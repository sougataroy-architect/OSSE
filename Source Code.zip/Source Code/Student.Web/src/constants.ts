export class Constants {
  public static get baseURL(): string { return " http://localhost/Student.Api/api/"; }
  }