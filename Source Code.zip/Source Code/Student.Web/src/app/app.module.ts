import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injectable } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
 
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
 
import { LayoutComponent } from './shared/layout/layout.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { LayoutModule } from './shared/layout/layout.module';
 
import { HttpClientModule } from '@angular/common/http';
 
import { EventEmitterService } from './event-emitter.service';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgxDatatablePagerModule } from 'ngx-datatable-pager';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { StudentComponent } from '../../src/app/student/student.component';

@NgModule({
  declarations: [
    AppComponent,
    
    LayoutComponent,
    HeaderComponent,
    FooterComponent,
    
   
    
    StudentComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    HttpClientModule,
    NgxDatatableModule,
    NgxPaginationModule,
    NgbModule,
    NgxDatatablePagerModule.forRoot()
    ],
  providers: [EventEmitterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
