import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Student, Paging, PagerModel, Search } from './student.module';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StudentService } from '../student/student.service'


declare var jquery: any;
declare var $: any;


@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  @ViewChild('myTable', { static: true }) table: ElementRef;
  studentList: Student[];
  response: any;
  name: string;
  paging: Paging;
  totalRecords: any;
  search : Search = 
  {
    Name: "",
    Grade: "",
    School: ""

  };
  public currentPageLimit: number = 1;
  public pageLimitOptions = [
    { value: 1 },
    { value: 10 },
    { value: 25 },
    { value: 50 },
    { value: 100 },
  ];
  private _PageNumbers: Int32List;
  studentForm: FormGroup;

  student: Student = {
    Id: 0,
    Name: "",
    Grade: "",
    School: ""
  };
  constructor(private studentService: StudentService, private formBuilder: FormBuilder) {
    this.studentForm = this.formBuilder.group({
      Name: ["", Validators.required],
      Grade: ["", Validators.required],
      School: ["", Validators.required],
    });
  }

  ngOnInit() {
    var pager: PagerModel =
    {
      PageIndex: 1,
      PageSize: 100,
      TotalRecords: 100,
      JsFunction: "StudentList",
      Parameters: "testing"
    }

    this.GetStudentList(pager);
  }

  ResetSearch()
  {
  this.search = { Name:'', School:"", Grade:""};
  var pager: PagerModel =
  {
    PageIndex: 1,
    PageSize: this.paging.PageSize,
    TotalRecords: 100,
    JsFunction: "StudentList",
    Parameters: "testing"
  }
  this.GetStudentList(pager);
  }

  GetStudentList(pager: any) {

    this.studentService.StudentList(pager,this.search).subscribe((response) => {
      this.response = response;
      this.studentList = this.response;
      this.totalRecords = this.response.length;// this.response.Data[0].TotalRecords;
      pager.TotalRecords = this.totalRecords;
      this.paging = pager;
    });
  }
  SaveStudent(model) {
    debugger
    if (this.studentForm.invalid) {
      if (this.studentForm.get('Name').value == "" ||
        this.studentForm.get('Grade').value == "" ||
        this.studentForm.get('School').value == "") {
        this.studentForm.get('Name').markAsTouched()
        this.studentForm.get('Grade').markAsTouched()
        this.studentForm.get('School').markAsTouched()
      }
    }
    else {

      this.studentService.SaveStudent(this.student).subscribe(student => {
        var pager: PagerModel =
        {
          PageIndex: 1,
          PageSize: this.paging.PageSize,
          TotalRecords: 100,
          JsFunction: "StudentList",
          Parameters: "testing"
        }
        this.GetStudentList(pager);
        $("#StudentAdd").HideCssPopup();
      });
      // ngForm.reset();
      // this.ResetStudent();
      
    }
  }
  ResetStudent() {

    this.student.Id = 0;
    this.student.Name = "";
    this.student.Grade = "";
    this.student.School = "";
  }

  AddNewStudent()
  {
   
    $('#txtName').val("");
    $('#txtGrade').val("");
    $('#txtSchool').val("");
    $('#StudentAdd').CssPopup();
  
  }

  EditStudent(id) {
    
    $('#StudentAdd').CssPopup();

    this.studentService.GetStudent(id).subscribe((response: Student) => {
      this.student = response;

    });
  }
  DeleteStudent(id) {
    this.studentService.DeleteStudent(id).subscribe((response: Student) => {
      this.GetStudentList(this.paging);
    });
  }


}
