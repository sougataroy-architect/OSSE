export class Student
{
    public Id : number;
    public Name : String;
    public Grade : String;
    public School : String;
}

export class Search
{
    public Name : String;
    public Grade : String;
    public School : String;

}
    export interface IListParameters
    {
          PageIndex : Number;
          Parameters : any;
          PageSize : Number;
    
    }
    export class  ListParameters implements IListParameters
    {
        PageIndex : Number;
        Parameters : any;
        PageSize : Number;
    
        constructor(pageIndex : Number, parameters : any)
        {
            this.PageIndex = pageIndex;
            this.Parameters = parameters;
        }
    }
    
    export class PagerModel
    {
        public PageIndex : number;
        public PageSize : number;
        public JsFunction : String;
        public TotalRecords : Number;
        public Parameters : any
    }
    
    export class Paging extends PagerModel
    {
      
        public TotalPages : number; 
        public StartIndex : number;
        public EndIndex : number;
        public PagingParms : Array<IListParameters>;
    
        _Parameter : ListParameters;
        constructor(pagerModel : PagerModel)
        {
            super();
            this.PageIndex = pagerModel.PageIndex;
            this.PageSize = pagerModel.PageSize;
            this.JsFunction = pagerModel.JsFunction;
            this.TotalRecords = pagerModel.TotalRecords;
            this.Parameters = pagerModel.Parameters;
    
            /******************************************************** this will not be passed ******************************************************/
            this.TotalPages = (Math.ceil(Number(this.TotalRecords) / Number(this.PageSize)));
            this.StartIndex =  (this.PageIndex + 2 > 5 && this.TotalPages > 5) ? (this.PageIndex - 2) : 1;
            this.EndIndex = (this.StartIndex + 5) < this.TotalPages ? (this.StartIndex +5) : this.TotalPages;
            this.PagingParms = new Array<ListParameters>();
            for(let  i=this.StartIndex; i<=this.EndIndex; i++)
            {
                this._Parameter = new ListParameters(i, this.Parameters);
                this.PagingParms.push(this._Parameter)
            }
           
        }
       
    }
    