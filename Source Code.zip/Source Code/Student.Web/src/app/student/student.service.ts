import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constants } from '../../constants';
import { Observable } from 'rxjs';
import { Student, Search } from '../student/student.module';
import { map } from 'rxjs/operators';
import { PaginatePipe } from 'ngx-pagination';


const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
    providedIn: 'root'
})



export class StudentService {
    _baseURL: string;
    response: any;
    headers: any;

    constructor(private http: HttpClient) {
        this._baseURL = Constants.baseURL;
        this.headers = new HttpHeaders().set('content-type', 'application/json');
    }


    public StudentList(paging, search: Search) {
        var searchResult: any = {
            Paging: paging,
            Search: search
        };
       
        return this.http.post(this._baseURL + "Student/GetStudents", searchResult, httpOptions)
    }

    public GetStudent(id) {
        return this.http.get(this._baseURL + "Student/" + id)
    }
    public DeleteStudent(id) {
        return this.http.delete(this._baseURL + "Student?id=" + id)
    }

    SaveStudent(model: Student): Observable<Student> {

        return this.http.post<Student>(this._baseURL + "Student", JSON.stringify(model), httpOptions)
            .pipe(map(x => x));
    }

    UpdateStudent(model: Student): Observable<Student> {
        return this.http.post<Student>(this._baseURL + "Student/UpdateStudent", JSON.stringify(model), httpOptions)
            .pipe(map(x => x));
    }




}
export class AjaxParameters {
    paging: any;

}