﻿var messageType =
{
    Message: 1,
    Warning: 2,
    Error: 3,
    InformativeMessage: 4,
    Confirmation: 5
};
var GROkayButtonText = "Okay";
var GRYesButtonText = "Yes";
var GRNoButtonText = "No";

(function ($) {
    var pb;
    var ifm, settings;
    var mousedown = false;
    var left = -500, top = 200;
    var popupmousemove;
    var popcontent, popup;
    var GeneralSettings = {
        'height': $(window).height(),
        'width': $(window).width(),
        'showIframe': false,
        'src': '',
        'title': 'CRM System',
        'showtitle': false,
        'Message': '',
        'okaybuttontext': GROkayButtonText,
        'callbackonokay': '',
        'callbackoncancel': '',
        'yesbuttontext': GRYesButtonText,
        'callbackonyes': '',
        'nobuttontext': GRNoButtonText,
        'callbackonno': '',
        'callbackonclose': '',
        'msgtype': messageType.Message,
        // 'successimage': SiteUrl + "/Content/images/success.png",
        // 'informative': SiteUrl + "/Content/images/informative.png",
        // 'errorimg': SiteUrl + "/Content/images/error1.png",
        // 'warning': SiteUrl + "/Content/images/warning.png",
        'isMobileDevice': $("body").find("#hdnIsMobileDevice").length > 0 ? $("body").find("#hdnIsMobileDevice").val() : false
    }
    var methods =
    {
        GetButton: function (Attributes) {
            return $("<input/>").attr(Attributes);
        },
        GetImageIcon: function (Attributes) {
            if (settings.msgtype == messageType.Message) {
                return GeneralSettings.successimage;
            }
            else if (settings.msgtype == messageType.InformativeMessage) {
                return GeneralSettings.informative;
            }
            else if (settings.msgtype == messageType.Error) {
                return GeneralSettings.errorimg;
            }
            else if (settings.msgtype == messageType.Warning) {
                return GeneralSettings.warning;
            }
            else {
                return GeneralSettings.informative;
            }
        }

    };
    $.fn.AddCallback = function (eventtype, callbackfunction) {
        this.bind(eventtype, function () {
            if (callbackfunction != null && $.isFunction(callbackfunction)) {
                callbackfunction($(this).parents("div.popup"));
            }
        });
        return this;
    };

    $.fn.hidediv = function (callbackonhide) {
        $(this).addClass("hide");
        if (pb != null) {
            pb = $($(this).parents("body").find("div.popupbackgroud"));
            pb.addClass("hidebackground");
        }
        if (navigator.userAgent.match(/msie/i) && parseInt(navigator.appVersion.replace(" (Windows)", "")) <= 8) {

            popcontent = $(this).find("div.DontRemove"); $(this).html(""); $(this).append(popcontent); popcontent.wrap("div.popup"); pb.show(); if (settings.callbackoncancel != null && $.isFunction(settings.callbackoncancel)) { callbackonhide(); }
            else { if (callbackonhide != null && $.isFunction(callbackonhide)) { settings.callbackoncancel(); } }
        }
        else {
            // pb.animate({ 'opacity': 0, 'filter': 'opacity(alpha = 0)' }, "slow", function () {
            popcontent = $(this).find("div.DontRemove");
            $(this).append(popcontent);
            popcontent.unwrap("div.popup");
            popcontent.removeClass("div.DontRemove");
            popcontent.addClass("hide");
            if (pb != null) {
                pb.show();
            }
            if (settings.callbackoncancel != null && $.isFunction(settings.callbackoncancel)) { settings.callbackoncancel(); }
            else {
                if (callbackonhide != null && $.isFunction(callbackonhide)) { callbackonhide(); }

            }
            // });
        }
        if (settings.draggable == true) { $(document).unbind("mousemove"); }
        $(document).unbind("mouseup"); $(document).unbind("keydown");
        pb = null;
    };
    $.fn.LoadIframe = function () {
        if (this.children().find(".iframePopup").length == 0) {
            var iframe = jQuery('<iframe/>', { "src": settings.src, "class": "iframePopup" });
            this.children("div.main-panel").append(iframe);
            ifm = this.children().find(".iframePopup");
            ifm.css({ 'width': (settings.width), 'height': (settings.height) - (settings.showtitle == true ? parseInt(this.children("div.error-title-panel").css("height").replace("px", "")) : "0"), 'overflow': 'hidden' });
        };
    };
    $.fn.MessageStructure = function (Message) {
        var Messageformat = $("<p/>").addClass("error-text").css({ "min-height": "35px" }).html(Message);
        this.append(Messageformat);
        this.AddButtons();
        var windowh = new Object();
        windowh = { "height": $(document).height(), "width": $(window).width() };
        settings.width = ($(this).outerWidth() < (windowh.width - 100)) ? ($(this).outerWidth() + 20) : (windowh.width - 100);
        if (settings.width < 350) {
            settings.width = 350;
        }
        $(this).width($(this).css("width", (windowh.width - 100)));
        var pheight = $(this).parents("div.popup").scroll().height() + 10;
        settings.height = (pheight < (windowh.height - 230)) ? pheight : (windowh.height - 230);
    };
    $.fn.LoadWindowContent = function () {
        if (settings.Message != '') {
            $(this).MessageStructure(settings.Message);
        }
        //   $(this).css({ 'height': settings.height - 16 - (settings.showtitle == true ? parseInt(this.parents("div.popup").children("div.error-title-panel").css("height").replace("px", "")) : "0"), 'width': settings.width - 28 });
    };
    $.fn.AddButtons = function () {
        var btnPanel = $("<div/>").addClass("btn-panel");
        if (settings.msgtype == messageType.Confirmation) {
            btnPanel.append(methods.GetButton({ "type": "button", "value": settings.yesbuttontext, "class": "button-orange" }).AddCallback("click", settings.callbackonyes)).append("&nbsp;");
            btnPanel.append(methods.GetButton({ "type": "button", "value": settings.nobuttontext, "class": "button-orange" }).AddCallback("click", settings.callbackonno));
        }
        else if (settings.msgtype == messageType.Message) {
            btnPanel.append(methods.GetButton({ "type": "button", "value": settings.okaybuttontext, "class": "button-orange" }).AddCallback("click", settings.callbackonokay));
        }
        else if (settings.msgtype == messageType.Error) {
            btnPanel.append($("<input />").attr({ "type": "submit", "value": settings.okaybuttontext, "class": "button-orange" }).AddCallback("click", settings.callbackonokay));
        }
        else if (settings.msgtype == messageType.Warning) {
            btnPanel.append($("<input />").attr({ "type": "submit", "value": settings.okaybuttontext, "class": "button-orange" }).AddCallback("click", settings.callbackonokay));
        }
        else {
            btnPanel.append($("<input />").attr({ "type": "submit", "value": setting.okaybuttontext, "class": "button-orange" }));
        }
        this.append(btnPanel);
    };

    $.fn.loadpopup = function (options) {
        settings = null;
        settings = $.extend(GeneralSettings, options);
        popup = $("<div />").addClass("popup").addClass("error-message");
        $(this).addClass("DontRemove");
        $(this).removeClass("hide");
        popcontent = $(this);
        popcontent.data("display", popcontent.css("display"));
        popcontent.wrap(popup);
        popup = popcontent.parents("div.popup");
        //$(popup).prepend('<div class="close"></div>');
        popup.popupsettings(options);
        //alert($(popup).children("a.icon-close-btn").length);
        $(popup).find(".icon-close-btn").click(function () {
            popup.hidediv();
        });
    };
    $.fn.popupsettings = function (options) {
        popup = $(this);
        top = (settings.height / 2) - (settings.height / 4);
        if (settings.showtitle == true) {
            $(popup).prepend('<div class="error-title-panel"><h2>' + GeneralSettings.title + '</h2><a href="#" class="icon-close-btn"></a><div class="clear"></div></div>');
            $(popup).find("div.error-title-panel").disableTextSelect();
        }
        $(this).children("div.main-panel").LoadWindowContent();
        pb = $($(this).parents("body").find("div.popupbackgroud"));
        if (pb == null || pb.length == 0) {
            $(this).after('<div class="popupbackgroud"></div>');

        } else {
            pb.removeClass("hidebackground");
        }
        popup.data("pw", settings.width);
        popup.data("ph", settings.height);
        var pleft = ($(window).width() / 2) - (popup.width() / 2);
        var ptop = $(window).width() < 900 == true ? "50" : ($(window).height() / 2) - ((popup.height()) / 2) - 50;
        this.css({ 'left': pleft + 'px', 'top': ptop + 'px' });
        if (settings.showIframe == true) {
            popup.LoadIframe();
        }

        $(document).bind("keydown", function (event) {
            var key = event.keycode || event.which;
            if (key == 27 && (pb.css('display') == 'block' || pb.css('display') == '')) {
                popup.hidediv();
            }
        });
    };
})(jQuery);
(function ($) {
    $.fn.hasScrollBar = function () {
        return this.get(0).scrollHeight > this.height();
    }
})(jQuery);
(function () {
    $.extend($.fn.disableTextSelect = function () {
        return this.each(function () {
            if (navigator.userAgent.match(/mozilla/i)) { /*Firefox*/
                $(this).css('MozUserSelect', 'none');
            } else if (navigator.userAgent.match(/msie/i)) {
                $(document).delegate($(
                this), 'selectstart', function () {
                    return false;
                });
                $(this).attr('unselectable', 'on').css('user-select', 'none');
            } else {
                $(this).mousedown(function () {
                    return false;
                });
            }
        });
    });
}(jQuery));

function LoadPoup(msgtype, message, successcallbackfunction, errorcallbackfunction) {
    var callbackfunction;
    if (successcallbackfunction != null && $.isFunction(successcallbackfunction) == true) {
        callbackfunction = successcallbackfunction;
    }
    else if (errorcallbackfunction != null && $.isFunction(errorcallbackfunction) == true) {
        callbackfunction = errorcallbackfunction;
    }
    else {
        callbackfunction = callbackfunction = function (popup) {
            HideDiv(popup);
        };
    }
    LoadGeneralPopup({ "Message": message, "msgtype": msgtype, "callbackonokay": callbackfunction });
}
function LoadGeneralPopup(options) {
    var popup = $("<div />").addClass("temppoup");
    $("body").append(popup);
    popup.loadpopup(options);
    return popup;
}


function MessageBox(popuptype, Message, callbackonokay, callbackonclose, callbackonyes, callbackonno) {
    messagepopupsettings(popuptype, Message, callbackonokay, callbackonclose, callbackonyes, callbackonno);
    $('div#Message').loadpopup();
}
function ErrorBox(Message, callbackonokay, callbackonclose) {
    var msgs = "";
    if (jQuery.type(Message) === "array") {
        $(Message).each(function (index, item) {
            msgs += item + "<br/>";
        });
    }
    else {
        msgs = Message;
    }
    MessageBox(messageType.Error, msgs, callbackonokay, callbackonclose);
    return false;
}
function ConfirmationBox(Message, callbackonyes, callbackonno, callbackonclose) {
    MessageBox(messageType.Confirmation, Message, null, callbackonclose, callbackonyes, callbackonno)
    return false;
}
function Message(Message, callbackonokay, callbackonclose) {
    MessageBox(messageType.Message, Message, callbackonokay, callbackonclose);
    return false;
}
function messagepopupsettings(popuptype, Message, callbackonokay, callbackonclose, callbackonyes, callbackonno, settings) {
    showhidebuttons(popuptype);
    $(".okay").RemoveClickEvent();
    $("#closeicon").RemoveClickEvent();
    $(".yes").RemoveClickEvent();
    $(".no").RemoveClickEvent();
    $("#closeicon").click(function () {
        HidePopup(callbackonclose, settings);
    });
    $(".okay").click(function () {
        if (callbackonokay != null) {
            HidePopup(callbackonokay, settings);
        }
        else {
            HidePopup(null, settings);
        }
    });
    $(".yes").click(function () {
        if (callbackonyes != null) {
            HidePopup(callbackonyes, settings);
        }
        else {
            HidePopup(null, settings);
        }
    });
    $(".no").click(function () {
        if (callbackonno != null) {
            HidePopup(callbackonno, settings);
        }
        else {
            HidePopup(null, settings);
        }
    });
    var icon = $($(".errormassage").find("span#spnIcon"));
    var message = $($(".errormassage").find("span#spnMessage"));
    icon.removeAttr("class");
    icon.attr("class", getErrorIconClass(popuptype));
    message.html(Message);
}
function getErrorIconClass(popuptype) {
    var icons = ["sucessicon", "infoicon", "erroricon", "infoicon", "infoicon"];
    return icons[popuptype - 1];
}
function showhidebuttons(popuptype) {
    if (popuptype == messageType.Confirmation) {
        $(".yes").show();
        $(".no").show();
        $(".okay").hide();
    }
    else {
        $(".yes").hide();
        $(".no").hide();
        $(".okay").show();
    }
}
function HidePopup(callbackonclose) {
    HideDiv($('div#Message'), callbackonclose);
}

function HideDiv(poupup, callbackonhide) {
    if (poupup != null) {
        poupup.hidediv(callbackonhide);
    }
}
(function ($) {
    $.fn.RemoveClickEvent = function () {
        $(this).RemoveEvent("click");
    }
    $.fn.RemoveEvent = function (event) {
        if ($(this).length > 0) {
            $(this).unbind(event)
        }

    };
})(jQuery);



/**************************************************Validation Script starts here *************************************************/
(function ($) {
    /* for this we required tooltip.js */
    var ErrorMessages = [];
    var result = { "IsValid": true, Message: "" }
    var validateEmail = function ($email) {
        var emailReg = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
        return emailReg.test($email);
    };
    var IsNumeric = function ($number) {
        return $.isNumeric($number);
    };
    var IsDecimal = function ($number) {
        var decimalReg = /^\d*(\.\d{1})?\d{0,1}$/;
        return decimalReg.test($number);
    };
    $.fn.ProcessErorr = function (message) {
        //$(this).AddErrorTooltip($(this).attr("data-r"), StaticSiteUrl);
        $(this).addClass("erroron");
        ErrorMessages.push(message);
    }
    $.fn.IsRquiredValidated = function () {
        var val = $(this).val();
        if (jQuery.trim(val).length == 0 || $(this).attr("data-default") == val || (jQuery(this).is("select") && jQuery.trim(val) == "0")) {
            return false;
        }
        return true;
    }
    $.fn.IsValidated = function () {
        ErrorMessages = new Array();
        var isValidated = true;
        $($(this).find("input[type='text'], input[type='Password'],textarea,select")).each(function (index, item) {
            if ($(this).IsErrorAvailable($(this)) == true) {
                isValidated = false;
            }
        });
        result.IsValid = isValidated;
        result.Message = ErrorMessages;
        return result;
    }
    $.fn.initValidation = function () {
        ErrorMessages = new Array();
        $(this).find("input[type='text'], input[type='Password'],textarea,select").each(function (index, item) {
            $(this).focus(function () {
                $(this).ValidateErrorEvent();
            });
            $(this).blur(function () {
                $(this).ValidateErrorEvent();
            });
        });
    };
    $.fn.ValidateErrorEvent = function () {
        $(this).IsErrorAvailable();
        if ($.trim($(this).data("dval")) == $.trim($(this).val())) {
            $(this).val("");
        }
    };
    $.fn.IsErrorAvailable = function () {
        var iserror = false;
        var attr = $(this).attr('data-r');
        if (typeof attr !== typeof undefined && attr !== false) {
            if (!$(this).IsRquiredValidated()) {
                iserror = true;
                $(this).ProcessErorr($(this).attr('data-r'));
                return iserror;
            }
            else {
                $(this).RemoveError();
            }
        }
        attr = $(this).attr('data-e');
        if (typeof attr !== typeof undefined && attr !== false) {
            var emailAddress = $(this).val();
            if (validateEmail(emailAddress) == false) {
                iserror = true;
                $(this).ProcessErorr($(this).attr('data-e'));
                return iserror;
            }
            else {
                $(this).RemoveError();
            }
        }
        attr = $(this).attr('data-i');
        if (typeof attr !== typeof undefined && attr !== false) {
            var number = $(this).val();
            if (jQuery.trim(number).length == 0 || $(this).attr("data-default") == number || (jQuery(this).is("select") && jQuery.trim(number) == "0")) {
                if (IsNumeric(number) == false) {
                    iserror = true;
                    $(this).ProcessErorr($(this).attr('data-i'));
                    return iserror;
                }
                else {
                    $(this).RemoveError();
                }
            }
        }
        attr = $(this).attr('data-d');
        if (typeof attr !== typeof undefined && attr !== false) {
            if (jQuery.trim(number).length == 0 || $(this).attr("data-default") == number || (jQuery(this).is("select") && jQuery.trim(number) == "0")) {
                var number = $(this).val();
                if (IsDecimal(number) == false) {
                    iserror = true;
                    $(this).ProcessErorr($(this).attr('data-d'));
                    return iserror;
                }
                else {
                    $(this).RemoveError();
                }
            }
        }
        return iserror;
    }
    $.fn.RemoveError = function () {
        $(this).removeClass("focus");
        $(this).removeClass("erroron");
    }


    var generalSettings = null;
    var SaveResponseDTO = {
        "IsValid": true,
        "Message": null,
        "Error": "",
        "Errors": [{ "ControlName": "", "DisplayMessage": "" }],
        "RecordId": null,
        "ExecutionScript": "",
        "MessageType": messageType.Message
    };
    $.fn.ParseResponse = function (iSaveResponseDTO, successcallback, errorcallback, ErrCntrlParentSelector) {
        //this.RemoveErrorTooltip();
        generalSettings = $.extend(SaveResponseDTO, iSaveResponseDTO);
        var parent = this;
        var emessage = "";
        if (generalSettings.ExecutionScript != null && generalSettings.ExecutionScript.IsEmpty() == false) {
            eval(generalSettings.ExecutionScript);
        }
        if (generalSettings.IsValid == true && generalSettings.MessageType == messageType.Message && generalSettings.Message.IsEmpty() == false) {
            emessage = emessage + generalSettings.Message + "<br/>";
        }
        else {
            $.each(SaveResponseDTO.Errors, function (RI, Response) {
                parent.find("[id *='" + Response.ControlName + "']").each(function (index, item) {
                    emessage = emessage + Response.DisplayMessage + "<br/>";
                    if (ErrCntrlParentSelector == null) {
                        $(this).addClass("erroron");
                        $(this).attr("title", Response.DisplayMessage)
                        //$(this).AddErrorTooltip(Response.DisplayMessage, SiteURL);
                    }
                    else {
                        /* Generally lies for login page where outside textbox there is a div and we have to show error line over div  */
                        $(this).parent(ErrCntrlParentSelector).addClass("erroron");
                        $(this).attr("title", Response.DisplayMessage)
                        //$(this).parent(ErrCntrlParentSelector).AddErrorTooltip(Response.DisplayMessage, SiteURL, false);
                    }
                });

            });
            if (generalSettings.Message != '') {
                emessage = emessage + generalSettings.Message + "<br/>";
            }
            generalSettings.MessageType = messageType.Error;

        }

        //LoadPoup(generalSettings.MessageType, emessage, successcallback, errorcallback);
        alert(SaveResponseDTO.Message);
        if (typeof successcallback !== typeof undefined) {
            successcallback(SaveResponseDTO);
        }
    };
})(jQuery);
/*************************************************Validation Script Ends here ****************************************************/


(function ($) {

    var generalSettings = null;
    var SaveResponseDTO = {
        "IsValid": true,
        "Message": null,
        "Error": "",
        "Errors": [{ "ControlName": "", "DisplayMessage": "" }],
        "RecordId": null,
        "ExecutionScript": "",
        "MessageType": messageType.Message
    };
    $.fn.SaveResponseParser = function (iSaveResponseDTO, successcallback, errorcallback, ErrCntrlParentSelector) {
        //this.RemoveErrorTooltip();
        generalSettings = $.extend(SaveResponseDTO, successcallback);
        var parent = this;
        var emessage = "";
        if (generalSettings.ExecutionScript != null && generalSettings.ExecutionScript.IsEmpty() == false) {
            eval(generalSettings.ExecutionScript);
        }
        if (generalSettings.IsValid == true && generalSettings.MessageType == messageType.Message && generalSettings.Message != null && generalSettings.Message.IsEmpty() == false) {
            emessage = emessage + generalSettings.Message + "<br/>";
        }
        else {
            $.each(SaveResponseDTO.Errors, function (RI, Response) {
                parent.find("[id *='" + Response.ControlName + "']").each(function (index, item) {
                    emessage = emessage + Response.DisplayMessage + "<br/>";
                    if (ErrCntrlParentSelector == null) {
                        $(this).addClass("error");
                        // $(this).AddErrorTooltip(Response.DisplayMessage, SiteUrl);
                    }
                    else {
                        /* Generally lies for login page where outside textbox there is a div and we have to show error line over div  */
                        $(this).parent(ErrCntrlParentSelector).addClass("error");
                        // $(this).parent(ErrCntrlParentSelector).AddErrorTooltip(Response.DisplayMessage, SiteUrl, false);
                    }
                });

            });
            if (generalSettings.Message != null && generalSettings.Message.IsEmpty() == false) {
                emessage = emessage + generalSettings.Message + "<br/>";
            }
            generalSettings.MessageType = messageType.Error;

        }

        LoadPoup(generalSettings.MessageType, emessage, successcallback, errorcallback);
    };
}(jQuery));
(function ($)
{
   $.fn.CssPopup = function () {
        var parentdiv = $(this);
        $(this).data("IspopupbgalreadyShowed", !$(".popup-bg").hasClass("hide"));
        $(this).find(".icon-close-btn").each(function () {
            $(this).unbind("click");
        });
        $(this).find(".icon-close-btn").click({ "parentdiv": parentdiv }, function (event) {
            $(parentdiv).HideCssPopup();
        });
        $(this).removeClass("hide");
        var height = $(this).height();
        var width = $(this).width();
        var screenheight = $(window).height();
        var screenwidth = $(window).width();
        var scrolltop = $(document).scrollTop() - 100;
        if ((typeof $(this).data("fullscreen") != typeof undefined && $(this).data("fullscreen") == true) || (screen.width <= 980)) {
            $(this).addClass("full-popup");
            if ((typeof $(this).data("issteppopup") != typeof undefined && $(this).data("issteppopup") == true)) {
                $(this).addClass("stepfullpopup");
                $(this).css("height", screenheight);
            }
            else {
                $(this).find(".full-popup-content").css("height", screenheight - $(this).find(".headererror").height() - 15)
            }
            $(this).parents("body").addClass("removeScroll");
            scrolltop = 0;
            $(".popup-bg").css({ "z-index": "99" });
        }
        else {
            if ((typeof $(this).data("fullscreen") != typeof undefined || $(this).data("fullscreen") == true)) {
                $(this).parents("body").addClass("removeScroll");
            }
            if (typeof (this).data("ispopuppreload") != typeof undefined || (this).data("ispopuppreload") == false) {
                scrolltop = 100;
                $(this).find(".popupcontent").css("max-height", (screenheight) / 1.2 - 130);
            }
            else {
                scrolltop = ((screenheight / 2) - (height / 2));
                $(this).find(".popupcontent").css("max-height", screenheight - $(this).find(".headererror").height() - 130);
            }
            $(this).addClass("css-popup");

            $(this).find(".popupcontent").css("overflow", 'auto');
            $(".popup-bg").removeClass("hide");

            $(".popup-bg").css({ "z-index": "102" });
            if (typeof (this).data("parentfullpopup") != typeof undefined || (this).data("parentfullpopup") == true) {
                $(".popup-bg").css({ "z-index": "104" });
                $(this).css({ "z-index": "105" });
            }
        }
        // $(this).css({ "top": scrolltop < 0 ? ((screenheight / 2) - (height / 2)) : scrolltop }); //"left": (screenwidth / 2 - width / 2) 

        $(this).css({ "top": scrolltop });

    };
    $.fn.HideCssPopup = function (IsHideBackgruound) {
        if (typeof IsHideBackgruound != typeof undefined && IsHideBackgruound != null && IsHideBackgruound == false) {

        }
        else {
            $(".popup-bg").addClass("hide");
        }
        $(this).addClass("hide");
    }

}(jQuery));

 