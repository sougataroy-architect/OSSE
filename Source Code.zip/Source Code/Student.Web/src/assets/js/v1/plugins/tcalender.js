(function ($) {
    var nextprevcurrenttype = { "Current": "c", "Next": "n", "Previous": "p" };
    var calenderType = { "Week": "W", "Month": "M", "Day": "D" };
    var monthType = { "Current": "c", "Next": "n", "Previous": "p" };
    var dayType = { "Current": "c", "Next": "n", "Previous": "p" };
    $.fn.ThirstCalender = function (options) {
        var opts = $.extend({}, $.fn.ThirstCalender.defaults, options);
        $(this).data("currentdate", opts.SelectedDate);
        return this.each(function () {
            var $this = $(this);
            var alldaysul = $this.find("ul.alldays");
            alldaysul.BindCalenderDays($this, opts, nextprevcurrenttype.Current);
            $(this).find(opts.NextSelector).click(function () {
                alldaysul.BindCalenderDays($this, opts, nextprevcurrenttype.Next);
            });
            $(this).find(opts.PreviousSelector).click(function () {
                alldaysul.BindCalenderDays($this, opts, nextprevcurrenttype.Previous);
            });
        });
    }
    $.fn.BindCalenderDays = function ($calparent, opts, nextPreviousCurrentType) {
        if (opts.CalenderType == calenderType.Week) {
            $(this).BindWeekDays($calparent, opts, nextPreviousCurrentType);
        }
        else {
            $(this).BindMonthDays($calparent, opts, nextPreviousCurrentType);
        }
    }
    $.fn.ThirstCalender.defaults =
    {
        SelectedDate: '2015-12-28', /* Date will be in yyyy-MM-dd format*/
        month: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        MonthShortNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'],
        dayName: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
        dayNameS: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        cssclass: { "PreviousMonth": "lm", "NextMothClass": "nm" },
        controlId: '',
        NextSelector: "[data-isnext]",
        PreviousSelector: "[data-isprev]",
        WeekDayNameSelector: ".weekdayname", /*WeekDaySelector compare to parent calender to display calendar name and detail*/
        WeekDayFullDay: "#dayw7",
        CalenderType: "M", /*CalenderType*/
        CallBackOnCalenderBind: ''

    };
    $.fn.BindMonthDays = function ($calparent, opts, nextPreviousCurrentType) {
        var calmethods = $.fn.ThirstCalender.Methods;
        $calparent.data("currentdate", calmethods.GetDate(nextPreviousCurrentType, $calparent.data("currentdate")));
        var day = 0, dayscounter = 0, lilist = "", d = new Date(), currentMonthCounter = 1, nmcounter = 1;
        $(this).html("");
        if (typeof $calparent.data("currentdate") != typeof undefined) {
            d = new Date($calparent.data("currentdate"));
        }
        var cm = calmethods.GetMonthDetail(monthType.Current, d);
        var nm = calmethods.GetMonthDetail(monthType.Next, d);
        var pm = calmethods.GetMonthDetail(monthType.Previous, d);
        $calparent.find(".currentdate").html(cm.MonthName + " " + cm.Year);
        $calparent.find(".current-date").html(cm.date);
        for (wday = 0; wday <= 6; wday++) {
            lilist += "<li><p>" + opts.dayName[wday] + "</p></li>";
        }
        var $weekday = $calparent.find(opts.WeekDayNameSelector);
        $weekday.html("");
        $weekday.html(lilist);
        lilist = "";
        var calday = 0;
        for (day = 0; day < 42; day++) {
            if (day >= cm.WeekDay && currentMonthCounter <= cm.Days) {
                lilist += "<li data-d='" + calmethods.GetDateFromYearMonthDay(cm.Year, cm.Month, currentMonthCounter) + "'><div class='date-cal'> <span class='date-here'>" + currentMonthCounter + "</span></div></li>";
                currentMonthCounter = currentMonthCounter + 1;
            }
            else if (day < cm.WeekDay) {
                /*Previous month value*/
                calday = (pm.Days - cm.WeekDay + day + 1);
                //console.log(calmethods.GetDateFromYearMonthDay(cm.Year, cm.Month, calday));
                lilist += "<li data-d='" + calmethods.GetDateFromYearMonthDay(pm.Year, pm.Month, calday) + "' ><div class='date-cal'> <span class='date-here '" + opts.cssclass.PreviousMonth + "'>" + calday + "</span></div></li>";
            }
            else {
                /* Next Month value */
                lilist += "<li data-d='" + calmethods.GetDateFromYearMonthDay(nm.Year, nm.Month, nmcounter) + "' ><div class='date-cal'> <span class='date-here '" + opts.cssclass.NextMothClass + "'>" + nmcounter + "</span></div></li>";
                nmcounter = nmcounter + 1;
            }
        }
        $(".thirstcalender").find("li").find("a").click(function () {
        });
        $(this).append(lilist);
        //$(this).find("li").find("a").click(function () {
        //    $(".get-date").html(calmethods.GetDateFromYearMonthDay(cm.Year, cm.Month, $(this).data("d")));
        //});

        //$(this).find("li").click(function () {
        //    alert($(this).data("date"));
        //});
        if (typeof opts.CallBackOnCalenderBind != undefined && $.isFunction(opts.CallBackOnCalenderBind)) {
            var returnval = { 'CalenderClickType': nextPreviousCurrentType, 'FirstDate': '2016-04-01', 'LastDate': '2016-04-31' }
            opts.CallBackOnCalenderBind(returnval);
        }
    }
    $.fn.BindWeekDays = function ($calparent, opts, nextPreviousCurrentType) {
        var calmethods = $.fn.ThirstCalender.Methods;
        $calparent.data("currentdate", calmethods.GetWeekDate(nextPreviousCurrentType, $calparent.data("currentdate")));
        var day = 0, dayscounter = 0, lilist = "", d = new Date(), currentMonthCounter = 1, nmcounter = 1;
        $(this).html("");
        if (typeof $calparent.data("currentdate") != typeof undefined) {
            d = new Date($calparent.data("currentdate"));
        }
        var cd = calmethods.GetWeekDay(dayType.Current, d);
        lilist = "";
        $calparent.find("#selectable-1").selectable({
            selected: function (event, ui) {
                var selected = $("li[class$='ui-selected']").length;
                $calparent.find("#abc").html("you selected " + selected + " Row!");
                //alert("you selected " + selected + " Row!");
            }
        });
        var weekstartdate = new Date(cd.WeekStartDate);
        var weekenddate = new Date(cd.WeekEndDate);
        $calparent.find(".currentdate").html(calmethods.GetDisplayDate(weekstartdate) + " to " + calmethods.GetDisplayDate(weekenddate));
        for (day = 0; day < 7; day++) {
            weekstartdate = weekstartdate;
            lilist = "<p>" + opts.dayNameS[day] + " " + (weekstartdate.getMonth() + 1) + "/" + weekstartdate.getDate() + "</p>";
            weekstartdate.setDate(weekstartdate.getDate() + 1);
            $calparent.find("#dayw" + (day + 1)).html(lilist);
        }
    }
})(jQuery);
(function ($) {
    var dayType = { "Current": "c", "Next": "n", "Previous": "p" };
    var monthType = { "Current": "c", "Next": "n", "Previous": "p" };
    var opts = $.fn.ThirstCalender.defaults;
    $.fn.ThirstCalender.Methods =
    {
        GetDateFromYearMonthDay: function (Year, Month, Day) {
            return Year + "-" + (Month < 10 ? "0" : "") + Month + "-" + (Day < 10 ? "0" : "") + Day;
        },
        GetDisplayDate: function (date) {
            var d = new Date(date);
            return d.getDate() + "-" + opts.MonthShortNames[(d.getMonth())] + "-" + d.getFullYear();
        },
        DateAddDay: function (d, Day) {
            var fd = new Date(d.getFullYear(), d.getMonth(), Day);
            return $.fn.ThirstCalender.Methods.GetDateFromYearMonthDay(fd.getFullYear(), fd.getMonth() + 1, fd.getDate());
        },
        GetFormatDate: function (date) {
            var d = new Date(date);
            return d.getFullYear() + "-" + (d.getMonth() + 1 < 10 ? "0" : "") + (d.getMonth() + 1) + "-" + (d.getDate() < 10 ? "0" : "") + d.getDate();
        },
        GetCurrentDate: function () {
            var date = new Date();
            return date;
        },
        GetMonth: function (type, date) {
            var d = new Date($.fn.ThirstCalender.Methods.GetDate(type, date));
            return d.getMonth() + 1;
        },
        GetYear: function (type, date) {
            var d = new Date($.fn.ThirstCalender.Methods.GetDate(type, date));
            return d.getFullYear();
        },
        GetDate: function (type, date) {
            var d = new Date(date);
            d.setMonth(type == monthType.Current ? d.getMonth() : (type == monthType.Next ? d.getMonth() + 1 : d.getMonth() - 1));
            return $.fn.ThirstCalender.Methods.GetFormatDate(d);
        },
        GetWeekDate: function (type, date) {
            var d = new Date(date);
            d = (type == dayType.Current ? d : (type == dayType.Next ? $.fn.ThirstCalender.Methods.DateAddDay(d, d.getDate() + 7) : $.fn.ThirstCalender.Methods.DateAddDay(d, d.getDate() - 7)));
            return $.fn.ThirstCalender.Methods.GetFormatDate(d);
        },
        GetWeekDay: function (type, date) {
            var d = new Date($.fn.ThirstCalender.Methods.GetWeekDate(type, date));
            var weekday = d.getDay();
            var weekstartDate = new Date(d);
            var weekendDate = new Date(d);
            weekstartDate = $.fn.ThirstCalender.Methods.DateAddDay(weekstartDate, weekstartDate.getDate() - weekday);
            weekendDate = $.fn.ThirstCalender.Methods.DateAddDay(weekendDate, (weekendDate.getDate() + 6 - weekday));
            return { "WeekCurrentDay": weekday, "WeekStartDate": weekstartDate, "WeekEndDate": weekendDate, "CurrentWeekDate": d.getDate() }
        },
        GetMonthDetail: function (type, date) {
            var d = new Date();
            if (typeof date != typeof undefined) {
                d = new Date(date);
            }
            var year = $.fn.ThirstCalender.Methods.GetYear(type, d);
            var month = $.fn.ThirstCalender.Methods.GetMonth(type, d);

            //-------
            var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
            var y = firstDay.getFullYear();
            var m = firstDay.getMonth() + 1;
            var da = firstDay.getDate();
            var date = new Date(y, m, 1, -1);
            date.setDate(da);
            var dayss = opts.dayNameS[date.getUTCDay()];
            var firstIndxDay = opts.dayNameS.indexOf(dayss);
            //alert(firstIndxDay);

            //-------

            return { "Year": year, "Month": month, "date": d.getDate(), "MonthName": opts.month[month - 1], "Days": new Date(year, month, 1, -1).getDate(), "WeekDayName": dayss, "WeekDay": firstIndxDay }
        }
    };
})(jQuery);
$(document).ready(function () {
    //  $('.thirstcalender').ThirstCalender({ "CalenderType": "W", "SelectedDate": new Date() });
    $('.thirstMcalender').ThirstCalender({ "CalenderType": "M", "SelectedDate": new Date(), "CallBackOnCalenderBind": BindCalenderActivity });
});

function BindCalenderActivity(returnVal) {
    var url = SiteUrl + '/activity/getcalenderactivity';
    var data = new Object();
    data.firstDate = returnVal.FirstDate;
    data.lastDate = returnVal.LastDate;
    var eventList = "";
    PostData(data, url, function (response) {
        var date = new Date();
        var d1 = new Date();
        var d2 = new Date();
        var sd = new Date();
        var ed = new Date();
        var counter = 1;
        var days = 0;
        var top = 0;
        var len = 0;
        var obj = "";
        $.each(response, function (key1, $weekevents) {
			debugger;
            d1 = new Date(parseInt($weekevents.FirstDateOfWeek.substr(6)));
            d2 = new Date(parseInt($weekevents.LastDateOfWeek.substr(6)));
            counter = 1;
            while (d1 <= d2) {
                date = GetActualDate(d1);
                $.each($weekevents.Events, function (key, $event) {
					debugger;
                    obj = $('.thirstMcalender').find('li[data-d="' + date + '"]');
                    len = $(obj).find('div.event-note').find('li').length;
                    sd = new Date(parseInt($event.EstimatedStartDate.substr(6)));
                    ed = new Date(parseInt($event.EstimatedEndDate.substr(6)));

                    days = DayCalculation(sd, ed);

                    sd = GetActualDate(sd);
                    ed = GetActualDate(ed);

                    if ((date >= sd && date <= ed && counter == 1) || sd == date) {
                       
                        top = $(obj).find('div.event-note').find('li').length;
                        if (sd != date) {
                            sd = new Date(date);
                            ed = new Date(parseInt($event.EstimatedEndDate.substr(6)));
                             
                            days = DayCalculation(sd, ed);

                            sd = GetActualDate(sd);
                            ed = GetActualDate(ed);
                        }
                        if (len == 0) {
                            eventList = "<div class='event-note' style='position:relative'><ul>";
                            eventList += "<li class='event-li' style='background:darksalmon'><a href='#'>" + $event.Title + "</a> <div class='hover-tooltip'><h2>" + $event.Title + "</h2><p>" + $event.Description + "</p> <div class='tooltip-footer'> <span class='date-e-n'>" + sd + "-" + ed + "</span> <a href='#'>More details �</a> </div><span class='down-arrow'></span> </div></li>"
                            eventList += "</ul></div>";
                            $(obj).find('div.date-cal').find("span").after(eventList);
                        }
                        else {
                            eventList = "<li class='event-li' style='background:darksalmon'><a href='#'>" + $event.Title + "</a> <div class='hover-tooltip'><h2>" + $event.Title + "</h2><p>" + $event.Description + "</p> <div class='tooltip-footer'> <span class='date-e-n'>" + sd + "-" + ed + "</span> <a href='#'>More details �</a> </div><span class='down-arrow'></span> </div></li>"
                            $(obj).find('div.event-note ul').append(eventList);
                        }
                        if (counter + days > 7)
                        {
                            days = 7 - counter;
                        }
                        for (var i = 0; i < days; i++) {
							debugger;
                            obj = $(obj).next("li[data-d]");
                            len = $(obj).find('div.event-note').find('li').length;
                            for (var j = 0; j < top-len; j++)
                            {
                                if(len==0)
                                {
                                    $(obj).find('div.date-cal').append("<div class='event-note'><ul><li></li></ul></div>");
                                }
                                else {
                                    $(obj).find('div.event-note ul').append("<li></li>");
                                }
                            }
                            len = $(obj).find('div.event-note').find('li').length;
                            if (len == 0) {
                                $(obj).find('div.date-cal').append("<div class='event-note' style='position:relative'><ul><li class='event-li' style='background:darksalmon'><a href='#'></a></li></ul></div>");
                            }
                            else {
                                $(obj).find('div.event-note ul').append("<li class='event-li' style='background:darksalmon'><a href='#'></a></li>");
                            }
                        }
                    }

                });
                counter++;
                d1.setDate(d1.getDate() + 1);
            }
        });

    });
}

function DayCalculation(firstDate, lastDate) {
    var oneDay = 24 * 60 * 60 * 1000;
    return Math.round(Math.abs((lastDate.getTime() - firstDate.getTime()) / (oneDay)));
}
function GetActualDate(date) {
    return date.getFullYear() + "-" + ((date.getMonth() + 1) < 10 ? "0" : "") + (date.getMonth() + 1) + "-" + (date.getDate() < 10 ? "0" : "") + date.getDate();
}

//$('.thirstMcalender').find('li[data-d]').each(function () {
//    //eventList = "<div class='event-note'><ul>";
//    var obj = this;
//    date = $(this).attr('data-d');
//    $.each(response, function (key, value) {
//        eventList = "<div class='event-note'><ul>";
//        sd = new Date(parseInt($(this)[0].EstimatedStartDate.substr(6)));
//        ed = new Date(parseInt($(this)[0].EstimatedEndDate.substr(6)));

//        days = dayCalculation(sd, ed);

//        sd = sd.getFullYear() + "-" + ((sd.getMonth() + 1) < 10 ? "0" : "") + (sd.getMonth() + 1) + "-" + (sd.getDate() < 10 ? "0" : "") + sd.getDate();
//        ed = ed.getFullYear() + "-" + ((ed.getMonth() + 1) < 10 ? "0" : "") + (ed.getMonth() + 1) + "-" + (ed.getDate() < 10 ? "0" : "") + ed.getDate();

//        if (sd == date) {
//            top = ($(obj).find('div.event-note').length) * height;
//            eventList += "<li style='background:darksalmon;position:relative;top:" + top + "px;height:" + height + "px'><a href='#'>" + $(this)[0].Title + "</a> <div class='hover-tooltip'><h2>" + $(this)[0].Title + "</h2><p>" + $(this)[0].Description + "</p> <div class='tooltip-footer'> <span class='date-e-n'>Mon, July 14, 2014</span> <a href='#'>More details �</a> </div><span class='down-arrow'></span> </div></li>"
//            eventList += "</ul></div>";
//            debugger;
//            $(obj).find('div.date-cal').append(eventList);

//            for (var i = 0; i < days; i++) {
//                debugger;
//                $(obj).next("li[data-d]").find('div.date-cal').append("<div class='event-note'><ul><li style='background:darksalmon;position:relative;top:" + top + "px;height:" + height + "px'><a href='#'></a></li></ul></div>");
//                obj = $(obj).next("li[data-d]");
//            }
//        }

//    });
//    if (counter % 7 === 0) {
//        counter = 1
//    }
//    counter++;


//    //$(this).find('div.date-cal').find("span").after(eventList);
//});