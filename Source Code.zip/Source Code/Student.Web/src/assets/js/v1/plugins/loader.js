﻿
(function ($) {

    var methods =
        {
            IsObject: function ($obj) {
                if (typeof $obj != typeof undefined && $obj.length > 0) {
                    return true;
                }
            }
        };
    $.fn.Value = function (val) {
        if ($(this).get(0).tagName == "INPUT") {
            $(this).val(val);
        }
        else {
            $(this).html(val);
        }
    }
    $.fn.ShowLoader = function () {
        debugger;
        var $loaderbg = $($("body").find(".loader-bg")[0]);
        if (methods.IsObject($loaderbg)) {
            $loaderbg.removeClass("hide");
        }
        if ($(this).get(0).tagName.toLowerCase() !="body" && typeof $(this).data("fullloader") == typeof undefined) {
            //<button type="button" class="btn mrgTB20 loadingonbtn"><span>Sign-Up</span><img src="images/logo-1.png" class="lg fadeIn"><img src="images/loader-1.gif" class="btn_loader"></button>
            if ($(this).get(0).tagName == "BUTTON" || $(this).get(0).tagName == "A") {
                if (typeof $(this).data("html") == typeof undefined || $(this).data("html") == "")
                {
                    $(this).data("html", $(this).html());
                }
                $(this).html("<span>" + $(this).html() + "</span>" + $("#spnbuttonloader").html());
            }
            else if ($(this).get(0).tagName == "INPUT" && $(this).get(0).type == "button") {
                $(this).data("html", $(this).val());
                $(this).val("");
            }
            $(this).addClass("loadingonbtn");
            $(this).attr('disabled', 'disabled');
        }

        else {
            $("#AjaxProgressLoader").removeClass("hide");
        }
        $(this).attr("data-loaderrunning", true);

    };
    $.fn.HideLoader = function () {
        var $loaderbg = $($("body").find(".loader-bg")[0]);
        if (methods.IsObject($loaderbg)) {
            $loaderbg.addClass("hide");
        }
        if (typeof $(this).data("fullloader") == typeof undefined) {
            if ($(this).hasClass("loadingonbtn") == true) {
                $(this).Value($(this).data("html"));
                $(this).removeClass("loadingonbtn");
                $(this).data("html", "");
                $(this).removeAttr('disabled', 'disabled');
            }
        }
        else {
            $("#AjaxProgressLoader").addClass("hide");
        }
        $(this).attr("data-loaderrunning", false);
    };
    $.fn.HideAllRunningLoader = function () {
        $(this).find("[data-loaderrunning=true]").each(function () {
            $(this).HideLoader();
        })

    }
})(jQuery);
