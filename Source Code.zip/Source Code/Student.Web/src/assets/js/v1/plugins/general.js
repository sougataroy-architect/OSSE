var messageType =
{
    Message: 1,
    Warning: 2,
    Error: 3,
    InformativeMessage: 4,
    Confirmation: 5
};
var SaveResponseDTO = {
    "IsValid": true,
    "Message": null,
    "Error": "",
    "Errors": [{ "ControlName": "", "DisplayMessage": "" }],
    "RecordId": null,
    "ExecutionScript": "",
    "MessageType": messageType.Message
};


var cnt = $("#dvLookupContainer");
var expectedReturnType =
{
    Json: 'json',
    Html: 'html',
    Xml: 'xml',
    Script: 'script'
};
var expectedInputType =
{
    Default: 'application/x-www-form-urlencoded; charset=UTF-8',
    Json: 'application/json; charset=utf-8'
};

function HasObjectProperty(obj) {
    for (var prop in obj) {
        return true;
    }
    return false;
}
function IsNullOrEmpty(Value) {
    if (Value != null && $.trim(Value).length > 0) {
        return false;
    }
    return true;
}
var loadertype = {
    "button": 1,
    "full": 2,
    "div": 3
};
function __PostMessage(postData, actionUrl, returnType, expectedType, callBackFunction, buttonObject, LoaderType) {
    // ShowLoader(buttonObject, LoaderType);
    $.ajax({
        type: "POST",
        url: actionUrl,
        data: postData,
        contentType: expectedType,
        dataType: returnType,
        success: function (data) {
            // ShowLoader(buttonObject, LoaderType);
            if (data.IsFatalError) {
                alert(data.Message);
            }
            if ($.isFunction(callBackFunction) == true) {
                callBackFunction(data);
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            //ShowLoader(buttonObject, LoaderType);
            alert(xhr.status);
            //alert(thrownError);
        }
    });
}
function ShowLoader() {
    //$("#divSmallLoader").toggleClass("hide");
    //$("#divSmallLoader").height($(document).height());
    //$("#divSmallLoader").find("img").css({ "top": $(window).height() / 2 }, { "left": $(window).width() / 2 });

}
function PostData(postData, actionUrl, callBackFunction, buttonObject, LoaderType) {
    __PostMessage($.toJSON(postData), actionUrl, expectedReturnType.Json, expectedInputType.Json, callBackFunction, buttonObject, LoaderType);
}

function PostDataGetHtml(postData, actionUrl, callBackFunction, buttonObject, LoaderType) {
    __PostMessage($.toJSON(postData), actionUrl, expectedReturnType.Html, expectedInputType.Json, callBackFunction, buttonObject, LoaderType);
}
function PostJson(postData, actionUrl, callBackFunction, buttonObject, LoaderType) {
    __PostMessage(postData, actionUrl, expectedReturnType.Json, expectedInputType.Json, callBackFunction, buttonObject, LoaderType);
}

function PostJsonGetHtml(pdata, actionUrl, selffunction, buttonObject, LoaderType) {
    __PostMessage(pdata, actionUrl, expectedReturnType.Html, expectedInputType.Json, selffunction, buttonObject, LoaderType);
}
function AjaxError(xhr, ajaxOptions, thrownError) {
    ShowLoader();
    alert(xhr.status);
    alert(thrownError);
};

(function ($) {
    m = { '\b': '\\b', '\t': '\\t', '\n': '\\n', '\f': '\\f', '\r': '\\r', '"': '\\"', '\\': '\\\\' },
    $.toJSON = function (value, whitelist) {
        var a,          // The array holding the partial texts.
            i,          // The loop counter.
            k,          // The member key.
            l,          // Length.
            r = /["\\\x00-\x1f\x7f-\x9f]/g,
            v;          // The member value.

        switch (typeof value) {
            case 'string':
                return r.test(value) ?
                '"' + value.replace(r, function (a) {
                    var c = m[a];
                    if (c) {
                        return c;
                    }
                    c = a.charCodeAt();
                    return '\\u00' + Math.floor(c / 16).toString(16) + (c % 16).toString(16);
                }) + '"' :
                '"' + value + '"';

            case 'number':
                return isFinite(value) ? String(value) : 'null';

            case 'boolean':
            case 'null':
                return String(value);

            case 'object':
                if (!value) {
                    return 'null';
                }
                if (typeof value.toJSON === 'function') {
                    return $.toJSON(value.toJSON());
                }
                a = [];
                if (typeof value.length === 'number' &&
                    !(value.propertyIsEnumerable('length'))) {
                    l = value.length;
                    for (i = 0; i < l; i += 1) {
                        a.push($.toJSON(value[i], whitelist) || 'null');
                    }
                    return '[' + a.join(',') + ']';
                }
                if (whitelist) {
                    l = whitelist.length;
                    for (i = 0; i < l; i += 1) {
                        k = whitelist[i];
                        if (typeof k === 'string') {
                            v = $.toJSON(value[k], whitelist);
                            if (v) {
                                a.push($.toJSON(k) + ':' + v);
                            }
                        }
                    }
                } else {
                    for (k in value) {
                        if (typeof k === 'string') {
                            v = $.toJSON(value[k], whitelist);
                            if (v) {
                                a.push($.toJSON(k) + ':' + v);
                            }
                        }
                    }
                }
                return '{' + a.join(',') + '}';
        }
    };

})(jQuery);

function ParseSaveResponse(container, data, successCallBack) {
    if (data.SessionStatusCode != undefined) {
        MessageBox(data.SessionStatusMessage, function (popup) {
            HideMsgBox(popup, function () {
                window.location = SiteURL + "/login";
            });
        });
    }
    else
        container.ParseResponse(data, successCallBack);
}
/*

function ParseSaveResponse(data, successCallBack) {
    if (typeof data.SessionStatusCode != typeof undefined) {
        MessageBox(data.SessionStatusMessage, function (popup) {
            HideMsgBox(popup, function () {
                window.location = SiteUrl + "Login";
            });
        });
    }
    else
        cnt.SaveResponseParser(data, successCallBack);
}
*/
(function ($) {

    String.prototype.IsEmpty = function () {
        if (this != null && $.trim(this).length > 0) {
            return false;
        }
        return true;
    };

    String.prototype.trim = function () {
        return $.trim(this);
    };

})(jQuery);

//(function ($) {

//    $.fn.BindTinyMCE = function () {
//        alert('bind3');
//        tinymce.init({
//            mode: "exact",
//            elements: this.attr("id"), //id of the textarea(s) If multiple, need to have comma separated
//            editor_selector: "textarea",
//            height: $(this).attr("height"),
//            //plugins: [
//            //    "advlist autolink lists link image charmap print preview anchor",
//            //    "searchreplace visualblocks code fullscreen",
//            //    "insertdatetime media table contextmenu paste"
//            //],
//            toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
//        });
//    };
//})(jQuery);


/**************************************************Validation Script starts here *************************************************/

function initializeValidations(ParentObject) {
    $(ParentObject.find("input,textarea,select")).each(function (index, item) {
        //  AddWaterMark($(this));
        $(this).focus(function () {
            $(this).addClass("focus");

            if ($.trim($(this).data("dval")) == $.trim($(this).val())) {
                $(this).val("");
                // AddWaterMark($(this));
            }
        });
        $(this).blur(function () {
            $(this).removeClass("focus");
            IsErrorAvailable(this);
            if ($.trim($(this).val()) == "" && $(this).data("dval") != null) {
                $(this).val($(this).data("dval"));
                //AddWaterMark($(this));
            }
        });
    });

}

function RemoveError(obj) {
    $(obj).removeClass("requiredfield");
    $(obj).RemoveErrorTooltip();
}
function validateEmail($email) {
    var emailReg = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
    return emailReg.test($email);
}
function validatePhone($phone) {
    var emailReg = /^([\w-\.]+([\w-]+\.)+[\w-]{2,4})?$/;
    if (!emailReg.test($phone)) {
        return false;
    } else {
        return true;
    }
}
function IsErrorAvailable(obj) {
    var iserror = false;
    if ($(obj).attr("required")) {
        if (jQuery.trim($(obj).val()) == "" || jQuery.trim($(obj).val()) == $(obj).data("dval")) {
            iserror = true;
            $(obj).addClass("requiredfield");
            $(obj).AddErrorTooltip(fieldIsRequire, StaticSitePath);
            return iserror;
        }
        else {
            RemoveError($(obj));
        }
    }
    if ($(obj).data("email") == true) {
        var emailAddress = $(obj).val();
        if (validateEmail($(obj).val()) == false) {
            iserror = true;
            $(obj).RemoveErrorTooltip();
            $(obj).AddErrorTooltip(invalidEmail, StaticSitePath);
            return iserror;
        }
        else {
            RemoveError($(obj));
        }
    }

    return iserror;
}


function IsValidated(obj) {
    var isValidated = true;
    $($(obj).find("input,textarea,select")).each(function (index, item) {
        if (IsErrorAvailable($(this)) == true) {
            isValidated = false;
        }
    });
    return isValidated;
}


/*************************************************Validation Script Ends here ****************************************************/


function GetCountryStates(Id, Type) {
    var url = '';
    var controlId = '';
    if (Type == 'S') {
        url = SiteUrl + "/setup/getstates";
        controlId = 'ddlState';
        $("#" + controlId).find("option[value!='']").remove();
        $("#ddlCity").find("option[value!='']").remove();
        $("#ddlArea").find("option[value!='']").remove();
        $("#ddlNeighborhood").find("option[value!='']").remove();
    } else if (Type == 'C') {
        url = SiteUrl + "/setup/getcities";
        controlId = 'ddlCity';
        $("#" + controlId).find("option[value!='']").remove();
        $("#ddlArea").find("option[value!='']").remove();
        $("#ddlNeighborhood").find("option[value!='']").remove();
    }else if (Type == 'A') {
        url = SiteUrl + "/setup/getareas";
        controlId = 'ddlArea';
        $("#" + controlId).find("option[value!='']").remove();
        $("#ddlNeighborhood").find("option[value!='']").remove();
    } else if (Type == 'N') {
        url = SiteUrl + "/setup/getneighborhoods";
        controlId = 'ddlNeighborhood';
        $("#" + controlId).find("option[value!='']").remove();
    }
    if (Id != "") {
        var data = new Object();
        data.id = Id;
        PostData(data, url, function (response) {
            $.each(response, function () {
                $('<option>').val(this.Value).text(this.Text).appendTo("#" + controlId);
            });
        })
    }
}



//(function ($) {

//    var gs =
//    {
//        'LoaderImage': StaticSitePath + "/img/ajax_loader.gif",
//        'LogoImage': StaticSitePath + "/img/logo.png",
//        'WaitMessage': waitMessage

//    };
//    $.fn.ShowHideLoader = function (options) {
//        var settings = $.extend(gs, options)
//        var Loader = $("<div class='row margintop10 loader'><div class='span12' id='failMsg' style='display:none;'></div><div id='srp_loading' class='row alignCenter'>" +
//                      "<div id='srp_loading_content'><br /><br /><div class='margintop10'>" +
//                      "<img border='0' id='img1' src='" + settings.LogoImage + "' alt='' /></div>" +
//                      "<div class='margintop10'><img border='0' src='" + settings.LoaderImage + "' alt='" + +"' /></div>" +
//                      "<div class='margintop10' ><br/> " + settings.WaitMessage + " </div></div></div></div></div>");
//        if ($(this).find('.loader').length == 0) {
//            $(Loader).appendTo($(this));
//            $(this).show();
//        }

//    };
//    $.fn.HideLoader = function (options) {
//        if ($(this).find('.loader').length > 0) {
//            $(this).html('');
//        }
//    }
//})(jQuery);
//function ShowHideLoader() {
//    if ($("#ajaxloader").length > 0) {
//        $("#ajaxloader").ShowHideLoader();
//    }
//}
//function HideLoader() {
//    if ($("#ajaxloader").length > 0) {
//        $("#ajaxloader").HideLoader();
//    }
//}



(function ($) {
    /* for this we required tooltip.js */
    var ErrorMessages = [];
    var result = { "IsValid": true, Message: "" }
    var validateEmail = function ($email) {
        var emailReg = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
        return emailReg.test($email);
    };
    var IsNumeric = function ($number) {
        return $.isNumeric($number);
    };
    var IsDecimal = function ($number) {
        var decimalReg = /^\d*(\.\d{1})?\d{0,1}$/;
        return decimalReg.test($number);
    };

    $.fn.ProcessErorr = function (message) {
        iserror = true;
        $(this).AddErrorTooltip(message, StaticSitePath);
        ErrorMessages.push(message);
        return iserror;
    }
    $.fn.IsRquiredValidated = function () {
        var val = $(this).val();
        if (jQuery.trim(val).length == 0 || $(this).attr("data-default") == val || (jQuery(this).is("select") && jQuery.trim(val) == "0")) {
            return false;
        }
        return true;
    }
    $.fn.IsValidated = function () {
        ErrorMessages = new Array();
        var isValidated = true;
        $($(this).find("input[type='text'], input[type='Password'],textarea,select")).each(function (index, item) {
            if ($(this).IsErrorAvailable($(this)) == true) {
                isValidated = false;
            }
        });
        result.IsValid = isValidated;
        result.Message = ErrorMessages;
        return result;
    }
    $.fn.initValidation = function () {
        ErrorMessages = new Array();
        $(this).find("input[type='text'], input[type='Password'],textarea,select").each(function (index, item) {
            $(this).focus(function () {
                $(this).ValidateErrorEvent();
            });
            $(this).blur(function () {
                $(this).ValidateErrorEvent();
            });
        });
    };
    $.fn.ValidateErrorEvent = function () {
        $(this).IsErrorAvailable();
        if ($.trim($(this).data("dval")) == $.trim($(this).val())) {
            $(this).val("");
        }
    };
    $.fn.IsErrorAvailable = function () {
        var iserror = false;
        var attr = $(this).attr('data-r');
        if (attr != undefined && attr != 'undefined' && attr != false) {
            if (!$(this).IsRquiredValidated()) {
                return $(this).ProcessErorr($(this).attr('data-r'));
            }
            else {
                $(this).RemoveError();
            }
        }
        attr = $(this).attr('data-e');
        if (attr != undefined && attr != 'undefined' && attr != false) {
            var emailAddress = $(this).val();
            if (validateEmail(emailAddress) == false) {
                return $(this).ProcessErorr($(this).attr('data-e'));
            }
            else {
                $(this).RemoveError();
            }
        }
        attr = $(this).attr('data-i');
        if (attr != undefined && attr != 'undefined' && attr != false) {
            var number = $(this).val();
            if (jQuery.trim(number).length == 0 || $(this).attr("data-default") == number || (jQuery(this).is("select") && jQuery.trim(number) == "0")) {
                if (IsNumeric(number) == false) {
                    return $(this).ProcessErorr($(this).attr('data-i'));
                }
                else {
                    $(this).RemoveError();
                }
            }
        }
        attr = $(this).attr('data-d');
        if (attr != undefined && attr != 'undefined' && attr != false) {
            if (jQuery.trim(number).length == 0 || $(this).attr("data-default") == number || (jQuery(this).is("select") && jQuery.trim(number) == "0")) {
                var number = $(this).val();
                if (IsDecimal(number) == false) {
                    return $(this).ProcessErorr($(this).attr('data-d'));
                }
                else {
                    $(this).RemoveError();
                }
            }
        }

        return iserror;

    }
    $.fn.RemoveError = function () {
        $(this).removeClass("focus");
        $(this).RemoveErrorTooltip();
    }
})(jQuery);

function GetQueryString() {
    return $.trim(location.href.split('?')[1]);
}

(function ($) {
    $.fn.FilePreview = function (fileindex, imgcontrol) {
        if ($(this).get(0).tagName == "INPUT" && $(this).get(0).type == "file" && $(this).val().length > 0 && $(this).prop("files").length - 1 >= fileindex) {
            var reader = new FileReader();
            reader = new FileReader();
            reader.readAsDataURL($(this).prop("files")[fileindex]);
            reader.onload = function (e) {
                if (imgcontrol != null && imgcontrol.length > 0) {
                    imgcontrol.attr('src', e.target.result);
                }
            }
        }
    };
})(jQuery);

(function ($) {
    $.fn.FileExtension = function (fileindex) {
        if ($(this).get(0).tagName == "INPUT" && $(this).get(0).type == "file" && $(this).val().length > 0 && $(this).prop("files").length - 1 >= fileindex) {
            var filename = $(this).prop("files")[fileindex].name;
            var totallength = filename.split(".").length;
            return filename.split(".")[totallength - 1].toString().toLowerCase();
        }
    };
})(jQuery);