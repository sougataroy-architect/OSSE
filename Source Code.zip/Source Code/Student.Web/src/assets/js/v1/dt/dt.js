﻿var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], dayNamesShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], dayNamesMin = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], dayNamesMinar = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'], Hijrimonth2014 = ['يناير   2014 / صفر - ربيع الاول 1435', ' فبراير  2014 / ربيع الثاني - ربيع الثاني  1435', 'مارس  2014/ ربيع الثاني - جمادى الاولى 1435', 'ابريل 2014/ جمادى الآخرة - جمادى الآخرة  1435', 'مايو  2014/ رجب  - رجب 1435', 'يونيو  2014/ شعبان - رمضان  1435', 'يوليو 2014/ رمضان  - شوال  1435', 'اغسطس  2014 / شوال  - ذو القعدة  1435', 'سبتمبر  2014/ ذو القعدة  - ذو الحجة  1435', 'اكتوبر  2014/ ذو الحجة  1435 - محرم 1436', 'نوفمبر   2014/ محرم  1436 - صفر 1436', 'ديسمبر  2014/ صفر - ربيع الاول 1436'], Hijrimonth2015 = ['يناير   2015 / ربيع الاول - ربيع الثاني 1436', ' فبراير  2015 / ربيع الثاني -جمادى الاولى  1436', 'مارس  2015/ جمادى الاولى  - جمادى الآخرة 1436', 'ابريل 2015/ جمادى الآخرة - رجب  1436', 'مايو  2015/ رجب  - شعبان 1436', 'يونيو  2015/ شعبان - رمضان  1436', 'يوليو 2015/ رمضان  - شوال  1436', 'اغسطس  2015 / شوال  - ذو القعدة  1436', 'سبتمبر  2015/ ذو القعدة  - ذو الحجة  1436', 'اكتوبر  2015/ذو الحجة   1436 - محرم 1437', 'نوفمبر   2015/ محرم  1437 - صفر 1437', 'ديسمبر  2015/ صفر - ربيع الاول 1437'];
var LangId = '1';
var showhijaritext = ['Show Hijri', 'Show Hijri'];
(function (a, b) {
    function c(b) {
        return !a(b).parents().andSelf().filter(function () {
            return a.curCSS(this, "visibility") === "hidden" || a.expr.filters.hidden(this)
        }).length;
    }
    a.ui = a.ui || {};
    if (a.ui.version) {
        return;
    }
    a.extend(a.ui, {
        version: "1.8.11",
        keyCode: {
            ALT: 18,
            BACKSPACE: 8,
            CAPS_LOCK: 20,
            COMMA: 188,
            COMMAND: 91,
            COMMAND_LEFT: 91,
            COMMAND_RIGHT: 93,
            CONTROL: 17,
            DELETE: 46,
            DOWN: 40,
            END: 35,
            ENTER: 13,
            ESCAPE: 27,
            HOME: 36,
            INSERT: 45,
            LEFT: 37,
            MENU: 93,
            NUMPAD_ADD: 107,
            NUMPAD_DECIMAL: 110,
            NUMPAD_DIVIDE: 111,
            NUMPAD_ENTER: 108,
            NUMPAD_MULTIPLY: 106,
            NUMPAD_SUBTRACT: 109,
            PAGE_DOWN: 34,
            PAGE_UP: 33,
            PERIOD: 190,
            RIGHT: 39,
            SHIFT: 16,
            SPACE: 32,
            TAB: 9,
            UP: 38,
            WINDOWS: 91
        }
    });
    a.fn.extend({
        _focus: a.fn.focus,
        focus: function (b, c) {
            return typeof b === "number" ? this.each(function () {
                var d = this;
                setTimeout(function () {
                    a(d).focus();
                    if (c) {
                        c.call(d);
                    }
                }, b);
            }) : this._focus.apply(this, arguments);
        },
        scrollParent: function () {
            var b;

            b = this.parents().filter(function () {
                return /(auto|scroll)/.test(a.curCSS(this, "overflow", 1) + a.curCSS(this, "overflow-y", 1) + a.curCSS(this, "overflow-x", 1));
            }).eq(0);
            return /fixed/.test(this.css("position")) || !b.length ? a(document) : b;
        },
        zIndex: function (c) {
            if (c !== b) {
                return this.css("zIndex", c);
            }
            if (this.length) {
                var d = a(this[0]),
                    e, f;
                while (d.length && d[0] !== document) {
                    e = d.css("position");
                    if (e === "absolute" || e === "relative" || e === "fixed") {
                        f = parseInt(d.css("zIndex"), 10);
                        if (!isNaN(f) && f !== 0) {
                            return f;
                        }
                    }
                    d = d.parent();
                }
            }
            return 0;
        },
        disableSelection: function () {
            return this.bind((a.support.selectstart ? "selectstart" : "mousedown") + ".ui-disableSelection", function (a) {
                a.preventDefault();
            });
        },
        enableSelection: function () {
            return this.unbind(".ui-disableSelection");
        }
    });
    a.each(["Width", "Height"], function (c, d) {
        function h(b, c, d, f) {
            a.each(e, function () {
                c -= parseFloat(a.curCSS(b, "padding" + this, true)) || 0;
                if (d) {
                    c -= parseFloat(a.curCSS(b, "border" + this + "Width", true)) || 0;
                }
                if (f) {
                    c -= parseFloat(a.curCSS(b, "margin" + this, true)) || 0;
                }
            });
            return c;
        }
        var e = d === "Width" ? ["Left", "Right"] : ["Top", "Bottom"],
            f = d.toLowerCase(),
            g = {
                innerWidth: a.fn.innerWidth,
                innerHeight: a.fn.innerHeight,
                outerWidth: a.fn.outerWidth,
                outerHeight: a.fn.outerHeight
            };
        a.fn["inner" + d] = function (c) {
            if (c === b) {
                return g["inner" + d].call(this);
            }
            return this.each(function () {
                a(this).css(f, h(this, c) + "px");
            });
        };
        a.fn["outer" + d] = function (b, c) {
            if (typeof b !== "number") {
                return g["outer" + d].call(this, b);
            }
            return this.each(function () {
                a(this).css(f, h(this, b, true, c) + "px");
            });
        }
    });
    a.extend(a.expr[":"], {
        data: function (b, c, d) {
            return !!a.data(b, d[3]);
        },
        focusable: function (b) {
            var d = b.nodeName.toLowerCase(),
                e = a.attr(b, "tabindex");
            if ("area" === d) {
                var f = b.parentNode,
                    g = f.name,
                    h;
                if (!b.href || !g || f.nodeName.toLowerCase() !== "map") {
                    return false;
                }
                h = a("img[usemap=#" + g + "]")[0];
                return !!h && c(h);
            }
            return (/input|select|textarea|button|object/.test(d) ? !b.disabled : "a" == d ? b.href || !isNaN(e) : !isNaN(e)) && c(b);
        },
        tabbable: function (b) {
            var c = a.attr(b, "tabindex");
            return (isNaN(c) || c >= 0) && a(b).is(":focusable");
        }
    });
    a(function () {
        var b = document.body,
            c = b.appendChild(c = document.createElement("div"));
        a.extend(c.style, {
            minHeight: "100px",
            height: "auto",
            padding: 0,
            borderWidth: 0
        });
        a.support.minHeight = c.offsetHeight === 100;
        a.support.selectstart = "onselectstart" in c;
        b.removeChild(c).style.display = "none";
    });
    a.extend(a.ui, {
        plugin: {
            add: function (b, c, d) {
                var e = a.ui[b].prototype;
                for (var f in d) {
                    e.plugins[f] = e.plugins[f] || [];
                    e.plugins[f].push([c, d[f]]);
                }
            },
            call: function (a, b, c) {
                var d = a.plugins[b];
                if (!d || !a.element[0].parentNode) {
                    return;
                }
                for (var e = 0; e < d.length; e++) {
                    if (a.options[d[e][0]]) {
                        d[e][1].apply(a.element, c);
                    }
                }
            }
        },
        contains: function (a, b) {
            return document.compareDocumentPosition ? a.compareDocumentPosition(b) & 16 : a !== b && a.contains(b);
        },
        hasScroll: function (b, c) {
            if (a(b).css("overflow") === "hidden") {
                return false;
            }
            var d = c && c === "left" ? "scrollLeft" : "scrollTop",
                e = false;
            if (b[d] > 0) {
                return true;
            }
            b[d] = 1;
            e = b[d] > 0;
            b[d] = 0;
            return e;
        },
        isOverAxis: function (a, b, c) {
            return a > b && a < b + c;
        },
        isOver: function (b, c, d, e, f, g) {
            return a.ui.isOverAxis(b, d, f) && a.ui.isOverAxis(c, e, g);
        }
    })
})(jQuery);
var hijariCheckBoxChecked = true;
 (function ($, undefined) {
    $.extend($.ui, { datepicker: { version: "1.8.11" } });
    var PROP_NAME = 'datepicker';
    var dpuuid = new Date().getTime();
    function Datepicker() {
        this.debug = false; // Change this to true to start debugging
        this._curInst = null; // The current instance in use
        this._keyEvent = false; // If the last event was a key event
        this._disabledInputs = []; // List of date picker inputs that have been disabled
        this._datepickerShowing = false; // True if the popup picker is showing , false if not
        this._inDialog = false; // True if showing within a "dialog", false if not
        this._mainDivId = 'ui-datepicker-div'; // The ID of the main datepicker division
        this._inlineClass = 'ui-datepicker-inline'; // The name of the inline marker class
        this._appendClass = 'ui-datepicker-append'; // The name of the append marker class
        this._triggerClass = 'icon-calendar'; // The name of the trigger marker class
        this._dialogClass = 'ui-datepicker-dialog'; // The name of the dialog marker class
        this._disableClass = 'ui-datepicker-disabled'; // The name of the disabled covering marker class
        this._unselectableClass = 'ui-datepicker-unselectable'; // The name of the unselectable cell marker class
        this._currentClass = 'ui-datepicker-current-day'; // The name of the current day marker class
        this._dayOverClass = 'ui-datepicker-days-cell-over'; // The name of the day hover marker class
        this.regional = []; // Available regional settings, indexed by language code
        this.regional[''] = { // Default regional settings
            closeText: 'Done', // Display text for close link
            prevText: '', // Display text for previous month link
            nextText: '', // Display text for next month link
            currentText: 'Today', // Display text for current month link
            monthNames: monthNames, // Names of months for drop-down and formatting
            monthNamesShort: monthNamesShort, // For formatting
            dayNames: dayNames, // For formatting
            dayNamesShort: dayNamesShort, // For formatting
            dayNamesMin: dayNamesMin, // Column headings for days starting at Sunday
            dayNamesMinar: dayNamesMinar,
            weekHeader: 'Wk', // Column header for week of the year
            dateFormat: 'yyy-mm-dd', // See format options on parseDate
            firstDay: 6, // The first day of the week, Sun = 0, Mon = 1, ...
            isRTL: false, // True if right-to-left language, false if left-to-right
            showMonthAfterYear: false, // True if the year select precedes month, false for month then year
            yearSuffix: '', // Additional text to append to the year in the month headers
            isShowAtTop: false, // Showcaledner at top
            defaultDate: null, // Used when field is blank: actual date,
        };
        this._defaults = { // Global defaults for all the date picker instances
            langid: 1,
            showOn: 'focus', // 'focus' for popup on focus,
            // 'button' for trigger button, or 'both' for either
            showAnim: 'fadeIn', // Name of jQuery animation for popup
            showOptions: {}, // Options for enhanced animations
            defaultDate: null, // Used when field is blank: actual date,
            // +/-number for offset from today, null for today
            appendText: '', // Display text following the input box, e.g. showing the format
            buttonText: '...', // Text for trigger button
            buttonImage: '', // URL for trigger button image
            buttonImageOnly: false, // True if the image appears alone, false if it appears on a button
            hideIfNoPrevNext: false, // True to hide next/previous month links
            // if not applicable, false to just disable them
            navigationAsDateFormat: false, // True if date formatting applied to prev/today/next links
            gotoCurrent: false, // True if today link goes back to current selection instead
            changeMonth: false, // True if month can be selected directly, false if only prev/next
            changeYear: false, // True if year can be selected directly, false if only prev/next
            yearRange: 'c-1:c+1', // Range of years to display in drop-down,
            // either relative to today's year (-nn:+nn), relative to currently displayed year
            // (c-nn:c+nn), absolute (nnnn:nnnn), or a combination of the above (nnnn:-n)
            showOtherMonths: false, // True to show dates in other months, false to leave blank
            selectOtherMonths: false, // True to allow selection of dates in other months, false for unselectable
            showWeek: false, // True to show week of the year, false to not show it
            calculateWeek: this.iso8601Week, // How to calculate the week of the year,
            // takes a Date and returns the number of the week for it
            shortYearCutoff: '+10', // Short year values < this are in the current century,
            // > this are in the previous century,
            // string value starting with '+' for current year + value
            minDate: null, // The earliest selectable date, or null for no limit
            maxDate: null, // The latest selectable date, or null for no limit
            duration: 'fast', // Duration of display/closure
            beforeShowDay: null, // Function that takes a date and returns an array with
            // [0] = true if selectable, false if not, [1] = custom CSS class name(s) or '',
            // [2] = cell title (optional), e.g. $.datepicker.noWeekends
            beforeShow: null, // Function that takes an input field and
            // returns a set of custom settings for the date picker
            afterShow: null,
            onSelect: null, // Define a callback function when a date is selected
            onChangeMonthYear: null, // Define a callback function when the month or year is changed
            onClose: null, // Define a callback function when the datepicker is closed
            numberOfMonths: 1, // Number of months to show at a time
            showCurrentAtPos: 0, // The position in multipe months at which to show the current month (starting at 0)
            stepMonths: 1, // Number of months to step back/forward
            stepBigMonths: 12, // Number of months to step back/forward for the big links
            altField: '', // Selector for an alternate field to store selected dates into
            altFormat: '', // The date format to use for the alternate field
            constrainInput: true, // The input is constrained by the current date format
            showButtonPanel: false, // True to show button panel, false to not show it
            autoSize: false, // True to size the input for the date format, false to leave as is
            triggerClass: null,
            isShowAtTop: false
        };
        $.extend(this._defaults, this.regional['']);
        this.dpDiv = $('<div id="' + this._mainDivId + '" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>');

    }
    $('#chkshowhijri').click(function () { $('.nexthijari').css("visibility", "hidden"); });
    function isArray(a) {
        return a && ($.browser.safari && typeof a == "object" && a.length || a.constructor && a.constructor.toString().match(/\Array\(\)/));
    }
    function extendRemove(a, b) {
        $.extend(a, b);
        for (var c in b) if (b[c] == null || b[c] == undefined) a[c] = b[c];
        return a;
    }
    $.extend(Datepicker.prototype, {
        markerClassName: "hasDatepicker",
        log: function () {
            if (this.debug) console.log.apply("", arguments);
        },
        _widgetDatepicker: function () {
            return this.dpDiv;
        },
        setDefaults: function (a) {
            extendRemove(this._defaults, a || {});
            return this;
        },
        _attachDatepicker: function (target, settings) {
            var inlineSettings = null;
            for (var attrName in this._defaults) {
                var attrValue = target.getAttribute("date:" + attrName);
                if (attrValue) {
                    inlineSettings = inlineSettings || {};
                    try {
                        inlineSettings[attrName] = eval(attrValue);
                    } catch (err) {
                        inlineSettings[attrName] = attrValue;
                    }
                }
            }
            var nodeName = target.nodeName.toLowerCase();
            var inline = nodeName == "div" || nodeName == "span";
            if (!target.id) {
                this.uuid += 1;
                target.id = "dp" + this.uuid;
            }
            var inst = this._newInst($(target), inline);
            inst.settings = $.extend({}, settings || {}, inlineSettings || {});
            if (nodeName == "input") {
                this._connectDatepicker(target, inst);
            } else if (inline) {
                this._inlineDatepicker(target, inst);
            }
        },
        _newInst: function (a, b) {
            var c = a[0].id.replace(/([^A-Za-z0-9_-])/g, "\\\\$1");
            return {
                id: c,
                input: a,
                selectedDay: 0,
                selectedMonth: 0,
                selectedYear: 0,
                drawMonth: 0,
                drawYear: 0,
                inline: b,
                dpDiv: !b ? this.dpDiv : $('<div class="' + this._inlineClass + ' ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>')
            };
        },
        _connectDatepicker: function (a, b) {
            var c = $(a);
            b.append = $([]);
            b.trigger = $([]);
            if (c.hasClass(this.markerClassName)) return;
            this._attachments(c, b);
            c.addClass(this.markerClassName).keydown(this._doKeyDown).keypress(this._doKeyPress).keyup(this._doKeyUp).bind("setData.datepicker", function (a, c, d) {
                b.settings[c] = d;
            }).bind("getData.datepicker", function (a, c) {
                return this._get(b, c);
            });
            this._autoSize(b);
            $.data(a, PROP_NAME, b);
        },
        _attachments: function (a, b) {
            var c = this._get(b, "appendText");
            var d = this._get(b, "isRTL");
            if (b.append) b.append.remove();
            if (c) {
                b.append = $('<span class="' + this._appendClass + '">' + c + "</span>");
                a[d ? "before" : "after"](b.append);
            }
            a.unbind("focus", this._showDatepicker);
            if (b.trigger) b.trigger.remove();
            var e = this._get(b, "showOn");

            if (e == "focus" || e == "both") {
                var is_safari = navigator.userAgent.indexOf("Safari") > -1;
                if (is_safari)
                    a.click(this._showDatepicker);
                else
                    a.focus(this._showDatepicker);
            }
            if (e == "button" || e == "both") {
                var f = this._get(b, "buttonText");
                var g = this._get(b, "buttonImage");
                b.trigger = $(this._get(b, "buttonImageOnly") ? $("<span/>").addClass(this._get(b, "triggerClass") == null ? this._triggerClass : this._get(b, "triggerClass")).attr({
                    //src: g,
                    //alt: f,
                    title: f,
                    height: 16,
                    width: 14
                }) : $('<button type="button"></button>').addClass(this._triggerClass).html(g == "" ? f : $("<span/>").attr({
                    //src: g,
                    //alt: f,
                    title: f
                })));
                a[d ? "before" : "after"](b.trigger);
                b.trigger.click(function () {
                    if ($.datepicker._datepickerShowing && $.datepicker._lastInput == a[0]) $.datepicker._hideDatepicker();
                    else $.datepicker._showDatepicker(a[0]);
                    return false;
                });
            }
        },
        _autoSize: function (a) {
            if (this._get(a, "autoSize") && !a.inline) {
                var b = new Date(2009, 12 - 1, 20);
                var c = this._get(a, "dateFormat");
                if (c.match(/[DM]/)) {
                    var d = function (a) {
                        var b = 0;
                        var c = 0;
                        for (var d = 0; d < a.length; d++) {
                            if (a[d].length > b) {
                                b = a[d].length;
                                c = d;
                            }
                        }
                        return c;
                    };
                    b.setMonth(d(this._get(a, c.match(/MM/) ? "monthNames" : "monthNamesShort")));
                    b.setDate(d(this._get(a, c.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - b.getDay());
                }
                a.input.attr("size", this._formatDate(a, b).length);
            }
        },
        _inlineDatepicker: function (a, b) {
            var c = $(a);
            if (c.hasClass(this.markerClassName)) return;
            c.addClass(this.markerClassName).append(b.dpDiv).bind("setData.datepicker", function (a, c, d) {
                b.settings[c] = d;
            }).bind("getData.datepicker", function (a, c) {
                return this._get(b, c);
            });
            $.data(a, PROP_NAME, b);
            this._setDate(b, this._getDefaultDate(b), true);
            this._updateDatepicker(b);
            this._updateAlternate(b);
            b.dpDiv.show();
        },
        _dialogDatepicker: function (a, b, c, d, e) {
            var f = this._dialogInst;
            if (!f) {
                this.uuid += 1;
                var g = "dp" + this.uuid;
                this._dialogInput = $('<input type="text" id="' + g + '" style="position: absolute; top: -100px; width: 0px; z-index: -10;"/>');
                this._dialogInput.keydown(this._doKeyDown);
                $("body").append(this._dialogInput);
                f = this._dialogInst = this._newInst(this._dialogInput, false);
                f.settings = {};
                $.data(this._dialogInput[0], PROP_NAME, f);
            }
            extendRemove(f.settings, d || {});
            b = b && b.constructor == Date ? this._formatDate(f, b) : b;
            this._dialogInput.val(b);
            this._pos = e ? e.length ? e : [e.pageX, e.pageY] : null;
            if (!this._pos) {
                var h = document.documentElement.clientWidth;
                var i = document.documentElement.clientHeight;
                var j = document.documentElement.scrollLeft || document.body.scrollLeft;
                var k = document.documentElement.scrollTop || document.body.scrollTop;
                this._pos = [h / 2 - 100 + j, i / 2 - 150 + k];
            }
            this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px");
            f.settings.onSelect = c;
            this._inDialog = true;
            this.dpDiv.addClass(this._dialogClass);
            this._showDatepicker(this._dialogInput[0]);
            if ($.blockUI) $.blockUI(this.dpDiv);
            $.data(this._dialogInput[0], PROP_NAME, f);
            return this;
        },
        _destroyDatepicker: function (a) {
            var b = $(a);
            var c = $.data(a, PROP_NAME);
            if (!b.hasClass(this.markerClassName)) {
                return;
            }
            var d = a.nodeName.toLowerCase();
            $.removeData(a, PROP_NAME);
            if (d == "input") {
                c.append.remove();
                c.trigger.remove();
                b.removeClass(this.markerClassName).unbind("focus", this._showDatepicker).unbind("keydown", this._doKeyDown).unbind("keypress", this._doKeyPress).unbind("keyup", this._doKeyUp);
            } else if (d == "div" || d == "span") b.removeClass(this.markerClassName).empty();
        },
        _enableDatepicker: function (a) {
            var b = $(a);
            var c = $.data(a, PROP_NAME);
            if (!b.hasClass(this.markerClassName)) {
                return;
            }
            var d = a.nodeName.toLowerCase();
            if (d == "input") {
                a.disabled = false;
                c.trigger.filter("button").each(function () {
                    this.disabled = false;
                }).end().filter("img").css({
                    opacity: "1.0",
                    cursor: ""
                });
            } else if (d == "div" || d == "span") {
                var e = b.children("." + this._inlineClass);
                e.children().removeClass("ui-state-disabled");
            }
            this._disabledInputs = $.map(this._disabledInputs, function (b) {
                return b == a ? null : b;
            });
        },
        _disableDatepicker: function (a) {
            var b = $(a);
            var c = $.data(a, PROP_NAME);
            if (!b.hasClass(this.markerClassName)) {
                return;
            }
            var d = a.nodeName.toLowerCase();
            if (d == "input") {
                a.disabled = true;
                c.trigger.filter("button").each(function () {
                    this.disabled = true;
                }).end().filter("img").css({
                    opacity: "0.5",
                    cursor: "default"
                });
            } else if (d == "div" || d == "span") {
                var e = b.children("." + this._inlineClass);
                e.children().addClass("ui-state-disabled");
            }
            this._disabledInputs = $.map(this._disabledInputs, function (b) {
                return b == a ? null : b;
            });
            this._disabledInputs[this._disabledInputs.length] = a;
        },
        _isDisabledDatepicker: function (a) {
            if (!a) {
                return false;
            }
            for (var b = 0; b < this._disabledInputs.length; b++) {
                if (this._disabledInputs[b] == a) return true;
            }
            return false;
        },
        _getInst: function (a) {
            try {
                return $.data(a, PROP_NAME);
            } catch (b) {
                throw "Missing instance data for this datepicker";
            }
        },
        _optionDatepicker: function (a, b, c) {
            var d = this._getInst(a);
            if (arguments.length == 2 && typeof b == "string") {
                return b == "defaults" ? $.extend({}, $.datepicker._defaults) : d ? b == "all" ? $.extend({}, d.settings) : this._get(d, b) : null;
            }
            var e = b || {};
            if (typeof b == "string") {
                e = {};
                e[b] = c;
            }
            if (d) {
                if (this._curInst == d) {
                    this._hideDatepicker();
                }
                var f = this._getDateDatepicker(a, true);
                var g = this._getMinMaxDate(d, "min");
                var h = this._getMinMaxDate(d, "max");
                extendRemove(d.settings, e);
                if (g !== null && e["dateFormat"] !== undefined && e["minDate"] === undefined) d.settings.minDate = this._formatDate(d, g);
                if (h !== null && e["dateFormat"] !== undefined && e["maxDate"] === undefined) d.settings.maxDate = this._formatDate(d, h);
                this._attachments($(a), d);
                this._autoSize(d);
                this._setDateDatepicker(a, f);
                this._updateDatepicker(d);
            }
        },
        _changeDatepicker: function (a, b, c) {
            this._optionDatepicker(a, b, c);
        },
        _refreshDatepicker: function (a) {
            var b = this._getInst(a);
            if (b) {
                this._updateDatepicker(b);
            }
        },
        _setDateDatepicker: function (a, b) {
            var c = this._getInst(a);
            if (c) {
                this._setDate(c, b);
                this._updateDatepicker(c);
                this._updateAlternate(c);
            }
        },
        _getDateDatepicker: function (a, b) {
            var c = this._getInst(a);
            if (c && !c.inline) this._setDateFromField(c, b);
            return c ? this._getDate(c) : null;
        },
        _doKeyDown: function (a) {
            var b = $.datepicker._getInst(a.target);
            var c = true;
            var d = b.dpDiv.is(".ui-datepicker-rtl");
            b._keyEvent = true;
            if ($.datepicker._datepickerShowing) switch (a.keyCode) {
                case 9:
                    $.datepicker._hideDatepicker();
                    c = false;
                    break;
                case 13:
                    var e = $("td." + $.datepicker._dayOverClass + ":not(." + $.datepicker._currentClass + ")", b.dpDiv);
                    if (e[0]) $.datepicker._selectDay(a.target, b.selectedMonth, b.selectedYear, e[0]);
                    else $.datepicker._hideDatepicker();
                    return false;
                    break;
                case 27:
                    $.datepicker._hideDatepicker();
                    break;
                case 33:
                    $.datepicker._adjustDate(a.target, a.ctrlKey ? -$.datepicker._get(b, "stepBigMonths") : -$.datepicker._get(b, "stepMonths"), "M");
                    break;
                case 34:
                    $.datepicker._adjustDate(a.target, a.ctrlKey ? +$.datepicker._get(b, "stepBigMonths") : +$.datepicker._get(b, "stepMonths"), "M");
                    break;
                case 35:
                    if (a.ctrlKey || a.metaKey) $.datepicker._clearDate(a.target);
                    c = a.ctrlKey || a.metaKey;
                    break;
                case 36:
                    if (a.ctrlKey || a.metaKey) $.datepicker._gotoToday(a.target);
                    c = a.ctrlKey || a.metaKey;
                    break;
                case 37:
                    if (a.ctrlKey || a.metaKey) $.datepicker._adjustDate(a.target, d ? +1 : -1, "D");
                    c = a.ctrlKey || a.metaKey;
                    if (a.originalEvent.altKey) $.datepicker._adjustDate(a.target, a.ctrlKey ? -$.datepicker._get(b, "stepBigMonths") : -$.datepicker._get(b, "stepMonths"), "M");
                    break;
                case 38:
                    if (a.ctrlKey || a.metaKey) $.datepicker._adjustDate(a.target, -7, "D");
                    c = a.ctrlKey || a.metaKey;
                    break;
                case 39:
                    if (a.ctrlKey || a.metaKey) $.datepicker._adjustDate(a.target, d ? -1 : +1, "D");
                    c = a.ctrlKey || a.metaKey;
                    if (a.originalEvent.altKey) $.datepicker._adjustDate(a.target, a.ctrlKey ? +$.datepicker._get(b, "stepBigMonths") : +$.datepicker._get(b, "stepMonths"), "M");
                    break;
                case 40:
                    if (a.ctrlKey || a.metaKey) $.datepicker._adjustDate(a.target, +7, "D");
                    c = a.ctrlKey || a.metaKey;
                    break;
                default:
                    c = false;
            } else if (a.keyCode == 36 && a.ctrlKey) $.datepicker._showDatepicker(this);
            else {
                c = false;
            }
            if (c) {
                a.preventDefault();
                a.stopPropagation();
            }
        },
        _doKeyPress: function (a) {
            var b = $.datepicker._getInst(a.target);
            if ($.datepicker._get(b, "constrainInput")) {
                var c = $.datepicker._possibleChars($.datepicker._get(b, "dateFormat"));
                var d = String.fromCharCode(a.charCode == undefined ? a.keyCode : a.charCode);
                return a.ctrlKey || a.metaKey || d < " " || !c || c.indexOf(d) > -1;
            }
        },
        _doKeyUp: function (a) {
            var b = $.datepicker._getInst(a.target);
            if (b.input.val() != b.lastVal) {
                try {
                    var c = $.datepicker.parseDate($.datepicker._get(b, "dateFormat"), b.input ? b.input.val() : null, $.datepicker._getFormatConfig(b));
                    if (c) {
                        $.datepicker._setDateFromField(b);
                        $.datepicker._updateAlternate(b);
                        $.datepicker._updateDatepicker(b);
                    }
                } catch (a) {
                    $.datepicker.log(a);
                }
            }
            return true
        },
        _showDatepicker: function (a) {
            a = a.target || a;
            if (a.nodeName.toLowerCase() != "input") a = $("input", a.parentNode)[0];
            if ($.datepicker._isDisabledDatepicker(a) || $.datepicker._lastInput == a) return;
            var b = $.datepicker._getInst(a);
            if ($.datepicker._curInst && $.datepicker._curInst != b) {
                $.datepicker._curInst.dpDiv.stop(true, true);
            }
            var c = $.datepicker._get(b, "beforeShow");
            extendRemove(b.settings, c ? c.apply(a, [a, b]) : {});
            b.lastVal = null;
            $.datepicker._lastInput = a;
            $.datepicker._setDateFromField(b);
            if ($.datepicker._inDialog) a.value = "";
            if (!$.datepicker._pos) {
                $.datepicker._pos = $.datepicker._findPos(a);
                $.datepicker._pos[1] += a.offsetHeight;
            }
            var d = false;
            $(a).parents().each(function () {
                d |= $(this).css("position") == "fixed";
                return !d;
            });
            if (d) {
                $.datepicker._pos[0] -= document.documentElement.scrollLeft;
                $.datepicker._pos[1] -= document.documentElement.scrollTop;
            }
            var e = {
                left: $.datepicker._pos[0],
                top: $.datepicker._pos[1]
            };
            if (b.settings.langid == 2) { e.left = $(window).width() - (e.left + b.input.width() + 12); }
            $.datepicker._pos = null;
            b.dpDiv.empty();
            b.dpDiv.css({
                position: "absolute",
                display: "block",
                top: "-1000px"
            });
            $.datepicker._updateDatepicker(b);
            e = $.datepicker._checkOffset(b, e, d);
            var isshowCalenderAtTop = $.datepicker._get(b, "isShowAtTop");
            if (b.settings.langid == 2) {
                b.dpDiv.css({
                    position: $.datepicker._inDialog && $.blockUI ? "static" : d ? "fixed" : "absolute",
                    display: "none",
                    right: e.left + "px",
                    top: e.top - (isshowCalenderAtTop == true ? (201 + $(a).height() + 2) : 0) + "px"
                });
            }
            else {
                b.dpDiv.css({
                    position: $.datepicker._inDialog && $.blockUI ? "static" : d ? "fixed" : "absolute",
                    display: "none",
                    left: e.left + "px",
                    top: e.top - (isshowCalenderAtTop == true ? ($(b.dpDiv).height() + $(a).height() + 2) : 0) + "px"
                });
            }
            if (!b.inline) {
                var f = $.datepicker._get(b, "showAnim");
                var g = $.datepicker._get(b, "duration");
                var h = function () {
                    $.datepicker._datepickerShowing = true;
                    var a = b.dpDiv.find("iframe.ui-datepicker-cover");
                    if (!!a.length) {
                        var c = $.datepicker._getBorders(b.dpDiv);
                        a.css({
                            left: -c[0],
                            top: -c[1],
                            width: b.dpDiv.outerWidth(),
                            height: b.dpDiv.outerHeight()
                        });
                    }
                };
                b.dpDiv.zIndex($(a).zIndex() + 1);
                if ($.effects && $.effects[f]) b.dpDiv.show(f, $.datepicker._get(b, "showOptions"), g, h);
                else b.dpDiv[f || "show"](f ? g : null, h);
                if (!f || !g) h();
                if (b.input.is(":visible") && !b.input.is(":disabled")) b.input.focus();
                $.datepicker._curInst = b;
            }
            setTimeout(function () {
                c = $.datepicker._get(b, "afterShow");
                extendRemove(b.settings, c ? c.apply(a, [a, b]) : {});
            }, 100);
        },
        _updateDatepicker: function (a) {
            var b = this;
            var c = $.datepicker._getBorders(a.dpDiv);
            a.dpDiv.empty().append(this._generateHTML(a));
            if (hijariCheckBoxChecked == false) {
                ShowHijriOptions();
            }
            var d = a.dpDiv.find("iframe.ui-datepicker-cover");
            if (!!d.length) {
                d.css({
                    left: -c[0],
                    top: -c[1],
                    width: a.dpDiv.outerWidth(),
                    height: a.dpDiv.outerHeight()
                });
            }
            a.dpDiv.find("button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a").bind("mouseout", function () {
                $(this).removeClass("ui-state-hover");
                if (this.className.indexOf("ui-datepicker-prev") != -1) $(this).removeClass("ui-datepicker-prev-hover");
                if (this.className.indexOf("ui-datepicker-next") != -1) $(this).removeClass("ui-datepicker-next-hover");
            }).bind("mouseover", function () {
                if (!b._isDisabledDatepicker(a.inline ? a.dpDiv.parent()[0] : a.input[0])) {
                    $(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover");
                    $(this).addClass("ui-state-hover");
                    if (this.className.indexOf("ui-datepicker-prev") != -1) $(this).addClass("ui-datepicker-prev-hover");
                    if (this.className.indexOf("ui-datepicker-next") != -1) $(this).addClass("ui-datepicker-next-hover");
                }
            }).end().find("." + this._dayOverClass + " a").trigger("mouseover").end();
            var e = this._getNumberOfMonths(a);
            var f = e[1];
            var g = 17;
            if (f > 1) {
                a.dpDiv.addClass("ui-datepicker-multi-" + f);
            } else a.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width("");
            a.dpDiv[(e[0] != 1 || e[1] != 1 ? "add" : "remove") + "Class"]("ui-datepicker-multi");
            a.dpDiv[(this._get(a, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl");
            if (a == $.datepicker._curInst && $.datepicker._datepickerShowing && a.input && a.input.is(":visible") && !a.input.is(":disabled") && a.input[0] != document.activeElement) a.input.focus();
            if (a.yearshtml) {
                var h = a.yearshtml;
                setTimeout(function () {
                    if (h === a.yearshtml) {
                        a.dpDiv.find("select.ui-datepicker-year:first").replaceWith(a.yearshtml);
                    }
                    h = a.yearshtml = null;
                    HideDatePickerElements();
                }, 10);
            }
            else {
                setTimeout(HideDatePickerElements, 10);
            }
        },
        _getBorders: function (a) {
            var b = function (a) {
                return {
                    thin: 1,
                    medium: 2,
                    thick: 3
                }[a] || a;
            };
            return [parseFloat(b(a.css("border-left-width"))), parseFloat(b(a.css("border-top-width")))];
        },
        _checkOffset: function (a, b, c) {
            var d = a.dpDiv.outerWidth();
            var e = a.dpDiv.outerHeight();
            var f = a.input ? a.input.outerWidth() : 0;
            var g = a.input ? a.input.outerHeight() : 0;
            var h = document.documentElement.clientWidth + $(document).scrollLeft();
            var i = document.documentElement.clientHeight + $(document).scrollTop();
            b.left -= this._get(a, "isRTL") ? d - f : 0;
            b.left -= c && b.left == a.input.offset().left ? $(document).scrollLeft() : 0;
            b.top -= c && b.top == a.input.offset().top + g ? $(document).scrollTop() : 0;
            b.left -= Math.min(b.left, b.left + d > h && h > d ? Math.abs(b.left + d - h) : 0);
            //     b.top -= Math.min(b.top, b.top + e > i && i > e ? Math.abs(e + g) : 0);
            if (b.left == 0) {
                b.left = ($(document).width() - a.input.offset().left) - a.input.width();
            }
            return b;
        },
        _findPos: function (a) {
            var b = this._getInst(a);
            var c = this._get(b, "isRTL");
            while (a && (a.type == "hidden" || a.nodeType != 1 || $.expr.filters.hidden(a))) {
                a = a[c ? "previousSibling" : "nextSibling"];
            }
            var d = $(a).offset();
            return [d.left, d.top];
        },
        _hideDatepicker: function (a) {
            var b = this._curInst;
            if (!b || a && b != $.data(a, PROP_NAME)) return;
            if (this._datepickerShowing) {
                var c = this._get(b, "showAnim");
                var d = this._get(b, "duration");
                var e = function () {
                    $.datepicker._tidyDialog(b);
                    this._curInst = null;
                };
                if ($.effects && $.effects[c]) b.dpDiv.hide(c, $.datepicker._get(b, "showOptions"), d, e);
                else b.dpDiv[c == "slideDown" ? "slideUp" : c == "fadeIn" ? "fadeOut" : "hide"](c ? d : null, e);
                if (!c) e();
                var f = this._get(b, "onClose");
                if (f) f.apply(b.input ? b.input[0] : null, [b.input ? b.input.val() : "", b]);
                this._datepickerShowing = false;
                this._lastInput = null;
                if (this._inDialog) {
                    this._dialogInput.css({
                        position: "absolute",
                        left: "0",
                        top: "-100px"
                    });
                    if ($.blockUI) {
                        $.unblockUI();
                        $("body").append(this.dpDiv);
                    }
                }
                this._inDialog = false;
            }
        },
        _tidyDialog: function (a) {
            a.dpDiv.removeClass(this._dialogClass).unbind(".ui-datepicker-calendar");
        },
        _checkExternalClick: function (a) {
            if (!$.datepicker._curInst) return;
            var b = $(a.target);
            if (b[0].id != $.datepicker._mainDivId && b.parents("#" + $.datepicker._mainDivId).length == 0 && !b.hasClass($.datepicker.markerClassName) && !b.hasClass($.datepicker._triggerClass) && $.datepicker._datepickerShowing && !($.datepicker._inDialog && $.blockUI)) $.datepicker._hideDatepicker();
        },
        _adjustDate: function (a, b, c) {
            var d = $(a);
            var e = this._getInst(d[0]);
            if (this._isDisabledDatepicker(d[0])) {
                return;
            }
            this._adjustInstDate(e, b + (c == "M" ? this._get(e, "showCurrentAtPos") : 0), c);
            this._updateDatepicker(e);
        },
        _gotoToday: function (a) {
            var b = $(a);
            var c = this._getInst(b[0]);
            if (this._get(c, "gotoCurrent") && c.currentDay) {
                c.selectedDay = c.currentDay;
                c.drawMonth = c.selectedMonth = c.currentMonth;
                c.drawYear = c.selectedYear = c.currentYear;
            } else {
                var d = new Date;
                c.selectedDay = d.getDate();
                c.drawMonth = c.selectedMonth = d.getMonth();
                c.drawYear = c.selectedYear = d.getFullYear();
            }
            this._notifyChange(c);
            this._adjustDate(b);
        },
        _selectMonthYear: function (a, b, c) {
            var d = $(a);
            var e = this._getInst(d[0]);
            e._selectingMonthYear = false;
            e["selected" + (c == "M" ? "Month" : "Year")] = e["draw" + (c == "M" ? "Month" : "Year")] = parseInt(b.options[b.selectedIndex].value, 10);
            this._notifyChange(e);
            this._adjustDate(d);
        },
        _clickMonthYear: function (a) {
            var b = $(a);
            var c = this._getInst(b[0]);
            if (c.input && c._selectingMonthYear) {
                setTimeout(function () {
                    c.input.focus();
                }, 0);
            }
            c._selectingMonthYear = !c._selectingMonthYear;
        },
        _selectDay: function (a, b, c, d) {
            var e = $(a);
            if ($(d).hasClass(this._unselectableClass) || this._isDisabledDatepicker(e[0])) {
                return;
            }
            var f = this._getInst(e[0]);
            f.selectedDay = f.currentDay = $("a", d).html();
            f.selectedMonth = f.currentMonth = b;
            f.selectedYear = f.currentYear = c;
            this._selectDate(a, this._formatDate(f, f.currentDay, f.currentMonth, f.currentYear));
        },
        _clearDate: function (a) {
            var b = $(a);
            var c = this._getInst(b[0]);
            this._selectDate(b, "");
        },
        _selectDate: function (a, b) {
            var c = $(a);
            var d = this._getInst(c[0]);
            b = b != null ? b : this._formatDate(d);
            if (d.input) d.input.val(b);
            this._updateAlternate(d);
            var e = this._get(d, "onSelect");
            if (e) e.apply(d.input ? d.input[0] : null, [b, d]);
            else if (d.input) d.input.trigger("change");
            if (d.inline) this._updateDatepicker(d);
            else {
                this._hideDatepicker();
                this._lastInput = d.input[0];
                if (typeof d.input[0] != "object") d.input.focus();
                this._lastInput = null;
            }
        },
        _updateAlternate: function (a) {
            var b = this._get(a, "altField");
            if (b) {
                var c = this._get(a, "altFormat") || this._get(a, "dateFormat");
                var d = this._getDate(a);
                var e = this.formatDate(c, d, this._getFormatConfig(a));
                $(b).each(function () {
                    $(this).val(e);
                });
            }
        },
        noWeekends: function (a) {
            var b = a.getDay();
            return [b > 0 && b < 6, ""];
        },
        iso8601Week: function (a) {
            var b = new Date(a.getTime());
            b.setDate(b.getDate() + 4 - (b.getDay() || 7));
            var c = b.getTime();
            b.setMonth(0);
            b.setDate(1);
            return Math.floor(Math.round((c - b) / 864e5) / 7) + 1;
        },
        parseDate: function (a, b, c) {
            if (a == null || b == null) throw "Invalid arguments";
            b = typeof b == "object" ? b.toString() : b + "";
            if (b == "") return null;
            var d = (c ? c.shortYearCutoff : null) || this._defaults.shortYearCutoff;
            d = typeof d != "string" ? d : (new Date).getFullYear() % 100 + parseInt(d, 10);
            var e = (c ? c.dayNamesShort : null) || this._defaults.dayNamesShort;
            var f = (c ? c.dayNames : null) || this._defaults.dayNames;
            var g = (c ? c.monthNamesShort : null) || this._defaults.monthNamesShort;
            var h = (c ? c.monthNames : null) || this._defaults.monthNames;
            var i = -1;
            var j = -1;
            var k = -1;
            var l = -1;
            var m = false;
            var n = function (b) {
                var c = s + 1 < a.length && a.charAt(s + 1) == b;
                if (c) s++;
                return c;
            };
            var o = function (a) {
                var c = n(a);
                var d = a == "@" ? 14 : a == "!" ? 20 : a == "y" && c ? 4 : a == "o" ? 3 : 2;
                var e = new RegExp("^\\d{1," + d + "}");
                var f = b.substring(r).match(e);
                if (!f) throw "Missing number at position " + r;
                r += f[0].length;
                return parseInt(f[0], 10);
            };
            var p = function (a, c, d) {
                var e = n(a) ? d : c;
                for (var f = 0; f < e.length; f++) {
                    if (b.substr(r, e[f].length).toLowerCase() == e[f].toLowerCase()) {
                        r += e[f].length;
                        return f + 1;
                    }
                }
                throw "Unknown name at position " + r;
            };
            var q = function () {
                if (b.charAt(r) != a.charAt(s)) throw "Unexpected literal at position " + r;
                r++;
            };
            var r = 0;
            for (var s = 0; s < a.length; s++) {
                if (m) if (a.charAt(s) == "'" && !n("'")) m = false;
                else q();
                else switch (a.charAt(s)) {
                    case "d":
                        k = o("d");
                        break;
                    case "D":
                        p("D", e, f);
                        break;
                    case "o":
                        l = o("o");
                        break;
                    case "m":
                        j = o("m");
                        break;
                    case "M":
                        j = p("M", g, h);
                        break;
                    case "y":
                        i = o("y");
                        break;
                    case "@":
                        var t = new Date(o("@"));
                        i = t.getFullYear();
                        j = t.getMonth() + 1;
                        k = t.getDate();
                        break;
                    case "!":
                        var t = new Date((o("!") - this._ticksTo1970) / 1e4);
                        i = t.getFullYear();
                        j = t.getMonth() + 1;
                        k = t.getDate();
                        break;
                    case "'":
                        if (n("'")) q();
                        else m = true;
                        break;
                    default:
                        q();
                }
            }
            if (i == -1) i = (new Date).getFullYear();
            else if (i < 100) i += (new Date).getFullYear() - (new Date).getFullYear() % 100 + (i <= d ? 0 : -100);
            if (l > -1) {
                j = 1;
                k = l;
                do {
                    var u = this._getDaysInMonth(i, j - 1);
                    if (k <= u) break;
                    j++;
                    k -= u;
                } while (true);
            }
            var t = this._daylightSavingAdjust(new Date(i, j - 1, k));
            if (t.getFullYear() != i || t.getMonth() + 1 != j || t.getDate() != k) throw "Invalid date";
            return t;
        },
        ATOM: "yy-mm-dd",
        COOKIE: "D, dd M yy",
        ISO_8601: "yy-mm-dd",
        RFC_822: "D, d M y",
        RFC_850: "DD, dd-M-y",
        RFC_1036: "D, d M y",
        RFC_1123: "D, d M yy",
        RFC_2822: "D, d M yy",
        RSS: "D, d M y",
        TICKS: "!",
        TIMESTAMP: "@",
        W3C: "yy-mm-dd",
        _ticksTo1970: ((1970 - 1) * 365 + Math.floor(1970 / 4) - Math.floor(1970 / 100) + Math.floor(1970 / 400)) * 24 * 60 * 60 * 1e7,
        formatDate: function (a, b, c) {
            if (!b) return "";
            var d = (c ? c.dayNamesShort : null) || this._defaults.dayNamesShort;
            var e = (c ? c.dayNames : null) || this._defaults.dayNames;
            var f = (c ? c.monthNamesShort : null) || this._defaults.monthNamesShort;
            var g = (c ? c.monthNames : null) || this._defaults.monthNames;
            var h = function (b) {
                var c = m + 1 < a.length && a.charAt(m + 1) == b;
                if (c) m++;
                return c;
            };
            var i = function (a, b, c) {
                var d = "" + b;
                if (h(a)) while (d.length < c) d = "0" + d;
                return d;
            };
            var j = function (a, b, c, d) {
                return h(a) ? d[b] : c[b];
            };
            var k = "";
            var l = false;
            if (b) for (var m = 0; m < a.length; m++) {
                if (l) if (a.charAt(m) == "'" && !h("'")) l = false;
                else k += a.charAt(m);
                else switch (a.charAt(m)) {
                    case "d":
                        k += i("d", b.getDate(), 2);
                        break;
                    case "D":
                        k += j("D", b.getDay(), d, e);
                        break;
                    case "o":
                        k += i("o", (b.getTime() - (new Date(b.getFullYear(), 0, 0)).getTime()) / 864e5, 3);
                        break;
                    case "m":
                        k += i("m", b.getMonth() + 1, 2);
                        break;
                    case "M":
                        k += j("M", b.getMonth(), f, g);
                        break;
                    case "y":
                        k += h("y") ? b.getFullYear() : (b.getYear() % 100 < 10 ? "0" : "") + b.getYear() % 100;
                        break;
                    case "@":
                        k += b.getTime();
                        break;
                    case "!":
                        k += b.getTime() * 1e4 + this._ticksTo1970;
                        break;
                    case "'":
                        if (h("'")) k += "'";
                        else l = true;
                        break;
                    default:
                        k += a.charAt(m);
                }
            }
            return k;
        },
        _possibleChars: function (a) {
            var b = "";
            var c = false;
            var d = function (b) {
                var c = e + 1 < a.length && a.charAt(e + 1) == b;
                if (c) e++;
                return c;
            };
            for (var e = 0; e < a.length; e++) if (c) if (a.charAt(e) == "'" && !d("'")) c = false;
            else b += a.charAt(e);
            else switch (a.charAt(e)) {
                case "d":
                case "m":
                case "y":
                case "@":
                    b += "0123456789";
                    break;
                case "D":
                case "M":
                    return null;
                case "'":
                    if (d("'")) b += "'";
                    else c = true;
                    break;
                default:
                    b += a.charAt(e);
            }
            return b;
        },
        _get: function (a, b) {
            return a.settings[b] !== undefined ? a.settings[b] : this._defaults[b];
        },
        _setDateFromField: function (a, b) {
            if (a.input.val() == a.lastVal) {
                return;
            }
            var c = this._get(a, "dateFormat");
            var d = a.lastVal = a.input ? a.input.val() : null;
            var e, f;
            e = f = this._getDefaultDate(a);
            var g = this._getFormatConfig(a);
            try {
                e = this.parseDate(c, d, g) || f;
            } catch (h) {
                this.log(h);
                d = b ? "" : d;
            }
            a.selectedDay = e.getDate();
            a.drawMonth = a.selectedMonth = e.getMonth();
            a.drawYear = a.selectedYear = e.getFullYear();
            a.currentDay = d ? e.getDate() : 0;
            a.currentMonth = d ? e.getMonth() : 0;
            a.currentYear = d ? e.getFullYear() : 0;
            this._adjustInstDate(a);
        },
        _getDefaultDate: function (a) {
            return this._restrictMinMax(a, this._determineDate(a, this._get(a, "defaultDate"), new Date));
        },
        _determineDate: function (a, b, c) {
            var d = function (a) {
                var b = new Date;
                b.setDate(b.getDate() + a);
                return b;
            };
            var e = function (b) {
                try {
                    return $.datepicker.parseDate($.datepicker._get(a, "dateFormat"), b, $.datepicker._getFormatConfig(a));
                } catch (c) { }
                var d = (b.toLowerCase().match(/^c/) ? $.datepicker._getDate(a) : null) || new Date;
                var e = d.getFullYear();
                var f = d.getMonth();
                var g = d.getDate();
                var h = /([+-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g;
                var i = h.exec(b);
                while (i) {
                    switch (i[2] || "d") {
                        case "d":
                        case "D":
                            g += parseInt(i[1], 10);
                            break;
                        case "w":
                        case "W":
                            g += parseInt(i[1], 10) * 7;
                            break;
                        case "m":
                        case "M":
                            f += parseInt(i[1], 10);
                            g = Math.min(g, $.datepicker._getDaysInMonth(e, f));
                            break;
                        case "y":
                        case "Y":
                            e += parseInt(i[1], 10);
                            g = Math.min(g, $.datepicker._getDaysInMonth(e, f));
                            break;
                    }
                    i = h.exec(b);
                }
                return new Date(e, f, g);
            };
            var f = b == null || b === "" ? c : typeof b == "string" ? e(b) : typeof b == "number" ? isNaN(b) ? c : d(b) : new Date(b.getTime());
            f = f && f.toString() == "Invalid Date" ? c : f;
            if (f) {
                f.setHours(0);
                f.setMinutes(0);
                f.setSeconds(0);
                f.setMilliseconds(0);
            }
            return this._daylightSavingAdjust(f);
        },
        _daylightSavingAdjust: function (a) {
            if (!a) return null;
            a.setHours(a.getHours() > 12 ? a.getHours() + 2 : 0);
            return a;
        },
        _setDate: function (a, b, c) {
            var d = !b;
            var e = a.selectedMonth;
            var f = a.selectedYear;
            var g = this._restrictMinMax(a, this._determineDate(a, b, new Date));
            a.selectedDay = a.currentDay = g.getDate();
            a.drawMonth = a.selectedMonth = a.currentMonth = g.getMonth();
            a.drawYear = a.selectedYear = a.currentYear = g.getFullYear();
            if ((e != a.selectedMonth || f != a.selectedYear) && !c) this._notifyChange(a);
            this._adjustInstDate(a);
            if (a.input) {
                a.input.val(d ? "" : this._formatDate(a));
            }
        },
        _getDate: function (a) {
            var b = !a.currentYear || a.input && a.input.val() == "" ? null : this._daylightSavingAdjust(new Date(a.currentYear, a.currentMonth, a.currentDay));
            return b;
        },
        _generateHTML: function (a) {
            var b = new Date;
            b = this._daylightSavingAdjust(new Date(b.getFullYear(), b.getMonth(), b.getDate()));
            var c = this._get(a, "isRTL");
            var d = this._get(a, "showButtonPanel");
            var e = this._get(a, "hideIfNoPrevNext");
            var f = this._get(a, "navigationAsDateFormat");
            var g = this._getNumberOfMonths(a);
            var h = this._get(a, "showCurrentAtPos");
            var i = this._get(a, "stepMonths");
            var j = g[0] != 1 || g[1] != 1;
            var k = this._daylightSavingAdjust(!a.currentDay ? new Date(9999, 9, 9) : new Date(a.currentYear, a.currentMonth, a.currentDay));
            var l = this._getMinMaxDate(a, "min");
            var m = this._getMinMaxDate(a, "max");
            var n = a.drawMonth - h;
            var o = a.drawYear;
            if (n < 0) {
                n += 12;
                o--;
            }
            if (m) {
                var p = this._daylightSavingAdjust(new Date(m.getFullYear(), m.getMonth() - g[0] * g[1] + 1, m.getDate()));
                p = l && p < l ? l : p;
                while (this._daylightSavingAdjust(new Date(o, n, 1)) > p) {
                    n--;
                    if (n < 0) {
                        n = 11;
                        o--;
                    }
                }
            }
            a.drawMonth = n;
            a.drawYear = o;
            var q = this._get(a, "prevText");
            q = !f ? q : this.formatDate(q, this._daylightSavingAdjust(new Date(o, n - i, 1)), this._getFormatConfig(a));
            var r = this._canAdjustMonth(a, -1, o, n) ? '<a class="ui-datepicker-prev ui-corner-all" onclick="DP_jQuery_' + dpuuid + ".datepicker._adjustDate('#" + a.id + "', -" + i + ", 'M');\"" + ' title="' + q + '"><span class="ui-icon ui-icon-circle-triangle-' + (c ? "e" : "w") + '">' + q + "</span></a>" : e ? "" : '<a class="ui-datepicker-prev ui-corner-all ui-state-disabled" title="' + q + '"><span class="ui-icon ui-icon-circle-triangle-' + (c ? "e" : "w") + '">' + q + "</span></a>";
            var s = this._get(a, "nextText");
            s = !f ? s : this.formatDate(s, this._daylightSavingAdjust(new Date(o, n + i, 1)), this._getFormatConfig(a));
            var t = this._canAdjustMonth(a, +1, o, n) ? '<a class="ui-datepicker-next ui-corner-all" onclick="DP_jQuery_' + dpuuid + ".datepicker._adjustDate('#" + a.id + "', +" + i + ", 'M');\"" + ' title="' + s + '"><span class="ui-icon ui-icon-circle-triangle-' + (c ? "w" : "e") + '">' + s + "</span></a>" : e ? "" : '<a class="ui-datepicker-next ui-corner-all ui-state-disabled" title="' + s + '"><span class="ui-icon ui-icon-circle-triangle-' + (c ? "w" : "e") + '">' + s + "</span></a>";
            var u = this._get(a, "currentText");
            var v = this._get(a, "gotoCurrent") && a.currentDay ? k : b;
            u = !f ? u : this.formatDate(u, v, this._getFormatConfig(a));
            var w = !a.inline ? '<button type="button" class="ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all" onclick="DP_jQuery_' + dpuuid + '.datepicker._hideDatepicker();">' + this._get(a, "closeText") + "</button>" : "";
            var x = d ? '<div class="ui-datepicker-buttonpane ui-widget-content">' + (c ? w : "") + (this._isInRange(a, v) ? '<button type="button" class="ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all" onclick="DP_jQuery_' + dpuuid + ".datepicker._gotoToday('#" + a.id + "');\"" + ">" + u + "</button>" : "") + (c ? "" : w) + "</div>" : "";
            var y = parseInt(this._get(a, "firstDay"), 10);
            y = isNaN(y) ? 0 : y;
            var z = this._get(a, "showWeek");
            var A = this._get(a, "dayNames");
            var B = this._get(a, "dayNamesShort");
            var C;
            if (this._get(a, "langid") == 2) {
                C = this._get(a, "dayNamesMinar");
            } else {
                C = this._get(a, "dayNamesMin");
            }
            var D = this._get(a, "monthNames");
            var E = this._get(a, "monthNamesShort");
            var F = this._get(a, "beforeShowDay");
            var G = this._get(a, "showOtherMonths");
            var H = this._get(a, "selectOtherMonths");
            var I = this._get(a, "calculateWeek") || this.iso8601Week;
            var J = this._getDefaultDate(a);
            var K = "";
            for (var L = 0; L < g[0]; L++) {
                var M = "";
                for (var N = 0; N < g[1]; N++) {
                    var O = this._daylightSavingAdjust(new Date(o, n, a.selectedDay));
                    var P = " ui-corner-all";
                    var Q = "";
                    if (j) {
                        Q += '<div class="ui-datepicker-group';
                        if (g[1] > 1) switch (N) {
                            case 0:
                                Q += " ui-datepicker-group-first";
                                P = " ui-corner-" + (c ? "right" : "left");
                                break;
                            case g[1] - 1:
                                Q += " ui-datepicker-group-last";
                                P = " ui-corner-" + (c ? "left" : "right");
                                break;
                            default:
                                Q += " ui-datepicker-group-middle";
                                P = "";
                                break;
                        }
                        Q += '">';
                    }
                    Q += '<div class="ui-datepicker-header ui-widget-header ui-helper-clearfix' + P + '">' + (/all|left/.test(P) && L == 0 ? c ? t : r : "") + (/all|right/.test(P) && L == 0 ? c ? r : t : "") + this._generateMonthYearHeader(a, n, o, l, m, L > 0 || N > 0, D, E) + '</div><table class="ui-datepicker-calendar"><thead>' + "<tr>";
                    var R = z ? '<th class="ui-datepicker-week-col">' + this._get(a, "weekHeader") + "</th>" : "";
                    for (var S = 0; S < 7; S++) {
                        var T = (S + y) % 7;
                        R += "<th" + ((S + y + 6) % 7 >= 5 ? ' class="ui-datepicker-week-end"' : "") + ">" + '<span title="' + A[T] + '">' + C[T] + "</span></th>";
                    }
                    Q += R + "</tr></thead><tbody>";
                    var U = this._getDaysInMonth(o, n);
                    if (o == a.selectedYear && n == a.selectedMonth) a.selectedDay = Math.min(a.selectedDay, U);
                    var V = (this._getFirstDayOfMonth(o, n) - y + 7) % 7;
                    var W = j ? 6 : Math.ceil((V + U) / 7);
                    var X = this._daylightSavingAdjust(new Date(o, n, 1 - V));
                    var Y = 0;
                    var Z = 0;
                    var _ = 0;
                    var ba = 0;
                    for (var bb = 0; bb < W; bb++) {
                        Q += "<tr>";
                        var bc = !z ? "" : '<td class="ui-datepicker-week-col">' + this._get(a, "calculateWeek")(X) + "</td>";
                        for (var S = 0; S < 7; S++) {
                            Z = X.getDate() - 1;
                            Y = X.getMonth();
                            _ = X.getFullYear();
                            if (HijaryYear[_] != null) {
                                ba = HijaryYear[_][Y][Z];
                            } else {
                                ba = "";
                            }
                            if (ba == null) {
                                ba = "";
                            }
                            var bd = F ? F.apply(a.input ? a.input[0] : null, [X]) : [true, ""];
                            var be = X.getMonth() != n;
                            var bf = be && !H || !bd[0] || l && X < l || m && X > m;
                            bc += '<td class="' + ((S + y + 6) % 7 >= 5 ? " ui-datepicker-week-end" : "") + (be ? " ui-datepicker-other-month" : "") + (X.getTime() == O.getTime() && n == a.selectedMonth && a._keyEvent || J.getTime() == X.getTime() && J.getTime() == O.getTime() ? " " + this._dayOverClass : "") + (bf ? " " + this._unselectableClass + " ui-state-disabled" : "") + (be && !G ? "" : " " + bd[1] + (X.getTime() == k.getTime() ? " " + this._currentClass : "") + (X.getTime() == b.getTime() ? " ui-datepicker-today" : "")) + '"' + ((!be || G) && bd[2] ? ' title="' + bd[2] + '"' : "") + (bf ? "" : ' onclick="DP_jQuery_' + dpuuid + ".datepicker._selectDay('#" + a.id + "'," + X.getMonth() + "," + X.getFullYear() + ', this);return false;"') + ">" + (be && !G ? "&#xa0;" : bf ? '<span class="ui-state-default">' + X.getDate() + "</span>" : '<span class="' + (X.getTime() == b.getTime() ? " ui-state-highlight" : "") + (X.getTime() == k.getTime() ? " ui-state-active" : "") + (be ? " ui-priority-secondary" : "") + ' hijariselectedday" >' + '<a class="ui-state-default" href="#">' + X.getDate() + '</a>' + (ba == "" ? "" : '<span class="nexthijari">(' + ba + ')</span>')) + "</span></td>";
                            X.setDate(X.getDate() + 1);
                            X = this._daylightSavingAdjust(X);
                        }
                        Q += bc + "</tr>";
                    }
                    if (ba != "") {
                        /*if (N == 0) {
                            Q += "<tr><td colspan='7' class='hijrioption'><input type='checkbox' id='chkshowhijri' name='chkshowhijri' checked onclick='javascript:showHideHijriValues(this);' /><label for='chkshowhijri'>" + showhijaritext[this._get(a, "langid")-1] + "</label></td></tr>";
                        } else {
                            Q += "<tr><td colspan='7' class='hijrioption'><span style='visibility:hidden;'><input type='checkbox' id='chkshowhijri' name='chkshowhijri' checked onclick='javascript:showHideHijriValues(this);' /><label for='chkshowhijri'>" + showhijaritext[this._get(a, "langid") - 1] + "</label></span></td></tr>";
                        }*/
                    }
                    n++;
                    if (n > 11) {
                        n = 0;
                        o++;
                    }
                    Q += "</tbody></table>" + (j ? "</div>" + (g[0] > 0 && N == g[1] - 1 ? '<div class="ui-datepicker-row-break"></div>' : "") : "");
                    M += Q;
                }
                K += M;
            }
            K += x + "";
            a._keyEvent = false;
            return K;
        },
        _generateMonthYearHeader: function (a, b, c, d, e, f, g, h) {

            var i = this._get(a, "changeMonth");
            var j = this._get(a, "changeYear");
            var k = this._get(a, "showMonthAfterYear");
            var l = '<div class="ui-datepicker-title">';
            var m = "";
            var n = true;
            if (HijaryYear[c] != null && HijaryYear[c]["month"] != null) {
                if (this._get(a, "langid") == 2) {
                    g = HijaryYear[c]["Hijrimonth"];
                } else {
                    g = HijaryYear[c]["month"];
                }
                n = false;
            }
            if (f || !i) {
                var o = g[b].split("/");

                m += '<span class="ui-datepicker-month hijrimonthtext" ><span class="ui-grdday">' + o[0] + '</span></span>';
            } else {
                var p = d && d.getFullYear() == c;
                var q = e && e.getFullYear() == c;
                var o = g[b].split("/");
                m += '<select class="ui-datepicker-month" ' + 'onchange="DP_jQuery_' + dpuuid + ".datepicker._selectMonthYear('#" + a.id + "', this, 'M');\" " + 'onclick="DP_jQuery_' + dpuuid + ".datepicker._clickMonthYear('#" + a.id + "');\"" + ">";
                for (var r = 0; r < 12; r++) {
                    if ((!p || r >= d.getMonth()) && (!q || r <= e.getMonth())) {
                        var tmpM = g[r].split('/');
                        tmpM = (tmpM && this._get(a, "langid") == 2 && tmpM.length == 2 ? tmpM[0].substring(0, tmpM[0].length - 5) : h[r]);
                        m += '<option value="' + r + '"' + (r == b ? ' selected="selected"' : "") + ">" + tmpM + "</option>";
                    }
                }
                m += '</select>';
            }
            if (!k) l += m + (f || !(i && j) ? "&#xa0;" : "");
            a.yearshtml = "";
            if (f || !j) {
                if (n == true) {
                    l += '<span class="ui-datepicker-year">' + c + '</span>';
                }
            } else {
                var s = this._get(a, "yearRange").split(":");
                var t = (new Date).getFullYear();
                var u = function (a) {
                    var b = a.match(/c[+-].*/) ? c + parseInt(a.substring(1), 10) : a.match(/[+-].*/) ? t + parseInt(a, 10) : parseInt(a, 10);
                    return isNaN(b) ? t : b;
                };
                var v = u(s[0]);
                var w = Math.max(v, u(s[1] || ""));
                v = d ? Math.max(v, d.getFullYear()) : v;
                w = e ? Math.min(w, e.getFullYear()) : w;
                a.yearshtml += '<select class="ui-datepicker-year" ' + 'onchange="DP_jQuery_' + dpuuid + ".datepicker._selectMonthYear('#" + a.id + "', this, 'Y');\" " + 'onclick="DP_jQuery_' + dpuuid + ".datepicker._clickMonthYear('#" + a.id + "');\"" + ">";
                for (; v <= w; v++) {
                    a.yearshtml += '<option value="' + v + '"' + (v == c ? ' selected="selected"' : "") + ">" + v + "</option>";
                }
                a.yearshtml += "</select>";

                l += '<select class="ui-datepicker-year"><option value="' + c + '" selected="selected">' + c + "</option></select>";
            }

            l += this._get(a, "yearSuffix");
            if (k) l += (f || !(i && j) ? "&#xa0;" : "") + m;
           
            return l;
        },
        _adjustInstDate: function (a, b, c) {
            var d = a.drawYear + (c == "Y" ? b : 0);
            var e = a.drawMonth + (c == "M" ? b : 0);
            var f = Math.min(a.selectedDay, this._getDaysInMonth(d, e)) + (c == "D" ? b : 0);
            var g = this._restrictMinMax(a, this._daylightSavingAdjust(new Date(d, e, f)));
            a.selectedDay = g.getDate();
            a.drawMonth = a.selectedMonth = g.getMonth();
            a.drawYear = a.selectedYear = g.getFullYear();
            if (c == "M" || c == "Y") this._notifyChange(a);
        },
        _restrictMinMax: function (a, b) {
            var c = this._getMinMaxDate(a, "min");
            var d = this._getMinMaxDate(a, "max");
            var e = c && b < c ? c : b;
            e = d && e > d ? d : e;
            return e;
        },
        _notifyChange: function (a) {
            var b = this._get(a, "onChangeMonthYear");
            if (b) b.apply(a.input ? a.input[0] : null, [a.selectedYear, a.selectedMonth + 1, a]);
        },
        _getNumberOfMonths: function (a) {
            var b = this._get(a, "numberOfMonths");
            return b == null ? [1, 1] : typeof b == "number" ? [1, b] : b;
        },
        _getMinMaxDate: function (a, b) {
            return this._determineDate(a, this._get(a, b + "Date"), null);
        },
        _getDaysInMonth: function (a, b) {
            return 32 - this._daylightSavingAdjust(new Date(a, b, 32)).getDate();
        },
        _getFirstDayOfMonth: function (a, b) {
            return (new Date(a, b, 1)).getDay();
        },
        _canAdjustMonth: function (a, b, c, d) {
            var e = this._getNumberOfMonths(a);
            var f = this._daylightSavingAdjust(new Date(c, d + (b < 0 ? b : e[0] * e[1]), 1));
            if (b < 0) f.setDate(this._getDaysInMonth(f.getFullYear(), f.getMonth()));
            return this._isInRange(a, f);
        },
        _isInRange: function (a, b) {
            var c = this._getMinMaxDate(a, "min");
            var d = this._getMinMaxDate(a, "max");
            return (!c || b.getTime() >= c.getTime()) && (!d || b.getTime() <= d.getTime());
        },
        _getFormatConfig: function (a) {
            var b = this._get(a, "shortYearCutoff");
            b = typeof b != "string" ? b : (new Date).getFullYear() % 100 + parseInt(b, 10);
            return {
                shortYearCutoff: b,
                dayNamesShort: this._get(a, "dayNamesShort"),
                dayNames: this._get(a, "dayNames"),
                monthNamesShort: this._get(a, "monthNamesShort"),
                monthNames: this._get(a, "monthNames")
            };
        },
        _formatDate: function (a, b, c, d) {
            if (!b) {
                a.currentDay = a.selectedDay;
                a.currentMonth = a.selectedMonth;
                a.currentYear = a.selectedYear;
            }
            var e = b ? typeof b == "object" ? b : this._daylightSavingAdjust(new Date(d, c, b)) : this._daylightSavingAdjust(new Date(a.currentYear, a.currentMonth, a.currentDay));
            return this.formatDate(this._get(a, "dateFormat"), e, this._getFormatConfig(a));
        }
    });
    $.fn.datepicker = function (a) {
        if (!this.length) {
            return this;
        }

        if (!$.datepicker.initialized) {
            $(document).mousedown($.datepicker._checkExternalClick).find("body").append($.datepicker.dpDiv);
            $.datepicker.initialized = true;
        }
        var b = Array.prototype.slice.call(arguments, 1);
        if (typeof a == "string" && (a == "isDisabled" || a == "getDate" || a == "widget")) return $.datepicker["_" + a + "Datepicker"].apply($.datepicker, [this[0]].concat(b));
        if (a == "option" && arguments.length == 2 && typeof arguments[1] == "string") return $.datepicker["_" + a + "Datepicker"].apply($.datepicker, [this[0]].concat(b));
        return this.each(function () {
            typeof a == "string" ? $.datepicker["_" + a + "Datepicker"].apply($.datepicker, [this].concat(b)) : $.datepicker._attachDatepicker(this, a);
        });
    }
    $.datepicker = new Datepicker(); // singleton instance
    $.datepicker.initialized = false;
    $.datepicker.uuid = new Date().getTime();
    $.datepicker.version = "1.8.11";
    window['DP_jQuery_' + dpuuid] = $;
})(jQuery);

function showHideHijriValues(chkHijri) {
    if (chkHijri.checked == false) { hijariCheckBoxChecked = false; $('.nexthijari').css("visibility", "hidden"); $('.previoushijari').css("visibility", "hidden"); $('.hijrimonthtext').css("visibility", "hidden"); }
    else { $('.nexthijari').css("visibility", "visible"); $('.previoushijari').css("visibility", "visible"); hijariCheckBoxChecked = true; $('.ui-datepicker-month').css("visibility", "visible"); }
}
function ShowHijriOptions() {
    var chkhijri = $('td.hijrioption input[type=checkbox]');
    if (hijariCheckBoxChecked == false) { $('.nexthijari').css("visibility", "hidden"); $('.previoushijari').css("visibility", "hidden"); $('.hijrimonthtext').css("visibility", "hidden"); }
    else {
        $('.nexthijari').css("visibility", "visible"); $('.previoushijari').css("visibility", "visible");
        $('.ui-datepicker-month').css("visibility", "visible");
    }
    if (chkhijri.length > 0) { chkhijri[0].checked = hijariCheckBoxChecked; }
}
var HijaryYear =
{
 
};
function DateAdd(a, b, c) {
    if (typeof a == "string") {
        var d = (a.split("-")[0]);
        var e = (a.split("-")[1]);
        var f = (a.split("-")[2]);
        a = new Date(e + "/" + f + "/" + d);
        if (isNaN(a)) {
            throw "DateAdd: Date is not a valid date";
        }
    } else if (typeof a != "object" || a.constructor.toString().indexOf("Date()") == -1) {
        throw "DateAdd: First parameter must be a date object";
    }
    if (b != "M" && b != "D" && b != "Y" && b != "h" && b != "m" && b != "uM" && b != "uD" && b != "uY" && b != "uh" && b != "um" && b != "us") {
        throw "DateAdd: Second parameter must be M, D, Y, h, m, uM, uD, uY, uh, um or us";
    }
    if (typeof c != "number") {
        throw "DateAdd: Third parameter must be a number";
    }
    switch (b) {
        case "M":
            a.setMonth(parseInt(a.getMonth()) + parseInt(c));
            break;
        case "D":
            a.setDate(parseInt(a.getDate()) + parseInt(c));
            break;
        case "Y":
            a.setYear(parseInt(a.getYear()) + parseInt(c));
            break;
        case "h":
            a.setHours(parseInt(a.getHours()) + parseInt(c));
            break;
        case "m":
            a.setMinutes(parseInt(a.getMinutes()) + parseInt(c));
            break;
        case "s":
            a.setSeconds(parseInt(a.getSeconds()) + parseInt(c));
            break;
        case "uM":
            a.setUTCMonth(parseInt(a.getUTCMonth()) + parseInt(c));
            break;
        case "uD":
            a.setUTCDate(parseInt(a.getUTCDate()) + parseInt(c));
            break;
        case "uY":
            a.setUTCFullYear(parseInt(a.getUTCFullYear()) + parseInt(c));
            break;
        case "uh":
            a.setUTCHours(parseInt(a.getUTCHours()) + parseInt(c));
            break;
        case "um":
            a.setUTCMinutes(parseInt(a.getUTCMinutes()) + parseInt(c));
            break;
        case "us":
            a.setUTCSeconds(parseInt(a.getUTCSeconds()) + parseInt(c));
            break;
    }
    var d = a.getUTCFullYear();
    var e = a.getMonth() + 1;
    var f = a.getDate();
    if (e < 10) {
        e = "0" + e;
    }
    if (f < 10) {
        f = "0" + f;
    }
    if (e == f && e == 1) {
        d = d + 1;
    }
    return d + "-" + e + "-" + f;
}
function applyDatePicker() {
    var langid = parseInt(LangId);
    if (langid == 0) langid = 1;
    var date = new Date();
    var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
    $(".calendar").each(function () {
        if ($(this).hasClass("all-days")) { y = null; }
        if ($(this).hasClass("manager")) { imgPath = "../" + imgPath; }
        if (!$(this).hasClass("hasDatepicker")) {
            $(this).datepicker({
                minDate: null,
                buttonImage: '',
                defaultDate: null,
                buttonImageOnly: true,
                showOn: 'both',
                numberOfMonths: 1,
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yyy-mm-dd',
                triggerClass: $(this).hasClass("detail-input") ? "icon-calander-detail" : null,
                langid: langid,
                isShowAtTop: ($(this).attr("data-isshowattop") == null ? false : ($(this).attr("data-isshowattop") == "true" ? true : false)),
                afterShow: function () {
                    if (typeof BindUniform == "function") {
                        BindUniform();
                    }
                }
            }).keydown(function (e) {
                if (e.which != 9 && e.which != 13) return false;
            }).attr("autocomplete", "off");
            if ($(this).attr("data-defaultvalue") != "") {
                if ($(this).hasClass("defdate0")) {
                    if ($.trim($(this).val()) == '')
                        $(this).val(y + '-' + ((m + 1) < 10 ? '0' + (m + 1) : (m + 1)) + '-' + (d < 10 ? '0' + d : d));
                }
                if ($(this).hasClass("defdate1")) {
                    if ($.trim($(this).val()) == '')
                        $(this).val(DateAdd(new Date(y, m, d), 'D', 1));
                }
            }


        }
    });
}
function onCheckInDateChange(eleFrom, eleTo) {
    var v = $('#' + eleFrom).val();
    var arrDate = v.split('-');
    var langid = 2;
    if (arrDate[0].length != 4) {
        langid = 1;
        v = arrDate[2] + '-' + arrDate[1] + '-' + arrDate[0];
    }
    $('#' + eleTo).val(DateAdd(v, "D", 1));
    setTimeout(function () {
        var is_safari = navigator.userAgent.indexOf("Safari") > -1;
        if (is_safari)
            $('#' + eleTo).click();
        else
            $('#' + eleTo).focus();
    }, 100);
}
$(document).ready(function () { applyDatePicker(); });
function HideDatePickerElements() {
    //var chkshowhijri = $('#chkshowhijri');
    //chkshowhijri.next().remove();
    //chkshowhijri.remove();
    //alert($('.ui-hijari').length);
    // $('.ui-datepicker-month .ui-hijari').remove();
    //$('.hijrimonthtext').remove();
    //$('.ui-hijari').remove();
    //$('.hijrimonthtext').remove();


}