﻿/***************************************************************Dashboard****************************************************************/
var ActivityType = {
    'Email': 20814,
    'Task': 20815,
    'SMS': 20816,
    'Meeting': 22387
}
//function FilterActivity(obj, FilterBy) {
//    $('.ulActivityFilter li.selected-tab').removeClass('selected-tab');
//    $(obj).parent('li').addClass('selected-tab');
//    $('#divCurrentActivities').find('#activityHeader').text($(obj).text());

//    var url = SiteUrl + '/home/filteractivity';
//    var data = new Object();
//    data.activityType = $('#divCurrentActivities').find('.ulActivityType').find('li.selected-tab').attr('data-activitytype');
//    data.filterBy = FilterBy;
//    data.pageIndex = 1;
//    data.userId = $('#divCurrentActivities').attr('data-userid');

//    PostData(data, url, function (response) {
//        $('.ulFilteredActivities').html("");
//        $('.ulFilteredActivities').html(response.value1.Data);
//        $('#lnkActivityType' + ActivityType.Email).text('Email(' + response.TotalEmail.Data + ')');
//        $('#lnkActivityType' + ActivityType.Task).text('Tak(' + response.TotalTask.Data + ')');
//        $('#lnkActivityType' + ActivityType.SMS).text('SMS(' + response.TotalSMS.Data + ')');
//        $('#lnkActivityType' + ActivityType.Meeting).text('Meeting(' + response.TotalMeeting.Data + ')');

//        if (response.value2.Data) {
//            $('#btnMoreActivity').removeClass('hide');
//        } else {
//            $('#btnMoreActivity').addClass('hide');
//        }
//    });
//}
function InitializeLeaderBoard() {
    $($('#divCurrentActivities').find('.ulActivityFilter li a')).click(function () {
        $('.ulActivityFilter li.selected-tab').removeClass('selected-tab');
        $(this).parent('li').addClass('selected-tab');
        $('#divCurrentActivities').find('#activityHeader').text($(this).text());
        $(this).parents('li').addClass('selected-tab');
        $('#divCurrentActivities').attr('data-pageindex', 1);
        $('#divCurrentActivities').attr('data-paging', 0);
        return FilterActivitySection();
    });
    $($('#divCurrentActivities').find('.ulActivityAssignedTo li a')).click(function () {
        $('.ulActivityAssignedTo li.selected-tab').removeClass('selected-tab');
        $(this).parent('li').addClass('selected-tab');
        $('#divCurrentActivities').attr('data-pageindex', 1);
        $('#divCurrentActivities').attr('data-paging', 0);
        return FilterActivitySection();
    });
    $($('#divActivityReminders').find('.ulReminderFilter li a')).click(function () {
        $('.ulReminderFilter li.selected-tab').removeClass('selected-tab');
        $(this).parent('li').addClass('selected-tab');
        $('#divActivityReminders').find('#reminderHeader').text($(this).text());
        $(this).parents('li').addClass('selected-tab');
        $('#divActivityReminders').attr('data-pageindex', 1);
        $('#divActivityReminders').attr('data-paging', 0);
        return FilterReminder();
    });
    $($('#divActivityReminders').find('.ulreminderTo li a')).click(function () {
        $('.ulreminderTo li.selected-tab').removeClass('selected-tab');
        $(this).parent('li').addClass('selected-tab');
        $('#divActivityReminders').attr('data-pageindex', 1);
        $('#divActivityReminders').attr('data-paging', 0);
        return FilterReminder();
    });
    $($('#divCurrentActivities').find('.ulActivityType li a')).click(function () {
        $('.ulActivityType li.selected-tab').removeClass('selected-tab');
        $(this).parent('li').addClass('selected-tab');
        $('#divCurrentActivities').attr('data-pageindex', 1);
        $('#divCurrentActivities').attr('data-paging', 0);
        return FilterActivitySection();
    });
    $($('#divCurrentActivities').find('#btnMoreActivity a')).click(function () {
        $('#divCurrentActivities').attr('data-paging', 1);
        return FilterActivitySection();
    });
    $($('#divCurrentActivities').find('.refresh_icon a')).click(function () {
        $('#divCurrentActivities').attr('data-pageindex', 1);
        $('#divCurrentActivities').attr('data-paging', 0);
        return FilterActivitySection();
    });

}

function FilterActivitySection() {
    var url = SiteUrl + '/home/filteractivity';
    var data = new Object();
    data.activityType = $('#divCurrentActivities').find('.ulActivityType').find('li.selected-tab').attr('data-activitytype');
    data.filterBy = $('#divCurrentActivities').find('.ulActivityFilter').find('li.selected-tab').attr('data-filterby');
    data.pageIndex = $('#divCurrentActivities').attr('data-pageindex');
    //data.userId = $('#divCurrentActivities').attr('data-userid');
    var userType = $('#divCurrentActivities').find('.ulActivityAssignedTo').find('li.selected-tab').attr('data-utype');
    if (userType == 'G')
        data.userId = 0;
    else
        data.userId = $('#divCurrentActivities').attr('data-userid');
    $('#divCurrentActivities').attr('data-pageindex', parseInt(data.pageIndex) + 1);
    PostData(data, url, function (response) {
        var currentPageIndex = parseInt(data.pageIndex = $('#divCurrentActivities').attr('data-pageindex'));
        if ($('#divCurrentActivities').attr('data-paging') == '0')
            $('.ulFilteredActivities').html("");
        $('.ulFilteredActivities').append(response.value1.Data);
        if (userType == 'G')
            $('.ulFilteredActivities').find('.pAssignedToForAdmin').removeClass('hide');
        var activityTypes = response.ActivityTypes.Data;
        $(".ulActivityType li a span").remove();
        $(activityTypes).each(function (i, item) {
            var a = $($(".ulActivityType").find("[data-activitytype='" + item.ActivityTypeId + "'] a"));
            if (a.find('span').length > 0) {
                a.find('span').html('(' + item.Total + ')');
            }
            else {
                $(a).append('<span>(' + item.Total + ')</span>');
            }
        });
        if (response.ViewMore.Data) {
            $('#btnMoreActivity').removeClass('hide');
        } else {
            $('#btnMoreActivity').addClass('hide');
        }
    });
    return false;
}

function extras() {
    //function FilterActivityType(obj, ActivityType) {
    //    $('.ulActivityType li.selected-tab').removeClass('selected-tab');
    //    $(obj).parent('li').addClass('selected-tab');
    //    var usertype = $($('.ulActivityAssignedTo .selected-tab')).data('utype');
    //    FilterUserActivity(obj, ActivityType, usertype);
    //    /*
    //    var url = SiteUrl + '/home/filteractivity';
    //    var data = new Object();
    //    data.activityType = ActivityType;
    //    data.filterBy = $('#divCurrentActivities').find('.ulActivityFilter').find('li.selected-tab').attr('data-filterby');
    //    data.pageIndex = 1;
    //    data.userId = $('#divCurrentActivities').attr('data-userid');

    //    PostData(data, url, function (response) {
    //        $('.ulFilteredActivities').html("");
    //        $('.ulFilteredActivities').html(response.value1.Data);
    //        if (response.value2.Data) {
    //            $('#btnMoreActivity').removeClass('hide');
    //        } else {
    //            $('#btnMoreActivity').addClass('hide');
    //        }
    //    });
    //    */
    //}

    //function ReloadActivities() {
    //    var url = SiteUrl + '/home/filteractivity';
    //    var data = new Object();
    //    data.activityType = $('#divCurrentActivities').find('.ulActivityType').find('li.selected-tab').attr('data-activitytype');
    //    data.filterBy = $('#divCurrentActivities').find('.ulActivityFilter').find('li.selected-tab').attr('data-filterby');
    //    data.pageIndex = $('#divCurrentActivities').attr('data-pageindex');
    //    data.userId = $('#divCurrentActivities').attr('data-userid');

    //    PostData(data, url, function (response) {
    //        $('.ulFilteredActivities').html("");
    //        $('.ulFilteredActivities').html(response.value1.Data);
    //        $('#lnkActivityType' + ActivityType.Email).text('Email(' + response.TotalEmail.Data + ')');
    //        $('#lnkActivityType' + ActivityType.Task).text('Tak(' + response.TotalTask.Data + ')');
    //        $('#lnkActivityType' + ActivityType.SMS).text('SMS(' + response.TotalSMS.Data + ')');
    //        $('#lnkActivityType' + ActivityType.Meeting).text('Meeting(' + response.TotalMeeting.Data + ')');
    //        if (response.value2.Data) {
    //            $('#btnMoreActivity').removeClass('hide');
    //        } else {
    //            $('#btnMoreActivity').addClass('hide');
    //        }
    //    });
    //}

    //function LoadMoreActivity(obj) {
    //    var pageIndex = $('#divCurrentActivities').attr('data-pageindex');
    //    pageIndex++;
    //    $('#divCurrentActivities').attr('data-pageindex', pageIndex);
    //    var url = SiteUrl + '/home/filteractivity';
    //    var data = new Object();
    //    data.activityType = $('#divCurrentActivities').find('.ulActivityType').find('li.selected-tab').attr('data-activitytype');
    //    data.filterBy = $('#divCurrentActivities').find('.ulActivityFilter').find('li.selected-tab').attr('data-filterby');
    //    data.pageIndex = pageIndex;
    //    data.userId = $('#divCurrentActivities').attr('data-userid');

    //    PostData(data, url, function (response) {
    //        if (response.value2.Data) {
    //            var html = $('.ulFilteredActivities').html();
    //            html = html + response.value1.Data;
    //            $('.ulFilteredActivities').html(html);
    //            $(obj).parent().removeClass('hide');
    //        } else {
    //            $(obj).parent().addClass('hide');
    //        }
    //    });
    //}

    //function FilterUserActivity(obj, UserId, UserType) {
    //    $('.ulActivityAssignedTo').find('li.selected-tab').removeClass('selected-tab');
    //    $(obj).parents('li').addClass('selected-tab');
    //    if (UserType == "G") {
    //        $('#divCurrentActivities').attr('data-userid', 0);
    //    }
    //    else {
    //        $('#divCurrentActivities').attr('data-userid', UserId);
    //    }
    //    var url = SiteUrl + '/home/filteractivity';
    //    var data = new Object();
    //    data.activityType = $('#divCurrentActivities').find('.ulActivityType').find('li.selected-tab').attr('data-activitytype');
    //    data.filterBy = $('#divCurrentActivities').find('.ulActivityFilter').find('li.selected-tab').attr('data-filterby');
    //    data.pageIndex = 1;
    //    data.userId = $('#divCurrentActivities').attr('data-userid');

    //    PostData(data, url, function (response) {
    //        $('.ulFilteredActivities').html("");
    //        $('.ulFilteredActivities').html(response.value1.Data);
    //        var activityTypes = response.ActivityTypes.Data;
    //        $(".ulActivityType li a span").remove();
    //        $(activityTypes).each(function (i, item) {
    //            var a = $($(".ulActivityType").find("[data-activitytype='" + item.ActivityTypeId + "'] a"));
    //            if (a.find('span').length > 0) {
    //                a.find('span').html('(' + item.Total + ')');
    //            }
    //            else {
    //                $(a).append('<span>(' + item.Total + ')</span>');
    //            }
    //        });
    //        //$('#ulActivityType').find('data-activitytype'" + current + "')

    //        //$('#lnkActivityType' + ActivityType.Email).text('Email(' + response.TotalEmail.Data + ')');
    //        //$('#lnkActivityType' + ActivityType.Task).text('Tak(' + response.TotalTask.Data + ')');
    //        //$('#lnkActivityType' + ActivityType.SMS).text('SMS(' + response.TotalSMS.Data + ')');
    //        //$('#lnkActivityType' + ActivityType.Meeting).text('Meeting(' + response.TotalMeeting.Data + ')');
    //        if (response.value2.Data) {
    //            $('#btnMoreActivity').removeClass('hide');
    //        } else {
    //            $('#btnMoreActivity').addClass('hide');
    //        }
    //    });
    //}

}

function FilterStatistics(obj, FilterBy) {
    $('.ulStatisticsFilter li.selected-tab').removeClass('selected-tab');
    $(obj).parent('li').addClass('selected-tab');
    $('#divEmployeeStatistics').find('#statisticsHeader').text($(obj).text());
    var url = SiteUrl + '/home/filterstatistics';
    var data = new Object();
    data.filterBy = FilterBy;
    data.pageIndex = 1;

    PostData(data, url, function (response) {
        $('.ulFilteredStatistics').html("");
        $('.ulFilteredStatistics').html(response.value1.Data);
        if (response.value2.Data) {
            $('#btnMoreStatistics').removeClass('hide');
        } else {
            $('#btnMoreStatistics').addClass('hide');
        }
    });
}

function ReloadStatistics() {
    var url = SiteUrl + '/home/filterstatistics';
    var data = new Object();
    data.filterBy = $('#divEmployeeStatistics').find('.ulStatisticsFilter').find('li.selected-tab').attr('data-filterby');;
    data.pageIndex = 1;

    PostData(data, url, function (response) {
        $('.ulFilteredStatistics').html("");
        $('.ulFilteredStatistics').html(response.value1.Data);
        if (response.value2.Data) {
            $('#btnMoreStatistics').removeClass('hide');
        } else {
            $('#btnMoreStatistics').addClass('hide');
        }
    });
}

// This Was for pagging now we dont need paging thats why commented 

//function LoadMoreStatistics(obj) {
//    var pageIndex = $('#divEmployeeStatistics').attr('data-pageindex');
//    pageIndex++;
//    $('#divEmployeeStatistics').attr('data-pageindex', pageIndex);
//    var url = SiteUrl + '/home/filterstatistics';
//    var data = new Object();
//    data.filterBy = $('#divEmployeeStatistics').find('.ulStatisticsFilter').find('li.selected-tab').attr('data-filterby');
//    data.pageIndex = pageIndex;

//    PostData(data, url, function (response) {
//        if (response.value2.Data) {
//            var html = $('.ulFilteredStatistics').html();
//            html = html + response.value1.Data;
//            $('.ulFilteredStatistics').html(html);
//            $(obj).parent().removeClass('hide');
//        }
//        else {
//            $(obj).parent().addClass('hide');
//        }
//    });
//}

function FilterReminder() {
    //$('.ulReminderFilter li.selected-tab').removeClass('selected-tab');
    //$(obj).parent('li').addClass('selected-tab');
    //$('#divActivityReminders').find('#reminderHeader').text($(obj).text());

    var url = SiteUrl + '/home/filteractivityreminder';
    var data = new Object();
    data.filterBy = $('#divActivityReminders').find('.ulReminderFilter').find('li.selected-tab').attr('data-filterby');
    data.pageIndex = $('#divActivityReminders').attr('data-pageindex');
    var userType = $('#divActivityReminders').find('.ulreminderTo').find('li.selected-tab').attr('data-utype');
    if (userType == 'G')
        data.userId = 0;
    else
        data.userId = $('#divActivityReminders').attr('data-userid');
    //$('#divActivityReminders').attr('data-pageindex', parseInt(data.pageIndex) + 1);

    PostData(data, url, function (response) {
        $('.ulFilteredReminders').html("");
        $('.ulFilteredReminders').html(response.value1.Data);
        if (response.value2.Data) {
            $('#btnMoreReminder').removeClass('hide');
        } else {
            $('#btnMoreReminder').addClass('hide');
        }
        //var currentPageIndex = parseInt(data.pageIndex = $('#divActivityReminders').attr('data-pageindex'));
        //if ($('#divCurrentActivities').attr('data-paging') == '0')
        //    $('.ulFilteredReminders').html("");
        //$('.ulFilteredReminders').append(response.value1.Data);
        ////if (userType == 'G')
        ////    $('.ulFilteredReminders').find('.pAssignedToForAdmin').removeClass('hide');
        //var activityTypes = response.ActivityTypes.Data;
        //$(".ulActivityType li a span").remove();
        //$(activityTypes).each(function (i, item) {
        //    var a = $($(".ulActivityType").find("[data-activitytype='" + item.ActivityTypeId + "'] a"));
        //    if (a.find('span').length > 0) {
        //        a.find('span').html('(' + item.Total + ')');
        //    }
        //    else {
        //        $(a).append('<span>(' + item.Total + ')</span>');
        //    }
        //});
        //if (response.ViewMore.Data) {
        //    $('#btnMoreActivity').removeClass('hide');
        //} else {
        //    $('#btnMoreActivity').addClass('hide');
        //}
    });
}
function ReloadReminders() {
    var url = SiteUrl + '/home/filteractivityreminder';
    var data = new Object();
    data.filterBy = $('#divActivityReminders').find('.ulReminderFilter').find('li.selected-tab').attr('data-filterby');
    data.pageIndex = $('#divActivityReminders').attr('data-pageindex');
    if (data.pageIndex == "NaN" || data.pageIndex == undefined) {
        data.pageIndex = 1;
    }
    data.userId = $("#divActivityReminders").attr("data-userid");
    PostData(data, url, function (response) {
        $('.ulFilteredReminders').html("");
        $('.ulFilteredReminders').html(response.value1.Data);
        if (response.value2.Data) {
            $('#btnMoreReminder').removeClass('hide');
        } else {
            $('#btnMoreReminder').addClass('hide');
        }
    });
}

function LoadMoreReminders(obj) {
    var pageIndex = $('#divActivityReminders').attr('data-pageindex');
    pageIndex++;
    $('#divActivityReminders').attr('data-pageindex', pageIndex);
    var url = SiteUrl + '/home/filteractivityreminder';
    var data = new Object();
    data.filterBy = $('#divActivityReminders').find('.ulReminderFilter').find('li.selected-tab').attr('data-filterby');
    data.pageIndex = pageIndex;
    var userType = $('#divActivityReminders').find('.ulreminderTo').find('li.selected-tab').attr('data-utype');
    if (userType == 'G')
        data.userId = 0;
    else
        data.userId = $('#divActivityReminders').attr('data-userid');
    PostData(data, url, function (response) {
        if (response.value2.Data) {
            var html = $('.ulFilteredReminders').html();
            html = html + response.value1.Data;
            $('.ulFilteredReminders').html(html);
            $(obj).parent().removeClass('hide');
        }
        else {
            $(obj).parent().addClass('hide');
        }
    });
}

function ReloadActivityFeeds() {
    var url = SiteUrl + '/home/filtercurrentactivity';
    var data = new Object();
    data.lastDate = $('#btnMoreActivityFeeds').attr('data-lastdate');
    data.type = "R";
    PostData(data, url, function (response) {
        $('.ulFilteredActivityFeeds').html("");
        $('.ulFilteredActivityFeeds').html(response.value1.Data);
        if (response.value2.Data) {
            $('#btnMoreActivityFeeds').attr('data-lastdate', response.value3.Data);
            $('#btnMoreActivityFeeds').removeClass('hide');
        }
        else {
            $('#btnMoreActivityFeeds').addClass('hide');
        }
    });
}

function LoadMoreActivityFeeds(obj) {
    var url = SiteUrl + '/home/filtercurrentactivity';
    var data = new Object();
    data.lastDate = $(obj).parent("div").attr('data-lastdate');
    data.type = "M";

    PostData(data, url, function (response) {
        if (response.value2.Data) {
            var html = $('.ulFilteredActivityFeeds').html();
            html = html + response.value1.Data;
            $('.ulFilteredActivityFeeds').html(html);
            $(obj).parent("div").attr('data-lastdate', response.value3.Data);
            $(obj).parent().removeClass('hide');
        }
        else {
            $(obj).parent().addClass('hide');
        }
    });
}

/**********************************************************************LeadImport************************************************************************/
function ImportLeads() {
    $("#importbtnlink").addClass('loader-btn');
    if ($('#fileUpload').val() == "") {
        alert("Please browse file.");
        $("#importbtnlink").removeClass('loader-btn'); return;

    }
    if (!ValidateFileExtension()) {
        alert("Please enter valid file.");
        $("#importbtnlink").removeClass('loader-btn');
        return;
    }
    //post file to server side using XMLHttpRequest
    var fileInput = document.getElementById('fileUpload');
    var xhr = new XMLHttpRequest();
    xhr.open('POST', SiteUrl + '/Leads/ImportLeads');
    xhr.setRequestHeader('Content-type', 'multipart/form-data');

    //Appending file and data information in Http headers
    xhr.setRequestHeader('X-File-Name', fileInput.files[0].name);
    var data = new Object();
    //Sending file in XMLHttpRequest
    xhr.send(fileInput.files[0]);

    //Get response
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var res = JSON.parse(xhr.response);
            if (res.response.Data.IsValid == true) {
                data.filePath = res.filepath.Data;
                var url = SiteUrl + '/leads/importmapping';
                PostDataGetHtml(data, url, function (result) {
                    $('#frmLeadColumnMapping').html("");
                    $('#frmLeadColumnMapping').html(result);
                    $("#importbtnlink").removeClass('loader-btn');
                });
            }
            else {
                alert(res.response.Data.Message);
                $("#importbtnlink").removeClass('loader-btn');
            }
        }
    }
    //return false;

    //var data = new Object();
    //var url = SitePath + '/Lead/ImportLeads';
    //PostData(data, url, function (response) {
    //    alert(response);
    //});
}

function ValidateFileExtension() {
    var validFileExtensions = ["xls", "xlsx"];
    var file = $('#fileUpload').val();
    var extension = file.split('.').pop();
    if ($.inArray(extension, validFileExtensions) == -1) {
        return false;
    }
    else { return true; }
}

function GetMappings() {
    //var validationResponse = $('#frmLeadColumnMapping').IsValidated();
    //if (!validationResponse.IsValid) {
    //    ErrorBox(validationResponse.Message);
    //    return;
    //}
    $("#mappingbtnlink").addClass('loader-btn');
    var url = SiteUrl + '/leads/getmappings';
    var data = new Object();
    data.leadOwner = $('#ddlLeadOwner').val();
    data.filePath = $('.divLeadMappingFile').attr('data-filepath');
    data.isSkipOnError = $('#chkSkipOnError').is(':checked');
    data.onDuplicates = $('input[name="rdDuplicate"]:checked').val();
    var mapping = new Object();
    var MappingColumns = new Array();

    $('.divLeadColumns').each(function () {
        mapping = new Object();
        mapping.SourceColumn = $(this).find('#lblSourceColumn').text();
        mapping.DataColumn = $(this).find('#ddlTableColumnName').val();
        mapping.DefaultValue = $(this).find('#txtDefaultValue').val();
        if (mapping.DataColumn != "") {
            MappingColumns.push(mapping);
        }
    });
    data.mappings = MappingColumns;
    PostDataGetHtml(data, url, function (response) {
        $('#divAfterImport').html("");
        $('#divAfterImport').html(response);
    });
    $("#mappingbtnlink").removeClass('loader-btn');

}

function ShowHideDiv(Id) {
    if ($("#" + Id).hasClass("show")) {
        $("#" + Id).removeClass("show");
        $("#" + Id).addClass("hide");

    }
    else {
        $("#" + Id).addClass("show");
        $("#" + Id).removeClass("hide");
        $('#' + Id).find('#txtDefaultValue').focus();
    }

}

function ImportNow() {
    var url = SiteUrl + '/leads/importnow';
    var data = new Object();
    data.leadOwner = $('#ddlLeadOwner').val();
    data.isSkipOnError = $('#chkSkipOnError').is(':checked');
    data.onDuplicates = $('input[name="rdDuplicate"]:checked').val();
    var html = "";
    PostData(data, url, function (res) {
        if (res.IsValid) {
            html = '<p class="sucses-msg">' + res.Message + '</p>';
            $('#divAfterImported').html("");
            $('#divAfterImported').html(html);
        }
        else {
            html = '<p class="error-msg">' + res.Message + '</p>';
            $('#divAfterImported').html("");
            $('#divAfterImported').html(html);
        }
    })
}

/***************************************************************************Note*****************************************************************/

function ManageNote(ContactId, NoteId, ActivityId) {
    var url = SiteUrl + '/leads/managenote';
    var data = new Object();
    data.contactId = ContactId;
    data.noteId = NoteId;
    data.activityId = ActivityId;
    PostDataGetHtml(data, url, function (response) {
        $('.AddEditNote').html(response);
        $('.AddEditNote').loadpopup();
    });
}

function SaveNote(noteType) {
    var validationResponse = $('#frmNote').IsValidated();

    var url = SiteUrl + '/leads/savenote';
    var data = new Object();
    var note = new Object();
    var obj = $('#frmNote');
    note.NoteId = obj.attr('data-noteid');
    note.CreatedOn = obj.attr('data-createdon');
    note.CreatedBy = obj.attr('data-createdby');
    note.Description = obj.find('#txtNoteDescription').val();
    if (note.Description == undefined || note.Description == "") {
        note.Description = $(".add-note").find("#txtaddnoteDesc").val();
        if (note.Description == "") {
            validationResponse.IsValid = false;
            var ErrorMsg = "Please Enter Description for Note"
            validationResponse.Message.push(ErrorMsg);
        }
    }
    note.Status = "A";

    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message);
        return;
    }
    data.note = note;
    data.contactId = obj.attr('data-contactid');
    if (data.contactId == undefined) {
        data.contactId = $(".add-note").attr('data-contactid');
    }
    data.activityId = obj.attr('data-activityid');
    if (data.activityId == undefined) {
        data.activityId = $(".add-note").attr('data-activityid');
    }
    data.noteType = noteType;
    PostData(data, url, function (response) {
        if (noteType == "Contact") {
            if (response.IsValid) {
                Message(response.Message, function (res) {
                    $('.AddEditNote').hidediv();
                    RebindNotes(data.contactId, 0);
                });
            }
            else {
                ErrorBox(response.Message);
            }
        }
        else {
            if (response.IsValid) {
                Message(response.Message, function (res) {
                    $('.AddEditNote').hidediv();
                    RebindNotes(0, data.activityId);
                });
            }
            else {
                ErrorBox(response.Message);
            }
        }

    });
}

function RebindNotes(ContactId, ActivityId) {
    var url = SiteUrl + '/leads/rebindnotes';
    var data = new Object();
    data.contactId = ContactId;
    data.activityId = ActivityId;
    PostDataGetHtml(data, url, function (response) {
        if (ContactId > 0) {
            $('.divContactNotes').html(response);
        }
        else {
            $('.divActivityNotes').html(response);
        }

    });
}

function DeleteNote(obj, message, NoteId) {
    ConfirmationBox(message, function () {
        DeleteNoteDetail(obj, NoteId);
    });
}

function DeleteNoteDetail(obj, NoteId) {
    var url = SiteUrl + '/lead/deletenote';
    var data = new Object();
    data.noteId = NoteId;

    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function (res) {
                $(obj).parents('.liContactNotes').remove();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
}

/*********************************************************************Lead***************************************************************************/

function InitializeLeadUI() {
    InitializeAutoComplete();
    $('#ddlCountry').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'S')
    });
    $('#ddlState').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'C')
    });
    $('#ddlCity').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'A')
    });
    $('#ddlArea').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'N')
    });

    $('#txtLeadName').focusout(function () {
        var val = $(this).val();
        var fname = $('#txtFName').val();
        if (fname == "") {
            $('#txtFName').val(val);
        }
    });

    $('.FrmContactInfo').each(function () {
        SetLeadContactType($(this).find("[data-id='contact-type']"));
        $(this).find("#ddlContactType").change(function () {
            var val = $(this).find('option:selected').val();

            $(this).parents('div.FrmContactInfo').find('#ddlcountrycode').attr('data-id', 'countrycode' + val);
            $(this).parents('div.FrmContactInfo').find("[data-id='contact-value']").attr('data-type', val);
            $(this).parents('div.FrmContactInfo').find('.chkIsDefault').attr('name', 'radioIsDefault' + val);

            if ($("input[type='radio'][name='radioIsDefault" + val + "']:checked").length == 0) {
                $(this).parents('div.FrmContactInfo').find('.chkIsDefault').attr('checked', 'checked');
            }
            var requiredMsg = GetContactDetailValidateMsg(val);
            $(this).parents('div.FrmContactInfo').find("[data-id='contact-value']").attr('data-r', requiredMsg);

            if ((",E,W,X,T,G,L,S,").indexOf("," + val + ",") == -1) {
                $(this).parents('div.FrmContactInfo').find("[data-id='contact-value']").attr('maxlength', "10");
                $(this).parents('div.FrmContactInfo').find("[data-id='contact-value']").removeAttr('data-e');
                $(this).parents("div.FrmContactInfo").find("#contactValueDiv").removeClass("w238px");
                $(this).parents("div.FrmContactInfo").find("#contactValueDiv").addClass("w178px");
            }
            else {
                $(this).parents('div.FrmContactInfo').find("[data-id='contact-value']").removeAttr('maxlength');
                $(this).parents('div.FrmContactInfo').find("[data-id='contact-value']").removeAttr('data-d');
                $(this).parents("div.FrmContactInfo").find("#contactValueDiv").removeClass("w178px");
                $(this).parents("div.FrmContactInfo").find("#contactValueDiv").addClass("w238px");
            }
            SetLeadContactType($(this));
        });
    });

    function SetLeadContactType(selContactType) {
        var type = selContactType.val();
        var IsCountryCodeShow = (",E,W,X,T,G,L,S,").indexOf("," + type + ",") == -1 ? true : false;
        if (IsCountryCodeShow) {
            var response = GetCountryCodeMsg(type);
            if (response != undefined && type != "") {
                selContactType.parents('div.FrmContactInfo').find("[data-id='countrycode'" + type + "']").attr("data-r", response.RequiredMessage);
                selContactType.parents('div.FrmContactInfo').find("[data-id='contact-value']").attr("data-d", response.ValidateMessage);
                selContactType.parents('div.FrmContactInfo').find("#CountryCodeDiv").removeClass("hide");
            }
        }
        else {
            if (selContactType.find('option:selected').val() == "E") {
                selContactType.parents('div.FrmContactInfo').find("[data-id='contact-value']").attr("data-e", "enter valid email");
            }
            selContactType.parents('div.FrmContactInfo').find("#CountryCodeDiv").addClass("hide");

        }
    }
}

function GetContactDetailValidateMsg(type) {
    if (type == "M") {
        return "Mobile is required";
    }
    else if (type == "P") {
        return "Phone is required";
    }
    else if (type == "E") {
        return "Email is required";
    }
    else if (type == "W") {
        return "Website is required";
    }
    else if (type == "Y") {
        return "Whatsapp is required";
    }
    else if (type == "F") {
        return "Fax is required";
    }
    else if (type == "X") {
        return "Facebook is required";
    }
    else if (type == "L") {
        return "LinkedIn is required";
    }
    else if (type == "S") {
        return "Skype is required";
    }
    else {
        return "GooglePlus is required";
    }
}

function GetCountryCodeMsg(type) {
    var response = new Object();
    if (type == "M") {
        response.RequiredMessage = "Mobile country code is required";
        response.ValidateMessage = "Enter valid Mobile number";
        return response;
    }
    else if (type == "P") {
        response.RequiredMessage = "Phone country code is required";
        response.ValidateMessage = "Enter valid phone number";
        return response;
    }
    else if (type == "Y") {
        response.RequiredMessage = "Whatsapp country code is required";
        response.ValidateMessage = "Enter valid Whatsapp number";
        return response;
    }
    else if (type == "F") {
        response.RequiredMessage = "Fax country code is required";
        response.ValidateMessage = "Enter valid Fax number";
        return response;
    }
}
function InitLeadSearchUI() {
    var allVals = [];

    if ($(".submenudropdown").find("input[id ='chkAllSearchStatus']").is('checked')) {
        $(".submenudropdown").find('input[id="chkSearchStatus"]').prop('checked', true);
        $("#chkSearchStatusDiv").find("#txtSearchStatus").val('All');
    }
    $(".submenudropdown").find("input[id ='chkAllSearchStatus']").change(function () {
        $(".submenudropdown").find('input[id="chkSearchStatus"]').prop('checked', $(this).prop("checked"));
        $("#chkSearchStatusDiv").find("#txtSearchStatus").val($(this).prop("checked") ? 'All' : '');
    });
    var total = $(".submenudropdown").find('input[id="chkSearchStatus"]').length;
    var totalChecked = $(".submenudropdown").find('input[id="chkSearchStatus"]:checked').length;

    if (totalChecked == total) {
        $(".submenudropdown").find("input[id ='chkAllSearchStatus']").prop('checked', true);
        allVals.push('All');
    }
    else {
        $(".submenudropdown").find("input[id ='chkAllSearchStatus']").prop('checked', false);
        allVals = [];
        $(".submenudropdown").find("input[id ='chkSearchStatus']:checked").each(function () {
            allVals.push($(this).attr('data-name'));
        });
    }
    $("#chkSearchStatusDiv").find("#txtSearchStatus").val(allVals)

    $(".submenudropdown").find('input[id="chkSearchStatus"]').change(function () {
        var allVals1 = [];
        var statusBox = $("#chkSearchStatusDiv").find("#txtSearchStatus");
        var total = $(".submenudropdown").find('input[id="chkSearchStatus"]').length;
        var totalChecked = $(".submenudropdown").find('input[id="chkSearchStatus"]:checked').length;

        if (totalChecked == total) {
            $(".submenudropdown").find("input[id ='chkAllSearchStatus']").prop('checked', true);
            allVals1.push('All');
        }
        else {
            $(".submenudropdown").find("input[id ='chkAllSearchStatus']").prop('checked', false);
            allVals1 = [];
            $(".submenudropdown").find("input[id ='chkSearchStatus']:checked").each(function () {
                allVals1.push($(this).attr('data-name'));
            });
        }
        statusBox.val(allVals1);
    });

    //*******************************
    $('#ddlCountry').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'S')
    });
    $('#ddlState').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'C')
    });

    var ids = ['#txtCreatedFrom', '#txtCreatedTo', '#txtUpadtedFrom', '#txtUpadtedTo'];
    ids.forEach(function (entry) {
        $(entry).datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, dateFormat: DateInputFormatJs });
    });

    var filterdIds = ["#ddlLeadFilteredBy", "#ddlUpdatedOn"];
    filterdIds.forEach(function (entry) {
        if (entry == "#ddlLeadFilteredBy") {
            var field1 = "#txtCreatedFrom";
            var field2 = "#txtCreatedTo";
        }
        else {
            var field1 = "#txtUpadtedFrom";
            var field2 = "#txtUpadtedTo";
        }
        $(entry).change(function () {
            if ($(this).find('option:selected').val() == "C") {
                $(field1).removeClass('hide');
                $(field2).removeClass('hide');
            }
            else {
                $(field1).addClass('hide');
                $(field1).val("");
                $(field2).addClass('hide');
                $(field2).val("");
            }
        });
        $(entry).each(function () {
            if ($(this).find('option:selected').val() == "C") {
                $(field1).removeClass('hide');
                $(field2).removeClass('hide');
            }
            else {
                $(field1).addClass('hide');
                $(field1).val("");
                $(field2).addClass('hide');
                $(field2).val("");
            }
        });
    });

    $('#lead .sorting').find('a').click(function () {
        GetLeadsInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
}

function AddCustomeFieldFilter(obj) {
    var copyhtml = $("#addnewcustomfield").clone();
    $(copyhtml).removeAttr("data-addcustomfield").removeClass("hide");
    $(copyhtml).removeAttr("id").attr("data-issample", false);
    $(".advanceFilter").before(copyhtml);
    $(copyhtml).addClass("customefields");
    $('.customefields').find('#ddlSearchCustomField').change(function () {
        LoadCustomFieldValues(this)
    });
}

function RemoveCustomeFieldFilter(obj) {
    $(obj).parent(".customefields").remove();
}

function LoadCustomFieldValues(obj) {
    var LookTypeFieldId = $(obj).find('option:selected').val();
    var url = SiteUrl + '/leads/loadcustomfieldvalues';
    var data = new Object();
    data.lookupTypeFieldId = LookTypeFieldId;
    PostData(data, url, function (response) {
        $(obj).parent('.customefields').find('.customeFieldDiv').html("");
        $(obj).parent('.customefields').find('.customeFieldDiv').html(response.Value1.Data);
        $(obj).parent('.customefields').find('.delete-icon').removeClass('hide');
        $(obj).parent('.customefields').find('#ddlSearchCustomField').remove();
    });
    return false;
}

function GetLeadsInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/leads/filterlead';
    var data = new Object();
    var criteria = new Object();
    criteria.JsFunction = "GetLeadsInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 9;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    criteria.Company = $("#ddlSearchCompany").find('option:selected').val();
    criteria.Country = $("#ddlCountry").find('option:selected').val();
    criteria.State = $("#ddlState").find('option:selected').val();
    criteria.City = $("#ddlCity").find('option:selected').val();
    criteria.LeadName = $("#txtSearchLeadName").val();
    criteria.FirstName = $("#txtSearchFName").val();
    criteria.LastName = $("#txtSearchLName").val();

    var infos = "";
    $('.chkSearchStatusDiv').find($("input[id='chkSearchStatus']:checked")).each(function () {
        infos += $(this).val() + ",";
    });
    criteria.LeadStatuses = infos;

    criteria.AssignedTo = $('#ddlLeadsAssignedTo').find('option:selected').val();
    criteria.Project = $('#ddlLeadProject').val();
    criteria.LeadSource = $('#ddlLeadSource').find('option:selected').val();
    criteria.LeadOwner = $('#ddlLeadOwner').find('option:selected').val();
    criteria.LeadFilteredBy = $('#ddlLeadFilteredBy').find('option:selected').val();
    criteria.UpadtedOn = $('#ddlUpdatedOn').find('option:selected').val();
    criteria.LeadUpdatedBy = $('#ddlLeadsUpdatedBy').find('option:selected').val();
    //criteria.CreatedFrom = $('#txtCreatedFrom').val();
    //criteria.CreatedTo = $('#txtCreatedTo').val();
    //criteria.UpadtedFrom = $('#txtUpadtedFrom').val();
    //criteria.UpdatedTo = $('#txtUpadtedTo').val();
    criteria.Contact = $('#txtSearchConatct').val();
    criteria.ActivitySearch = $('#txtLeadActivity').val();
    criteria.NoteSearch = $('#txtLeadNotes').val();
    var customeField = new Object();
    var customFieldList = new Array();
    $('.customefields .customeFieldDiv').each(function () {
        customeField = new Object();
        customeField.LookupTypeFieldId = $(this).find('#divCustomeFieldValues').attr('data-lookuptypefieldid');
        var selectedValue = $(this).find('#divCustomeFieldValues').attr('data-controlname');
        customeField.CustomFieldValue = $("#" + selectedValue).val();
        if (customeField.LookupTypeFieldId >= 0 && customeField.LookupTypeFieldId != null && customeField.CustomFieldValue != undefined && customeField.CustomFieldValue != "") {
            customFieldList.push(customeField);
        }
    });
    criteria.LeadCustomFieldSearch = customFieldList;
    data.criteria = criteria;
    data.createdFrom = $('#txtCreatedFrom').val();
    data.createdTo = $('#txtCreatedTo').val();
    data.upadtedFrom = $('#txtUpadtedFrom').val();
    data.updatedTo = $('#txtUpadtedTo').val();
    loading = true;
    PostData(data, url, function (response) {
        $('#lead .leadResult').html(response.Records.Data);
        $('#lead .leadPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function ConfirmDeleteLeadDetail(message, leadId) {
    ConfirmationBox(message, function () {
        DeleteLeadDetail(leadId);
    });
    return false;
}

function DeleteLeadDetail(leadId) {
    var data = new Object();
    data.leadId = leadId;
    url = SiteUrl + '/leads/deleteleaddetail';
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.reload();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function SearchLeads() {
    GetLeadsInternal(1, '', '');
}

function ResetLeads() {
    $("#ddlSearchCompany").val("");
    $("#ddlCountry").val("");
    $("#ddlState").val("");
    $("#ddlCity").val("");
    $("#txtSearchLeadName").val("");
    $("#txtSearchFName").val("");
    $("#txtSearchLName").val("");
    $("#ddlSearchStatus").val("-1");
    $("#ddlLeadsAssignedTo").val("-1");
    $("#ddlLeadProject").val("-1");
    $("#ddlLeadSource").val("-1");
    $("#ddlLeadOwner").val("-1");
    $('#ddlLeadFilteredBy').val("");
    $('#txtCreatedFrom').val("");
    $('#txtCreatedTo').val("");
    $('#ddlUpdatedOn').val("");
    $('#ddlLeadsUpdatedBy').val("-1");
    $('#txtUpadtedFrom').val("");
    $('#txtUpadtedTo').val("");
    $('#txtSearchConatct').val("");
    $('#txtLeadActivity').val("");
    $('#txtLeadNotes').val("");
    $('#ddlSearchCustomField').val("");
    $('#txtCustomValue').val("");
    $('#txtSearchStatus').val("");
    var filterdIds = ["#ddlLeadFilteredBy", "#ddlUpdatedOn"];
    filterdIds.forEach(function (entry) {
        if (entry == "#ddlLeadFilteredBy") {
            var field1 = "#txtCreatedFrom";
            var field2 = "#txtCreatedTo";
        }
        else {
            var field1 = "#txtUpadtedFrom";
            var field2 = "#txtUpadtedTo";
        }
        if ($(entry).find('option:selected').val() == "C") {
            $(field1).removeClass('hide');
            $(field2).removeClass('hide');
        }
        else {
            $(field1).addClass('hide');
            $(field2).addClass('hide');
        }
    });
    $(".customefields .customeFieldDiv").each(function () {
        $(this).find('#divCustomeFieldValues').removeAttr('data-lookuptypefieldid');
        $(this).find('#divCustomeFieldValues').removeAttr('data-controlname');
        $(this).parent('.customefields').remove();
    });
    $('.chkSearchStatusDiv').find($("input[id='chkSearchStatus']:checked")).each(function () {
        $(this).prop("checked", false);
    });
    GetLeadsInternal(1, '', '');
    if (location.href.indexOf("?") != -1) {
        var url = SiteUrl + '/leads'
        window.history.pushState("", "", url);
    }
}

function SaveLead() {
    var isChecked;
    var validationResponse = $('#lead').IsValidated();
    var lead = new Object();
    lead.LeadId = $('#lead').attr('data-leadid');
    lead.LeadName = $('#txtLeadName').val();
    lead.CreatedOn = $('#lead').attr('data-createdon');
    lead.CreatedBy = $('#lead').attr('data-createdby');

    lead.LeadType = $('#ddlLeadTypes').val();
    lead.ContactId = $('#lead').attr('data-contactid');
    lead.CompanyId = $('#txtCompany').attr('data-selectedid');
    if ($('#ddlIndustryType').val() != '0')
        lead.IndustryType = $('#ddlIndustryType').val();
    if ($('#ddlLeadSource').val() != '0')
        lead.LeadSource = $('#ddlLeadSource').val();
    if ($('#ddlCampaignSource').val() != '0')
        lead.CampaignSource = $('#ddlCampaignSource').val();
    if ($('#ddlProject').val() != '0')
        lead.Project = $('#ddlProject').val();
    lead.EmailOptOut = $('#chkEmailOptOut').attr("checked") == "checked" ? 'A' : 'I';
    if ($('#ddlLeadStatus').val() != '0')
        lead.LeadStatus = $('#ddlLeadStatus').val();
    lead.Remark = $('#txtRemark').val();
    lead.LeadOwner = $('#ddlLeadOwner').val();
    lead.AssignedTo = $('#ddlLeadAssignedTo').val();

    var contact = new Object();
    contact.ContactId = $('#lead').attr('data-contactid');
    contact.Title = $('#ddlSalutation').val();
    contact.FirstName = $('#txtFName').val();
    if (contact.FirstName == "") {
        contact.FirstName = lead.LeadName;
    }
    contact.LastName = $('#txtLName').val();
    contact.BirthDate = $('#txtBirthDate').val();
    contact.Gender = $('#ddlGender').val();
    contact.EntityType = 'L';
    contact.EntityRefId = $('#lead').attr('data-leadid');
    contact.CreatedOn = $('#lead').attr('data-createdon');
    contact.CreatedBy = $('#lead').attr('data-createdby');
    var contactAdd = new Object();
    contactAdd.Address1 = $('#txtAddress1').val();
    contactAdd.Address2 = $('#txtAddress2').val();
    if ($('#ddlCountry').val() != '0')
        contactAdd.Country = $('#ddlCountry').val();
    if ($('#ddlState').val() != '0')
        contactAdd.State = $('#ddlState').val();
    if ($('#ddlCity').val() != '0')
        contactAdd.City = $('#ddlCity').val();
    if ($('#ddlArea').val() != '0')
        contactAdd.Area = $('#ddlArea').val();
    if ($('#ddlNeighborhood').val() != '0')
        contactAdd.Neighborhood = $('#ddlNeighborhood').val();
    contactAdd.Zip = $('#txtZip').val();
    contactAdd.AddressType = 'H';
    contactAdd.IsDefault = 1;
    contactAdd.ContactId = $('#lead').attr('data-contactid');
    contactAdd.EntityType = 'L';
    contactAdd.EntityRefId = $('#lead').attr('data-leadid');
    contactAdd.AddressId = $('#lead').attr('data-addressid');

    var leadDetails = new Array();
    var leadContact = new Object();
    $('#lead').find(".FrmContactInfo").each(function (index, item) {
        result = new Object();
        if ($(this).find('input[name^=radioIsDefault]').is(":checked")) {
            isChecked = "true";
        }
        else {
            isChecked = "false";
        }
        leadContact = new Object();
        leadContact.ContactDetailId = $(this).attr('data-contactdetailid');
        leadContact.ContactId = $('#lead').attr('data-contactid');
        leadContact.Type = $(this).find('#ddlContactType').val();
        leadContact.Code = $(this).find('#ddlcountrycode').val();
        leadContact.Value = $(this).find('#txtContactValue').val();
        leadContact.IsDefault = isChecked;

        leadDetails.push(leadContact);
    });
    if (leadDetails == "") {
        validationResponse.IsValid = false;
        validationResponse.Message.push("Please add atleast one contact detail.");
    }
    var leaddata = new Object();
    leaddata.lead = lead;
    leaddata.contact = contact;
    leaddata.leadDetails = leadDetails;
    leaddata.contactAdd = contactAdd;
    leaddata.oldLeadStatus = $("#ddlLeadStatus").attr('data-oldstatus');

    SaveLeadDetail(leaddata, validationResponse);
}

function SaveLeadDetail(leaddata, validationResponse) {
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message);
        return false;
    }
    var url = SiteUrl + '/leads/save';
    PostData(leaddata, url, function (leadResponse) {
        if (leadResponse.IsValid) {
            var res = SaveCustomFields(leadResponse.RecordId, function (response) {
                if (response.IsValid) {
                    Message(leadResponse.Message, function (result) {
                        window.location.href = SiteUrl + '/leads/manage/' + leadResponse.RecordId;
                    });
                }
                else {
                    ErrorBox(leadResponse.Message);
                }
            });
        }

        else {
            ErrorBox(leadResponse.Message)
        }
    });
}

function UpdateAssignment(updateType) {
    var url = SiteUrl + '/leads/?assignment=' + updateType;
    location.href = url;
}

function LeadAssignmentConfirmation(msg, obj) {
    var SelectedDiv = $(obj).parents('fieldset').attr('id');
    var result = $("#" + SelectedDiv).IsValidated();
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }
    ConfirmationBox(msg, function () {
        UpadteLeadAssignment();
    });
}

function UpadteLeadAssignment() {
    var url = SiteUrl + '/leads/upadteleadassignment';
    var criteria = new Object();
    criteria.PageIndex = 1;
    criteria.PageSize = 9999999;
    criteria.JsFunction = "GetLeadsInternal(currentPageIndex)";
    criteria.Company = $("#ddlSearchCompany").find('option:selected').val();
    criteria.Country = $("#ddlCountry").find('option:selected').val();
    criteria.State = $("#ddlState").find('option:selected').val();
    criteria.City = $("#ddlCity").find('option:selected').val();
    criteria.LeadName = $("#txtSearchLeadName").val();
    criteria.FirstName = $("#txtSearchFName").val();
    criteria.LastName = $("#txtSearchLName").val();
    criteria.Status = $("#ddlSearchStatus").find('option:selected').val();
    criteria.AssignedTo = $('#ddlLeadsAssignedTo').val();    
    criteria.LeadFilteredBy = $('#ddlLeadFilteredBy').find('option:selected').val();
    criteria.CreatedFrom = $('#txtCreatedFrom').val();
    criteria.CreatedTo = $('#txtCreatedTo').val();
    criteria.UpdateLeadOwnerId = $("#divleadAssignment #ddlOwnertoUpdate").find("option:selected").val();
    criteria.UpdateAssignToId = $("#divleadAssignment #ddlAssignedLead").find("option:selected").val();

    var data = new Object();
    data.criteria = criteria;

    PostData(data, url, function (assignmentResponse) {
        if (assignmentResponse.IsValid) {
            Message(assignmentResponse.Message, function () { location.href = SiteUrl + '/leads' });
            //var leadOwner = $("#divleadAssignment #ddlOwnertoUpdate").find("option:selected").val();
            //var assignedTo = $("#divleadAssignment #ddlAssignedLead").find("option:selected").val();
            //return UpadteLeadAssignment(assignmentResponse.LeadIds, leadOwner, assignedTo);
        }
        else {
            Message(assignmentResponse.Message);
        }
    });
    return false;
}

/*********************************************************************Contact***************************************************************************/
function AddContact(element) {
    var newRow = $('#NewAddLeadContact').find('#FrmContactInfoNew').clone();
    $(newRow).removeClass("FrmContactInfoNew");
    $(newRow).addClass("FrmContactInfo");
    $(newRow).find("#ddlContactType").removeAttr("data-r");
    $(newRow).find("#ddlContactType").attr("data-r", "Contact type is required.");
    $(element).before(newRow);
    InitializeLeadUI();
}

function DeleteLeadContact(ele, msg) {
    ConfirmationBox(msg, function () {
        ConfirmDeleteLeadContact(ele);
    });
}

function ConfirmDeleteLeadContact(ele) {
    $(ele).parents(".FrmContactInfo").remove();
    $('.FrmContactInfo').each(function () {
        var val = $(this).find("#ddlContactType").find('option:selected').val();
        if ($("input[type='radio'][name='radioIsDefault" + val + "']:checked").length == 0) {
            $(this).find('.chkIsDefault').prop('checked', true);
        }
    });
}
function InitManageLeadUI() {
    InitProfileImageUI();
    var oldCode = $('#ddlLeadStatus').attr('data-statuscode');
    if (oldCode == "RD") {
        $('#txtHotelId').attr('data-r', 'Please enter mapping hotel id.');
    }
    $('#ddlLeadStatus').change(function () {
        var newCode = $(this).find('option:selected').attr('data-code');
        if ((oldCode == "WO" && newCode == "RD")) {
            $('#txtHotelId').attr('data-r', 'Please enter mapping hotel id.');
        }
        else {
            $('#txtHotelId').removeAttr('data-r');
        }
    });
}
function InitProfileImageUI() {
    $("[id^=fluProfile]").each(function (index, item) {
        UploadProfileImage($(this).attr('data-contactid'));
    });
}

function UploadProfileImage(uniqueId) {
    $(document).on('change', '#fluProfile' + uniqueId, function () {
        var fileobjraw = $("#profilefileupload" + uniqueId);
        $('#fluProfile' + uniqueId).FilePreview(0, $(fileobjraw).find("img[data-id]"));
        var fileInput;
        fileInput = $("#fluProfile" + uniqueId).val();
        if (fileInput != "") {
            var contactId = uniqueId;
            SaveProfileImageInDirectory(contactId);
        }
    });
}

function SaveProfileImageInDirectory(contactId) {
    var fileInput;
    fileInput = $("#fluProfile" + contactId);
    var xhr = new XMLHttpRequest();
    xhr.open('POST', SiteUrl + '/leads/saveprofileimageindirectory', true);
    xhr.setRequestHeader('Content-type', 'multipart/form-data');
    xhr.setRequestHeader('X-File-Name', fileInput.prop('files')[0].name);
    xhr.setRequestHeader('X-ContactId', contactId);

    var tempfilename = fileInput.prop('files')[0].name;

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var response = JSON.parse(xhr.response);
            var res = response.Response;
            var fileName = response.FileName;
            return true;
        }
        else
            return false;
    }
    xhr.send(fileInput.prop('files')[0]);
}

function ManageContact(LeadId, ContactId) {
    var url = SiteUrl + '/lead/managecontact/' + LeadId;
    if (ContactId > 0) {
        url = url + '/' + ContactId;
    }
    var data = new Object();

    PostJsonGetHtml(data, url, function (response) {
        $('.AddEditLeadContact').html(response);
        $('.AddEditLeadContact').loadpopup();
        InitializeActivity();
        applyDatePicker();
    });
}

function SaveLeadContact() {
    var result = $("#frmContact").IsValidated();
    var url = SiteUrl + '/lead/savecontact';
    var data = new Object();
    var contact = new Object();
    var LeadId = $('#frmContact').attr('data-contactleadid');
    contact.ContactId = $('#frmContact').attr('data-leadcontactid');
    contact.CreatedBy = $('#frmContact').attr('data-createdby');
    contact.EntityRefId = LeadId;
    contact.Title = $('#ddlContactSalutation').val();
    contact.FirstName = $('#txtContactFName').val();
    contact.LastName = $('#txtContactLName').val();
    contact.Gender = $('#ddlContactGender').val();
    contact.BirthDate = $('#txtContactBirthDate').val();
    contact.EntityType = 'L';
    var contactDetails = new Array();
    var leadContact = new Object();
    $('#frmContact').find(".FrmContactInfo").each(function (index, item) {
        if ($(this).find('input[name^=radioIsDefault]').is(":checked")) {
            isChecked = true;
        }
        else {
            isChecked = false;
        }
        leadContact = new Object();
        leadContact.ContactDetailId = $(this).attr('data-contactdetailid');
        leadContact.ContactId = $('#hdnLeadContactId').val();
        leadContact.Type = $(this).find('#ddlContactType').val();
        leadContact.Code = $(this).find('#ddlcountrycode').val();
        leadContact.Value = $(this).find('#txtContactValue').val();
        leadContact.IsDefault = isChecked;
        contactDetails.push(leadContact);
    });

    if (contactDetails == "") {
        result.IsValid = false;
        result.Message.push("Please add atleast one contact detail.");
    }
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }
    data.contact = contact;
    data.contactDetails = contactDetails;
    PostData(data, url, function (response) {
        if (response.IsValid) {
            var res = SaveCustomFields(response.RecordId, function (res) {
                Message(response.Message, function (res) {
                    $('.AddEditLeadContact').hidediv();
                    ReBindLeadContact(LeadId);
                    window.location = "http://localhost/crm/contacts";
                });
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
}

function ReBindLeadContact(LeadId) {
    var url = SiteUrl + '/lead/rebindcontacts/' + LeadId;
    var data = new Object();

    PostJsonGetHtml(data, url, function (response) {
        $('.divLeadContacts').html(response);
    });
}

function DeleteContactDetail(msg, obj, ContactId) {
    ConfirmationBox(msg, function () {
        DeleteContact(obj, ContactId);
    });
}

function DeleteContact(obj, ContactId) {
    var url = SiteUrl + '/lead/deletecontact';
    var data = new Object();
    data.contactId = ContactId;

    PostData(data, url, function (res) {
        if (res.IsValid) {
            Message(res.Message);
            $(obj).parents('.liLeadContact').remove();
        }
        else {
            ErrorBox(res.Message);
        }
    });
}


/*********************************************************************Document***************************************************************************/

function ManageDocument(DocumentId) {
    var data = new Object();
    var url = SiteUrl + '/lead/managedocument';

    if (DocumentId > 0) {
        url = url + '/' + DocumentId
    }

    PostJsonGetHtml(data, url, function (res) {
        $('.divUploadDocument').html(res);
        $('.divUploadDocument').loadpopup();
    });
}

function SaveActivityDocument() {
    var result = $("#frmUploadDocument").IsValidated();


    var document = new Object();
    document.ActivityId = $('#frmActivity').attr('data-leadactivityid');
    document.DocumentId = $('#frmUploadDocument').attr('data-documentid');

    document.EntityRefId = $('#txtActivityContact').attr('data-leadid');
    document.ContactId = $('#txtActivityContact').attr('data-contactid');
    document.Title = $('#txtDocumentTitle').val();
    document.Description = $('#txtDocumentDescription').val();
    document.EntityType = 'L';
    document.DocType = $('#fileDocument').attr('data-doctype');
    document.Path = $('#fileDocument').attr('data-path');

    var fileInput;
    fileInput = $("#fileDocument").val();
    if (fileInput != "") {
        SaveDocumentinDirectory(document, result);
    }
    else {
        if (document.DocumentId == 0) {
            result.IsValid = false;
            result.Message.push("Please select document");
            if (result.IsValid == false) {
                ErrorBox(result.Message);
                return false;
            }
        }
        else {
            SaveDocument(document, result);
        }

    }

}

function SaveDocumentinDirectory(document, result) {
    var fileInput;
    fileInput = $("#fileDocument");
    var xhr = new XMLHttpRequest();
    xhr.open('POST', SiteUrl + '/lead/savedocumentindirectory');
    xhr.setRequestHeader('Content-type', 'multipart/form-data');
    xhr.setRequestHeader('X-File-Name', fileInput.prop('files')[0].name);
    var tempfilename = fileInput.prop('files')[0].name;

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var response = JSON.parse(xhr.response);
            var res = response.Response;
            var fileName = response.FileName;
            if (res.IsValid == true) {
                document.Path = 'docs/1/' + fileName;
                document.DocType = response.FileType;
                SaveDocument(document, result);
            }
            return true;
        }
        else
            return false;
    }
    xhr.send(fileInput.prop('files')[0]);
}

function SaveDocument(document, result) {
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }
    var url = SiteUrl + '/lead/savedocument';
    var data = new Object();
    data.document = document;
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message("Document Uploaded", function (res) {
                $('#divUploadDocumentpopup').hidediv();
                ReBindDocuments(document.ActivityId);
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
}

function DeleteDocument(obj, message, DocumentId) {
    ConfirmationBox(message, function () {
        DeleteDocumentDetail(obj, DocumentId);
    });
}

function DeleteDocumentDetail(obj, DocumentId) {
    var url = SiteUrl + '/lead/deletedocument';
    var data = new Object();
    data.documentId = DocumentId;

    PostData(data, url, function (response) {
        if (response.IsValid == true) {
            Message(response.Message, function (res) {
                $(obj).parents('.liActivityDocument').remove();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
}

function ReBindDocuments(ActivityId) {
    var url = SiteUrl + '/lead/rebinddocuments/' + ActivityId;
    var data = new Object();

    PostJsonGetHtml(data, url, function (response) {
        $('.divActivityDocuments').html(response);
    });
}
/************************************************************************Auto Complete********************************************************************/

function InitializeAutoComplete() {
    $(".jqautoComplete").autocomplete({
        source: function (request, callBack) {
            GetAutoCompleteData(request.term, $(this.element[0]).attr("data-type"), callBack);
        },
        minLength: 2,
        select: function (event, ui) {
            $(this).attr("data-selectedId", ui.item.id);
        },
        open: function () {
            $(this).removeClass("ui-corner-all").addClass("ui-corner-top");
        },
        close: function () {
            $(this).removeClass("ui-corner-top").addClass("ui-corner-all");
        }
    });
}

function GetAutoCompleteData(term, searchType, callBack) {
    var url = SiteUrl + '/leads/filterleadautocomplete';
    var data = new Object();
    data.term = term;
    data.conditionType = searchType;
    PostData(data, url, function (response) {
        callBack(response);
    });
}

/*********************************************************************Activity***************************************************************************/


/**********************************************Start Calender Activity*************************************************************************/

//function BindCalenderActivity(returnVal)
//{
//    debugger;
//    var url = SiteUrl + 'activity/getcalenderactivity';
//    var data = new Object();
//    data.firstDate = returnVal.FirstDate;
//    data.lastDate = returnVal.LastDate;
//    return;
//    PostData(data, url, function (response) {

//    })
//}

/**********************************************End Calender Activity*************************************************************************/

function InitializeActivity() {
    $('#txtActivityDescription').BindTinyMCE();
    $('#txtEstimatedStartDate').datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, dateFormat: DateInputFormatJs });
    $('#txtEstimatedEndDate').datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, dateFormat: DateInputFormatJs });
    $('#txtRemindOn').datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, minDate: "today", dateFormat: DateInputFormatJs });
    $('txtContactBirthDate').datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, maxDate: "today", dateFormat: DateInputFormatJs });
    $(".chkRemindMe").change(function () {
        if ($(this).is(':checked')) {
            $('.divReminderDetail').removeClass('hide');
            $('#txtRemindOn').attr('data-r', 'RemindOn is required');
        }
        else {
            $('.divReminderDetail').addClass('hide');
            $('#txtRemindOn').removeAttr('data-r');
        }
    });
    $('#ddlActivityTypes').change(function () {
        var activityTypeId = $(this).find('option:selected').val();
        var url = SiteUrl + '/leads/loadsubactivity/' + activityTypeId;
        var data = new Object();
        PostJsonGetHtml(data, url, function (response) {
            $('.subActivityTypeDiv').html("");
            $('.subActivityTypeDiv').html(response);
            InitializeActivity();
        });
    });
}

function ChooseActivityContacts(TemplateCode, PageType, EntityId) {
    var data = new Object();
    var TemplateCode = TemplateCode;
    data.PageType = PageType;
    data.TemplateCode = TemplateCode;
    data.entityId = EntityId;
    data.IsPopupOpen = $("#frmActivity").attr('data-isopenpopup');
    var url = SiteUrl + '/email/chooseusers';
    PostDataGetHtml(data, url, function (response) {
        $('.userPopUp').html(response);
        $('.AddEditLeadActivity').HideCssPopup(false);
        $(".userPopUp").CssPopup();
    });
    return false;
}
function ManageActivity(ActivityId, IsOpenPopup, Type, contactId, leadId, projectId) {
    var url = '';
    if (Type == 'A') {
        url = SiteUrl + '/lead/manageactivity';
    }
    else if (Type == 'T') {
        url = SiteUrl + '/lead/managetask';
    }
    else if (Type == 'S') {
        url = SiteUrl + '/lead/managesms';
    }
    else if (Type == 'E') {
        url = SiteUrl + '/lead/manageemail';
    }
    if (ActivityId > 0 || IsOpenPopup == false) {
        var newurl = SiteUrl + '/lead/editactivity';
        if (ActivityId > 0) {
            newurl = newurl + '/' + ActivityId;
        }
        window.open(newurl);
        return;
    }
    var data = new Object();
    data.contactId = contactId;
    data.leadId = leadId;
    data.projectId = projectId;

    PostDataGetHtml(data, url, function (response) {
        $('.AddEditLeadActivity').html(response);
        $('.AddEditLeadActivity').CssPopup();
        $('#txtActivityDescription').BindTinyMCE();
        InitializeActivity();
    });
}

function SelectedLeadContact() {
    var IsPopupOpne = $("#divSearchUser").attr('data-isopen');
    var obj = $('input[name=radioLeadContacts]:checked');
    if (obj.length == 0) {
        ErrorBox("Please Select any User");
        return false;
    }
    else {
        $('#txtActivityContact').attr('data-contactid', obj.val());
        $('#txtActivityContact').attr('data-leadid', obj.attr('data-leadid'));
        $('#txtActivityContact').val($(obj).parents('li').find('a').text());
        if (IsPopupOpne == "True") {
            $('.userPopUp').HideCssPopup(false);
            $('.AddEditLeadActivity').CssPopup();
        }
        else {
            $('.userPopUp').HideCssPopup();
        }
    }
}

function SaveLeadActivity() {
    var result = $("#frmActivity").IsValidated();
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }
    var url = SiteUrl + '/lead/saveactivity';
    var data = new Object();
    var activity = new Object();
    activity.ActivityId = $('#frmActivity').attr('data-leadactivityid');
    var isOpenPopup = $('#frmActivity').attr('data-isopenpopup');
    var LeadId = $('#txtActivityContact').attr('data-leadid');
    if (LeadId == undefined) {
        LeadId = $('#activityItemDiv').attr('data-leadid') == "" ? 0 : $('#activityItemDiv').attr('data-leadid');
    }
    var ContactId = $('#txtActivityContact').attr('data-contactid');
    if (ContactId == undefined) {
        ContactId = $('#activityItemDiv').attr('data-contactid') == "" ? 0 : $('#activityItemDiv').attr('data-contactid');
    }
    activity.ContactId = ContactId;
    activity.OldContactId = $('#txtActivityContact').attr('data-oldcontactid');
    activity.LeadId = LeadId;
    activity.ProjectId = $('#frmActivity').attr('data-leadprojectid');// $('#ddlActivityProjects').val();
    activity.ActivityTypeId = $('#ddlActivityTypes').val();
    activity.SubActivityTypeId = $('#ddlSubActivityTypes').find('option:selected').val();
    activity.DependedActivityId = $('#ddlDependentActivities').val();
    activity.Title = $('#txtActivityTitle').val();
    activity.CreatedOn = $('#frmActivity').attr('data-createdon');
    activity.CreatedBy = $('#frmActivity').attr('data-createdby');
    activity.Description = tinymce.get('txtActivityDescription').getContent();
    activity.EstimatedHour = $('#txtEstimatedHour').val();
    activity.Severity = $('#ddlSeverity').val();
    activity.AssignedTo = $('#ddlAssignedTo').val();
    activity.Status = $('#ddlActivityStatus').val();
    activity.Sequence = $('#txtSequence').val();
    data.activity = activity;
    data.EstimatedStartDateString = $('#txtEstimatedStartDate').val();
    data.EstimatedEndDateString = $('#txtEstimatedEndDate').val();
    data.tsEstimatedStart = $('#ddlEstimatedStartHours').val() + ':' + $('#ddlEstimatedStartMinutes').val() + ':00';
    data.tsEstimatedEnd = $('#ddlEstimatedEndHours').val() + ':' + $('#ddlEstimatedEndMinutes').val() + ':00';
    data.remindMe = $("#chkRemindMe").is(":checked") ? true : false;
    if (data.remindMe) {
        data.remindOn = $('#txtRemindOn').val();
        data.sendEmail = $('#chkSendEmail').is(":checked") ? true : false;
        data.tsRemindDate = $('#ddlReminderHours').val() + ':' + $('#ddlreminderMinutes').val() + ':00';
    }
    else {
        data.remindOn = "";
    }
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function (res) {
                if (isOpenPopup == "True") {
                    $('.AddEditLeadActivity').HideCssPopup();
                    ReBindLeadActivities(LeadId);
                }
                else {
                    window.location.href = SiteUrl + '/lead/editactivity/' + response.RecordId;
                }
            });
        }
        else {
            ErrorBox(response.Message);
            return;
        }
    });

}
function LoadUpdateActivityStatusPopup(ActivityId) {
    var url = SiteUrl + '/activity/loadupdatestatuspopup/' + ActivityId;
    var data = new Object();

    PostJsonGetHtml(data, url, function (res) {
        $('.UpdateActivityStatus').html(res);
        $('.UpdateActivityStatus').loadpopup();
        InitializeActivity();
    });
}
function UpdateActivityStatus() {
    var result = $("#frmUpdateActivity").IsValidated();
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }
    var url = SiteUrl + '/activity/updatestatus';
    var data = new Object();
    var LeadId = $('#frmLeadProfile').attr('data-leadid');
    if (LeadId == undefined) {
        LeadId = $('#activityItemDiv').attr('data-leadid') == "" ? 0 : $('#activityItemDiv').attr('data-leadid');
    }
    var ContactId = $('#frmUpdateActivity').attr('data-contactid');
    if (ContactId == undefined) {
        ContactId = $('#activityItemDiv').attr('data-contactid') == "" ? 0 : $('#activityItemDiv').attr('data-contactid');
    }
    var activity = new Object();
    var reminder = new Object();
    //alert($('#frmUpdateActivity #ddlActivityStatus').val());
    activity.Status = $('#frmUpdateActivity #ddlActivityStatus').val();
    activity.ResponseComment = $('#txtResponseComment').val();
    reminder.remindMe = $("#chkRemindMe").is(":checked") ? true : false;
    reminder.sendEmail = $('#chkSendEmail').is(":checked") ? true : false;
    data.activityId = $('#frmUpdateActivity').attr('data-activityid');

    data.activity = activity;
    data.reminder = reminder;
    if (reminder.remindMe) {
        data.remindOn = $('#txtRemindOn').val();
        data.tsRemindDate = $('#ddlReminderHours').val() + ':' + $('#ddlreminderMinutes').val();
    }
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function (res) {
                $('#divUpdateActivityStatus').HideCssPopup();
                if ($('#frmLeadProfile').attr('data-leadid') == undefined) {
                    location.reload();
                }
                else {
                    ReBindLeadActivities(LeadId);
                }

            });
        }
    });
}
function ReBindLeadActivities(LeadId) {
    var url = SiteUrl + '/lead/rebindactivities/' + LeadId;
    var data = new Object();

    PostJsonGetHtml(data, url, function (response) {
        $('.divLeadActivities').html(response);
    });
}
function DeleteActivityDetail(obj, message, ActivityId) {
    ConfirmationBox(message, function () {
        DeleteActivity(obj, ActivityId);
    });
}

function DeleteActivity(obj, ActivityId) {
    var url = SiteUrl + '/lead/deleteactivity';
    var data = new Object();
    data.activityId = ActivityId;
    PostData(data, url, function (res) {
        if (res.IsValid) {
            Message(res.Message, function (response) {
                if ($(obj).parents('.liLeadActivity').length == 0 || $(obj).parents('.liLeadActivity').length == undefined) {
                    location.reload();
                }
                else {
                    $(obj).parents('.liLeadActivity').remove();
                }
            });
        }
        else {
            ErrorBox(res.Message);
        }
    });
}
function InitActivitiesUI() {
    var allVals = [];

    if ($(".submenudropdown").find("input[id ='chkAllActivityStatus']").is('checked')) {
        $(".submenudropdown").find('input[id="chkActivityStatus"]').prop('checked', true);
        $("#chkActivityStatusDiv").find("#txtActivityStatus").val('All');
    }

    $(".submenudropdown").find("input[id ='chkAllActivityStatus']").change(function () {
        $(".submenudropdown").find('input[id="chkActivityStatus"]').prop('checked', $(this).prop("checked"));
        $("#chkActivityStatusDiv").find("#txtActivityStatus").val($(this).prop("checked") ? 'All' : '');
    });
    var total = $(".submenudropdown").find('input[id="chkActivityStatus"]').length;
    var totalChecked = $(".submenudropdown").find('input[id="chkActivityStatus"]:checked').length;

    if (totalChecked == total) {
        $(".submenudropdown").find("input[id ='chkAllActivityStatus']").prop('checked', true);
        allVals.push('All');
    }
    else {
        $(".submenudropdown").find("input[id ='chkAllActivityStatus']").prop('checked', false);
        allVals = [];
        $(".submenudropdown").find("input[id ='chkActivityStatus']:checked").each(function () {
            allVals.push($(this).attr('data-name'));
        });
    }
    $("#chkActivityStatusDiv").find("#txtActivityStatus").val(allVals)

    $(".submenudropdown").find('input[id="chkActivityStatus"]').change(function () {
        var allVals1 = [];
        var statusBox = $("#chkActivityStatusDiv").find("#txtActivityStatus");
        var total = $(".submenudropdown").find('input[id="chkActivityStatus"]').length;
        var totalChecked = $(".submenudropdown").find('input[id="chkActivityStatus"]:checked').length;

        if (totalChecked == total) {
            $(".submenudropdown").find("input[id ='chkAllActivityStatus']").prop('checked', true);
            allVals1.push('All');
        }
        else {
            $(".submenudropdown").find("input[id ='chkAllActivityStatus']").prop('checked', false);
            allVals1 = [];
            $(".submenudropdown").find("input[id ='chkActivityStatus']:checked").each(function () {
                allVals1.push($(this).attr('data-name'));
            });
        }
        statusBox.val(allVals1);
    });

    //**********************************
    var ids = ['#txtStartDate', '#txtEndDate', '#txtCreatedOnFrom', '#txtCreatedOnTo', '#txtUpdatedOnFrom', '#txtUpdatedOnTo'];
    ids.forEach(function (entry) {
        $(entry).datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, dateFormat: DateInputFormatJs });
    });

    var filterdIds = ["#ddlActivityFilteredBy", "#ddlActivitycreatedOn", "#ddlActivityUpdatedOn"];
    filterdIds.forEach(function (entry) {
        if (entry == "#ddlActivityFilteredBy") {
            var field1 = "#txtStartDate";
            var field2 = "#txtEndDate";
        }
        else if (entry == "#ddlActivityUpdatedOn") {
            var field1 = "#txtUpdatedOnFrom";
            var field2 = "#txtUpdatedOnTo";
        }
        else {
            var field1 = "#txtCreatedOnFrom";
            var field2 = "#txtCreatedOnTo";
        }
        $(entry).change(function () {
            if ($(this).find('option:selected').val() == "C") {
                $(field1).removeClass('hide');
                $(field2).removeClass('hide');
            }
            else {
                $(field1).addClass('hide');
                $(field1).val("");
                $(field2).addClass('hide');
                $(field2).val("");
            }
        });
        $(entry).each(function () {
            if ($(this).find('option:selected').val() == "C") {
                $(field1).removeClass('hide');
                $(field2).removeClass('hide');
            }
            else {
                $(field1).addClass('hide');
                $(field1).val("");
                $(field2).addClass('hide');
                $(field2).val("");
            }
        });
    });
    $('.sortactivities').find('a').click(function () {
        GetActivitiesInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });

    $('#ddlActivityTypes').change(function () {
        var activityTypeId = $(this).find('option:selected').val();
        if (activityTypeId == "" || activityTypeId == undefined) {
            activityTypeId = 0
        }
        var url = SiteUrl + '/leads/loadsubactivity/search/' + activityTypeId;
        var data = new Object();
        PostJsonGetHtml(data, url, function (response) {
            $('.subActivityTypeDiv').html("");
            $('.subActivityTypeDiv').html(response);
            //InitActivitiesUI();
        });
    });
}

function GetActivitiesInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/leads/filteractivities';
    var criteria = new Object();
    criteria.JsFunction = "GetActivitiesInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    criteria.Title = $("#txtTitle").val();
    criteria.IsOverDueActivities = $('.filteractivities').attr('data-isoverdue');
    criteria.ProjectId = $("#ddlActivityProjects").find('option:selected').val();
    criteria.ActivityFilteredBy = $("#ddlActivityFilteredBy").find('option:selected').val();
    //criteria.EstimatedStartDate = $("#txtStartDate").val();
    //criteria.EstimatedEndDate = $("#txtEndDate").val();
    criteria.ActivityCreatedOn = $("#ddlActivitycreatedOn").find('option:selected').val();
    criteria.ActivityUpdatedOn = $("#ddlActivityUpdatedOn").find('option:selected').val();
    criteria.ModifiedBy = $("#ddlActivityUpdatedBy").find('option:selected').val();

    //criteria.CreatedOnFrom = $("#txtCreatedOnFrom").val();
    //criteria.CreatedOnTo = $("#txtCreatedOnTo").val();
    criteria.ActivityTypeId = $("#ddlActivityTypes").find('option:selected').val();
    criteria.SubActivityTypeId = $("#ddlSubActivityTypes").find('option:selected').val();
    criteria.AssignedTo = $("#ddlAssignedTo").find('option:selected').val();
    criteria.LeadOwner = $("#ddlLeadOwner").find('option:selected').val();
    criteria.CreatedBy = $("#ddlAssignedBy").find('option:selected').val();
    criteria.Status = $("#ddlActivityStatus").find('option:selected').val();
    var infos = "";
    $('.chkActivityStatusDiv').find($("input[id='chkActivityStatus']:checked")).each(function () {
        infos += $(this).val() + ",";
    });
    criteria.ActionStatus = infos;
    var data = new Object();
    data.criteria = criteria;
    data.estimatedStartDate = $("#txtStartDate").val();
    data.estimatedEndDate = $("#txtEndDate").val();
    data.createdOnFrom = $("#txtCreatedOnFrom").val();
    data.createdOnTo = $("#txtCreatedOnTo").val();
    data.updtaedOnFrom = $("#txtUpdatedOnFrom").val();
    data.updtaedOnTo = $("#txtUpdatedOnTo").val();
    loading = true;
    PostData(data, url, function (response) {
        $('.activityResult').html(response.Records.Data);
        $('.activityPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function SearchActivities() {
    GetActivitiesInternal(1, '', '');
    return false;
}

function ResetActivities() {

    $("#txtTitle").val("");
    $("#ddlActivityProjects").val("");
    $("#ddlActivityFilteredBy").val("");
    $("#txtStartDate").val("");
    $("#txtEndDate").val("");
    $("#ddlActivitycreatedOn").val("");
    $("#ddlActivityUpdatedOn").val("");
    $("#ddlActivityUpdatedBy").val("-1");
    $("#txtCreatedOnFrom").val("");
    $("#txtCreatedOnTo").val("");
    $("#txtUpdatedOnFrom").val("");
    $("#txtUpdatedOnTo").val("");
    $("#ddlActivityTypes").val("");
    $("#ddlSubActivityTypes").val("");
    $("#ddlAssignedTo").val("");
    $("#ddlLeadOwner").val("");
    $("#ddlAssignedBy").val("");
    $("#ddlActivityStatus").val("");
    $("#txtActivityStatus").val("");
    $(".submenudropdown").find("input[type ='checkbox']:checked").removeAttr('checked');

    $("#txtStartDate").addClass('hide');
    $("#txtEndDate").addClass('hide');

    $("#txtCreatedOnFrom").addClass('hide');
    $("#txtCreatedOnTo").addClass('hide');
    $("#txtUpdatedOnFrom").addClass('hide');
    $("#txtUpdatedOnTo").addClass('hide');
    $('#ddlActivityTypes').each(function () {
        var activityTypeId = 0;
        var url = SiteUrl + '/leads/loadsubactivity/search/' + activityTypeId;
        var data = new Object();
        PostJsonGetHtml(data, url, function (response) {
            $('.subActivityTypeDiv').html("");
            $('.subActivityTypeDiv').html(response);
            //InitActivitiesUI();
        });
    });
    GetActivitiesInternal(1, '', '');
    if (location.href.indexOf("?") != -1) {
        var url = SiteUrl + '/leads/activities'
        window.history.pushState("", "", url);
    }
    return false;
}

function SearchByStatistics(obj) {
    var employeeId = $(obj).attr('data-employeeid');
    var statisticsType = $(obj).attr('data-typename');
    var statisticsSubType = $(obj).attr('data-subtype');
    var statisticsDate = $(obj).parents("#divEmployeeStatistics").find(".ulStatisticsFilter #statisticsHeader").text();
    var date = "";
    if (statisticsDate == "Yesterday") {
        date = 'Y';
    }
    else if (statisticsDate == "This Week") {
        date = 'TW';
    }
    else if (statisticsDate == "Last Week") {
        date = 'LW';
    }
    else if (statisticsDate == "This Month") {
        date = 'TM';
    }
    else {
        date = 'T';
    }
    if (statisticsType == "Lead") {

        var url = SiteUrl + '/leads/?empid=' + employeeId + '&date=' + date;
        window.open(url, "");
    }
    else {
        var url = SiteUrl + '/leads/activities/?empid=' + employeeId + '&date=' + date + '&type=' + statisticsType + '&subtype=' + statisticsSubType;
        window.open(url, "");
    }
}

/***************************************************************End of Choose emial Campaigns*******************************************************************************/

/******************************************************** Start Activity Tasks******************************************************************************************/
//function ManageActivity(leadId, activityId) {
//    var url = SiteURL + 'activity/manage';
//    var data = new Object();
//    data.leadId = leadId;
//    data.activityId = activityId;
//    PostDataGetHtml(data, url, function (response) {
//        $('#leadActivity').html(response);
//        $('#leadActivity').loadpopup();
//    });
//}

//function SaveActivity(leadId, activityId) {
//    var result = $("#activity").IsValidated();
//    if (result.IsValid == false) {
//        ErrorBox(result.Message);
//        return false;
//    }
//    var url = SiteURL + "activity/save";
//    var data = new Object();
//    //data.LeadId = leadId;
//    data.ActivityId = activityId;
//    data.Title = $('#txtTitle').val();
//    data.Description = $('#txtDescription').val();
//    //data.ProjectId = $("#ddlProject").val();
//    //data.EstimatedHour = $('#txtEstimatedHour').val();

//    var startDate = $('#txtStartDate').val() + ' ' + $('#ddlSHours').val() + ':' + $('#ddlSMinutes').val() + ' ' + $('#ddlSAMPM').val();
//    var endDate = $('#txtEndDate').val() + ' ' + $('#ddlEHours').val() + ':' + $('#ddlEMinutes').val() + ' ' + $('#ddlEAMPM').val();
//    //data.EstimatedEndDate = $('#txtEndDate').val();
//    //data.ActualStartDate = actualStartDate;
//    //data.ActualEndDate = actualEndDate;
//    data.ActivityTypeId = 20815;
//    data.Severity = $('#ddlSeverity').val();
//    data.Sequence = $('#txtSequence').val();
//    data.Status = $('#ddlStatus').val();
//    data.AssignedTo = $('#ddlAssignedTo').val();
//    var activity = new Object();
//    activity.activity = data;
//    activity.leadId = leadId;
//    activity.startDate = startDate;
//    activity.endDate = endDate;
//    //var leadActivities = new Array();
//    //var activity = new Object();
//    //activity.LeadId = LeadId;
//    //leadActivities.push(activity);
//    //data.leadActivities = leadActivities;
//    alert(url);
//    PostData(activity, url, function (response) {
//        if (response.IsValid) {
//            HideDiv($('#leadActivity'));

//            //location.href = SiteUrl + 'lead/ManageLead2/' + LeadId;
//            //window.location = GVSiteURL + "email/Activity";
//        }
//        alert(response.Message);
//    });

//}

//function CloseActivity() {
//    HideDiv($('#leadActivity'));
//}

/* End Activity Tasks*/

/* Start Activity Email*/

//function ManageActivityEmail(leadId, activityId) {
//    var url = SiteURL + 'activity/manageemail';
//    var data = new Object();
//    data.leadId = leadId;
//    data.activityId = activityId;
//    PostDataGetHtml(data, url, function (response) {
//        $('#leadActivity').html(response);
//        $('#leadActivity').loadpopup();
//    });
//}

//function FetchEmailTemplateDetail(emailTemplateId) {

//    if (emailTemplateId == 0) {
//        $('#txtSubject').val('');
//        $('#txtBody').val('');
//        $('#ddlSender').val(0);
//        return;
//    }
//    var url = SiteURL + 'activity/fetchemailtemplatedetail';
//    var data = new Object();
//    data.emailTemplateId = emailTemplateId;
//    PostData(data, url, function (response) {
//        $('#txtSubject').val(response.Subject);
//        $('#txtBody').val(response.Body);
//        $('#ddlSender').val(response.SenderId);
//    });
//}

/*End Activity Email*/


/*************************************************************Start Merge Leads******************************************************************/
function FindDuplicateLeads() {
    ShowLoader();
    var url = SiteUrl + '/leads/findduplicates';
    var data = new Object();
    var types = "";
    $('.findduplicates input[type="checkbox"]:not("#cbkLeadName"):checked').each(function () {
        types = types + $(this).val() + ",";
    });
    data.type = types;
    PostData(data, url, function (response) {
        $('.dvFindDuplicateLeadsBytype').addClass('hide');
        $('.dvAvailableDuplicateItems').html(response.Records.Data).removeClass('hide');
        HideLoader();
    });
}
function ViewDuplicateLeadDetails(leadId, duplicatesWith) {
    if ($('#dvDuplicateLeadDetails' + leadId).attr('data-isloaded') == 'false') {
        duplicatesWith = duplicatesWith + leadId;
        var url = SiteUrl + '/leads/viewduplicatesdetail';
        var data = new Object();
        data.duplicatesLeadIds = duplicatesWith;
        PostData(data, url, function (response) {
            $('#dvDuplicateLeadDetails' + leadId).html(response.Records.Data);
            $('#dvDuplicateLeadDetails' + leadId).removeClass('hide').attr('data-isloaded', true);
        });
    }
    else {
        if ($('#dvDuplicateLeadDetails' + leadId).hasClass('hide'))
            $('#dvDuplicateLeadDetails' + leadId).removeClass('hide');
        else
            $('#dvDuplicateLeadDetails' + leadId).addClass('hide');
    }
}
function BackToPreviousPage($currentPageContainer, $prevPageContainer) {
    $currentPageContainer.addClass('hide');
    $prevPageContainer.removeClass('hide');
}
function ManualLeadMerge(duplicatesLeadIds, elem) {
    ShowLoader();
    var url = SiteUrl + '/leads/manualmerge';
    var data = new Object();
    data.duplicatesLeadIds = duplicatesLeadIds;
    PostData(data, url, function (response) {
        $(elem).parents('.dvMainFoundLead').addClass('clicked');
        $('.dvAvailableDuplicateItems').addClass('hide');
        $('.dvMainManualMergeLeads').html(response.Records.Data).removeClass('hide');
        HideLoader();
        InitManualMergeUI();
    });
}
function InitManualMergeUI() {
    $('.scrocolumn input[name="rdLeadMain"]').change(function () {
        $('.scrocolumn input[type="checkbox"]:checked,.scrocolumn input[type="radio"]:checked').prop('checked', false);
        $(this).parents('.dvLeadColumns').find('input[type="checkbox"],input[type="radio"]').prop('checked', true);
    });
}
function MergeLeads(message) {
    ConfirmationBox(message, function () {
        MergeLeadsConfirm();
    });
}
function MergeLeadsConfirm() {
    ShowLoader();
    var result = new Object();
    result.IsValid = true;
    result.Message = new Array();
    if ($('input[type="radio"][name="rdLeadMain"]:checked').length == 0) {
        result.IsValid = false;
        result.Message.push("Please select lead with whom you want to merge details.");
    }
    if ($('input[type="radio"][name="rdLeadStatus"]:checked').length == 0) {
        result.IsValid = false;
        result.Message.push("Please select lead status.");
    }
    if ($('input[type="radio"][name="rdLeadName"]:checked').length == 0) {
        result.IsValid = false;
        result.Message.push("Please select lead name.");
    }
    if ($('input[type="radio"][name="rdFirstName"]:checked').length == 0) {
        result.IsValid = false;
        result.Message.push("Please select first name.");
    }
    //if ($('input[type="radio"][name="rdLastName"]:checked').length == 0) {
    //    result.IsValid = false;
    //    result.Message.push("Please select last name.");
    //}
    //if ($('input[type="radio"][name="rdCompany"]:checked').length == 0) {
    //    result.IsValid = false;
    //    result.Message.push("Please select lead company.");
    //}
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }
    var url = SiteUrl + '/leads/mergeduplicates';
    var data = new Object();

    var customFields = new Array();
    var field = new Object();

    var contactDetailIds = "";

    data.LeadId = $('input[type="radio"][name="rdLeadMain"]:checked').val();
    data.DuplicatesWith = "";
    $('input[type="radio"][name="rdLeadMain"]:not(:checked)').each(function () {
        data.DuplicatesWith += $(this).val() + ",";
    });
    data.LeadStatus = $('input[type="radio"][name="rdLeadStatus"]:checked').val();
    data.LeadName = $('input[type="radio"][name="rdLeadName"]:checked').val();
    data.FirstName = $('input[type="radio"][name="rdFirstName"]:checked').val();
    data.LastName = $('input[type="radio"][name="rdLastName"]:checked').val();
    data.CompanyId = $('input[type="radio"][name="rdCompany"]:checked').val();
    data.MergeType = 'M';
    $('input[type="radio"][name^="rdCustom"]:checked').each(function () {
        field = new Object();
        field.LookupTypeFieldId = $(this).attr('data-ltfid');
        field.CustomFieldValue = $(this).val();
        field.RefId = data.LeadId;
        customFields.push(field);
    });
    data.ExtraFields = customFields;

    $('input[type="checkbox"][name="cbkContactDetail"]:checked').each(function () {
        if ($(this).val() != 0)
            contactDetailIds += $(this).val() + ",";
    });
    data.ContactDetailIds = contactDetailIds;
    PostData(data, url, function (response) {
        HideLoader();
        if (response.IsValid) {
            Message(response.Message, function () {
                BackToPreviousPage($('.dvMainManualMergeLeads'), $('.dvAvailableDuplicateItems'));
                $('.dvMainFoundLead.clicked').remove();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
}
function LoadDuplicateLeadsPartial(leadId) {
    var url = SiteUrl + '/loadDuplicateLeadPartial';
    var data = new Object();
    data.leadId = leadId
    PostData(data, url, function (response) {
        $('.dvDuplicatesWithBox').html(response.Records.Data);
    });
}
function AutoMergeWithLead(elem,type,message) {
    ConfirmationBox(message, function () {
        AutoMergeWithLeadConfirm(elem);
    });
}
function AutoMergeWithLeadConfirm(elem, type)//Type - M: Normal Merge Screen,L:Lead screen
{
    ShowLoader();
    $(elem).parents('.dvtdDupLeads').addClass('automerge');
    var url = SiteUrl + '/leads/mergeduplicates';
    var data = new Object();
    data.LeadId = $('.dvtdDupLeads.automerge').attr('data-leadid');
    data.DuplicatesWith = "";
    $('.dvtdDupLeads:not(.automerge)').each(function () {
        data.DuplicatesWith += $(this).attr('data-leadid') + ",";
    });
    data.MergeType = 'A';
    PostData(data, url, function (response) {
        HideLoader();
        if (response.IsValid) {
            Message(response.Message, function () {
                if(type == "M")
                    $(elem).parents('.dvMainFoundLead').remove();
                else
                    location.href = SiteUrl + '/leads/view/' + data.LeadId;
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
}
/*************************************************************End Merge Leads******************************************************************/
function InitLeadContactUI() {
    $('.search').click(function () {
        LoadContacts(1);
    });
    $('.clear-search').click(function () {
        ResetLeadContacts();
    });
    $('.contacts').find('a').click(function () {
        LoadContacts(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
    LoadContacts(1);
}
function ResetLeadContacts() {
    $("#txtSearchConatctDetail").val("");
    $("#txtSearchLeadContact").val("");
    $('#txtSearchFName').val('');
    $('#txtSearchLName').val('');
    LoadContacts(1);
}
function LoadContacts(currentPageIndex, sortExpression, sortDirection) {
    $('#ContactContainer').html("Loading...");
    var data = new Object();
    data.JsFunction = "LoadContacts(currentPageIndex)";
    data.contactId = parseInt($("#txtSearchLeadContact").val()) || 0;
    data.firstname = $("#txtSearchFName").val();
    data.lastname = $("#txtSearchLName").val();
    data.value = $("#txtSearchConatctDetail").val();
    data.PageIndex = currentPageIndex;
    data.PageSize = 12;
    if (sortExpression != undefined)
        data.SortExpression = sortExpression;
    if (sortDirection != undefined)
        data.SortDirection = sortDirection;
    var url = SiteUrl + '/leads/contactdetails';
    PostData(data, url, function (response) {
        $('#ContactContainer').html(response.contactlist.Data);
        $('.leadPaging').html(response.Paging.Data);
    })
}
function ConfirmDeleteLeadContactDetail(message, ContactId) {
    ConfirmationBox(message, function () {
        DeleteLeadContactDetail(ContactId);
    });
    return false;
}
function DeleteLeadContactDetail(ContactId) {
    var data = new Object();
    data.ContactId = ContactId;
    url = SiteUrl + '/leads/deleteleadcontacts';
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.reload();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}
function SearchUserDetails() {
    var sortExpression = "";
    var sortDirection = "";
    GetUserDetailsInternal(1, sortExpression, sortDirection);
    return false;
}
function ResetUserDetails() {
    $("#txtSearchLeadContact").val("");
    $("#txtSearchFName").val("");
    $("#txtSearchLName").val("");
    $("#txtSearchConatctDetail").val("");
    GetUserDetailsInternal(1, '', '');
    return false;
}