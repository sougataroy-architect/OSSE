﻿/*************************************************************************Email Setting***************************************************************************/

function InitializeEmailSettingsUI() {
    $('.sortsetting').find('a').click(function () {
        GetEmailSettingsInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
}

function SearchEmailSetting() {
    return GetEmailSettings(1);
}

function GetEmailSettingsInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/email/filteremailsettings';
    var criteria = $('.filtersetting').GetSearchCriteria();
    criteria.JsFunction = "GetEmailSettings(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    loading = true;
    PostData(criteria, url, function (response) {
        $('.emailSettingResult').html(response.Records.Data);
        $('.emailSettingPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function GetEmailSettings(currentPageIndex) {
    return GetEmailSettingsInternal(currentPageIndex, '', '');
}

function ResetEmailSettings() {
    $('#EmailSettings .filtersetting').ResetSearchCriteria();
    SearchEmailSetting();
}

function SaveEmailSettings() {

    var validationResponse = $('#EmailSettings').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message)
        return false;
    }
    var sslEnabled;
    url = SiteUrl + '/email/saveEmailSettings';
    var emailSender = new Object();
    emailSender.SSLEnabled = $('#SSLEnabled').is(":checked");
    emailSender.Status = $('#Status').is(":checked")
    emailSender.EmailSenderId = $('#lblEmailSettingId').text();
    emailSender.Title = $("#txtTitle").val();
    emailSender.SMTP = $('#txtSMTP').val();
    emailSender.UserName = $('#txtUserName').val();
    emailSender.Password = $('#txtPassword').val();
    emailSender.Port = $('#txtPort').val();
    emailSender.Status = $('#chkStatus').is(":checked") ? "A" : "I";
    emailSender.CustomerAccountId = $("#hdnCustomerAccId").val();
    emailSender.CreatedDate = $("#EmailSettings").attr('data-createddate');
    var data = new Object();
    data.emailSender = emailSender;

    PostData(data, url, function (response) {
        if (response.IsValid) {
            return Message(response.Message, function () { window.location = SiteUrl + "/email/settings"; });
        }
        else {
            return ErrorBox(response.Message);
        }
    });
    return false
}

function RedirectNewEmailSettings() {
    window.location.href = SiteUrl + "/email/managesettings";
}

function ConfirmDeleteEmailSetting(message, emailSenderId) {
    ConfirmationBox(message, function () {
        DeleteEmailSettings(emailSenderId);
    });
    return false;
}

function DeleteEmailSettings(emailSenderId) {
    var data = new Object();
    data.emailSenderId = emailSenderId;
    url = SiteUrl + '/email/deleteEmailSettings';
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.reload();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}


/*************************************************************************Email Template***************************************************************************/

function InitializeEmailTemplatesUI() {
    $('.sorttemplates').find('a').click(function () {
        GetEmailTemplatesInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
}

function SearchEmailTemplates() {
    return GetEmailTemplates(1);
}

function GetEmailTemplatesInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/email/FilterEmailTemplates';
    var criteria = $('.filtertemplates').GetSearchCriteria();
    criteria.JsFunction = "GetEmailTemplates(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    loading = true;
    PostData(criteria, url, function (response) {
        $('.emailTemplateResult').html(response.Records.Data);
        $('.emailTemplatePaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function GetEmailTemplates(currentPageIndex) {
    return GetEmailTemplatesInternal(currentPageIndex, '', '');
}

function ResetEmailTemplates() {
    $('#EmailTemplates .filtertemplates').ResetSearchCriteria();
    SearchEmailTemplates();
}

function SaveEmailTemplates() {
    var validationResponse = $('#EmailTemplates').IsValidated();
    var saveUrl = SiteUrl + "/email/saveEmailTemplates";
    var emailTemplateId = $("#EmailTemplates").attr('data-emailtemplateid');
    var emailTemplateTypeId = $("#ddlEmailTemplateType option:selected").val();
    var emailTemplateCode = $("#txtTemplateCode").val();
    var emailTemplateName = $("#txtTemplateName").val();
    var emailTemplateBody = tinymce.get('txtbody').getContent();
    var emailTemplateStatus = $("#chkActive").is(":checked") ? "A" : "I";
    var emailTemplateSubject = $("#txtSubject").val();
    var emailSenderId = $("#ddlFromAddress option:selected").val();
    var emailTemplateFrom = $("#ddlFromAddress option:selected").val();
    var emailCreatedDate = $("#EmailTemplates").attr('data-createdon');
    var emailCreatedBy = $("#EmailTemplates").attr('data-createdby');
    var CustomerAccountId;

    if (tinymce.get('txtbody').getContent() == "") {
        var error = "Please Enter Body of Template";
        validationResponse.IsValid = false;
        validationResponse.Message.push(error);
    }
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message)
        return false;
    }
    var data = new Object();
    data.EmailTemplateId = emailTemplateId;
    data.EmailTemplateTypeId = emailTemplateTypeId
    data.Code = emailTemplateCode;
    data.Name = emailTemplateName;
    data.Body = emailTemplateBody;
    data.Status = emailTemplateStatus;
    data.Subject = emailTemplateSubject;
    data.FromAddress = emailTemplateFrom;
    data.EmailSenderId = emailSenderId;
    data.CreatedDate = emailCreatedDate;
    data.CreatedBy = emailCreatedBy;
    data.CustomerAccountId = CustomerAccountId;
    PostData(data, saveUrl, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () { window.location = SiteUrl + "/email/templates"; });

        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function RedirectNewEmailTemplates() {
    window.location.href = SiteUrl + "/email/templates/manage";
}

function ConfirmDeleteEmailTemplate(message, emailtemplateid) {
    ConfirmationBox(message, function () {
        DelelteEmailTemplates(emailtemplateid);
    });
    return false;
}

function DelelteEmailTemplates(emailtemplateid) {
    var data = new Object();
    data.emailTemplateId = emailtemplateid;
    url = SiteUrl + '/email/delelteemailtemplates';
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.reload();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

/*************************************************************************Email Campaign manage***************************************************************************/

function InitializeCampaignUI() {
    if ($("#CampaignForm").find("#hdnEmailCampaignId").val() > 0) {
        $("#UserTypeDiv").find("#next1").addClass("hide");
        $("#EmailTemplateDiv").find("#next2").addClass("hide");
        $("#UserDiv").find("#next3").addClass("hide");
        $("#CampaignForm").find("#EmailTemplateDiv").removeClass("hide");
        $("#CampaignForm").find("#UserDiv").removeClass("hide");
        $("#CampaignForm").find("#ScheduleDiv").removeClass("hide");
        $(".SaveData").find("#next4").removeClass("hide");
    }
    else {
        $("#UserTypeDiv").find("#next1").click(function () {
            if ($('input:radio[name=typeradio]').is(':checked')) {
                $("#CampaignForm").find("#EmailTemplateDiv").removeClass("hide");
                $("#UserTypeDiv").find("#next1").addClass("hide");
            }
            else {
                ErrorBox("First Select Email Template Type For Campaign", 1);
            }
        });
        $("#EmailTemplateDiv").find("#next2").click(function () {
            if ($("#txtSubject").val() != "" && tinymce.get('txtbody').getContent() != "" && $("#ddlFromAddress").find('option:selected').val() != "") {
                $("#CampaignForm").find("#UserDiv").removeClass("hide");
                $("#EmailTemplateDiv").find("#next2").addClass("hide");
            }
            else {
                var validation = $('#EmailTemplateDiv').IsValidated();
                if (tinymce.get('txtbody').getContent() != "") {
                    var error = "Please Enter Body For Campaign";
                    validation.IsValid = false;
                    validation.Message.push(error);
                }
                if (!validation.IsValid) {
                    ErrorBox(validation.Message)
                    return false;
                }
            }
        });
        $("#UserDiv").find("#next3").click(function () {
            if ($("#campaignUserDiv").find(".contactDiv").length != 0 || $("#campaignIddiv").find(".userDetailDiv").length != 0) {
                $("#CampaignForm").find("#ScheduleDiv").removeClass("hide");
                $("#UserDiv").find("#next3").addClass("hide");
                $(".SaveData").find("#next4").removeClass("hide");
            }
            else {
                ErrorBox("First Select User For Campaign");
            }
        });
    }
    $('input:radio[name=typeradio]').click(function () {
        var EmailTemplateId = $("#CampaignForm").find("#EmailTemplateDiv").attr('data-emailtemplateId');
        LoadTemplate(EmailTemplateId);
        ResetSearchUser();
    });
    $('#ContactDeailForm').find($("input[id='chkuserSel']")).click(function () {
        SelectedUsers();
    });
    $('#txtduedate').datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, dateFormat: DateInputFormatJs });
    return false;
}

function InitExpressEmailUI() {

    $("#EmailTemplateDiv").find(".ddlEmailTemplate").change(function(){
        LoadTemplateDetails();
    });

    $('#ContactDeailForm').find($("input[id='chkuserSel']")).click(function () {
        SelectedUsers();
    });
    $('#txtduedate').datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, dateFormat: DateInputFormatJs });
    return false;
}

function LoadTemplate(EmailTemplateId) {
    var EmailTemplateTypeId = $('input:radio[name=typeradio]:checked').val();
    var url = SiteUrl + '/email/loadtemplate';
    var data = new Object();
    data.EmailTemplateId = EmailTemplateId;
    data.EmailTemplateTypeId = EmailTemplateTypeId;
    PostDataGetHtml(data, url, function (response) {
        $('.divTemplateList').html("");
        $('.divTemplateList').html(response);
        LoadTemplateDetails();
    });
}

function LoadTemplateDetails() {
    var EmailTemplateId = $("#ddlEmailTemplate").find('option:selected').val();
    var EmailCampaignId = $("#hdnEmailCampaignId").val();
    var url = SiteUrl + '/email/loadtemplatedetail';
    var data = new Object();
    data.EmailTemplateId = EmailTemplateId;
    data.EmailCampaignId = EmailCampaignId;
    PostDataGetHtml(data, url, function (response) {
        $('.divTemplateDetail').html("");
        $('.divTemplateDetail').html(response);
    });
}

/*************************************************************************Select AllUser***************************************************************************/
function UsersByUserType() {
    var url = SiteUrl + '/email/loadselecteduserlist';
    //var type = $('#UserTypeDiv').find('input[name=typeradio]:checked').attr('data-templatecode');
    var Contact = new Object();
    var Contacts = new Array();
    $('#ContactDeailForm').find($("input[id='chkuserSel']:checked")).each(function () {
        Contact = new Object();
        Contact.ContactId = $(this).attr('data-contactid');
        Contact.FirstName = $(this).attr('data-firstname');
        Contact.LastName = $(this).attr('data-lastname');
        Contact.Email = $(this).attr('data-email');
        Contact.Type = $('#UserTypeDiv').find('input[name=typeradio]:checked').attr('data-templatecode');
        Contacts.push(Contact);
    });
    var data = new Object();
    var removeID = 0;
    data.Contacts = Contacts;
    data.removeID = removeID;
    PostDataGetHtml(data, url, function (response) {
        $('.divselectedUserList').html("");
        $('.divselectedUserList').html(response);
        var contactsLength = $("#campaignUserDiv").attr('data-userCount');
        var userCounthtml = '<span class="user-icon-user"></span> ' + contactsLength + ' Users Selected';
        $('#userCount').find('p').html("");
        $('#userCount').find('p').html(userCounthtml);
    });
    return false;
}

function SelectedUsers() {
    if ($('#ContactDeailForm').find($("input[id='chkuserSel']:checked")).length <= 0) {
        ErrorBox("Atleast Select Any one User For Campaign", 1);
        return false;
    }
    UsersByUserType();
}

function RemoveUser(obj) {
    var removeID = $(obj).parents(".contactDiv").attr('data-contactid');
    $(obj).parents(".contactDiv").remove();
    var url = SiteUrl + '/email/loadselecteduserlist';
    var type = $('#UserTypeDiv').find('input[name=typeradio]:checked').attr('data-templatecode');
    var data = new Object();
    data.removeID = removeID;
    data.type = type;
    PostDataGetHtml(data, url, function (response) {
        $('.divselectedUserList').html("");
        $('.divselectedUserList').html(response);
        var contactsLength = $("#campaignUserDiv").attr('data-userCount');
        if (contactsLength == undefined) {
            contactsLength = 0;
        }
        var userCounthtml = '<span class="user-icon-user"></span> ' + contactsLength + ' Users Selected';
        $('#userCount').find('p').html("");
        $('#userCount').find('p').html(userCounthtml);
        $(".userPopUp").hidediv();
    });
    return false;

}

function RemoveAllUsers() {
    var data = new Object();
    var url = SiteUrl + '/email/removeallusers';
    PostDataGetHtml(data, url, function (response) {
        $('.divselectedUserList').html("");
        var contactsLength = $("#campaignUserDiv").attr('data-userCount');
        if (contactsLength == undefined) {
            contactsLength = 0;
        }
        var userCounthtml = '<span class="user-icon-user"></span> ' + contactsLength + ' Users Selected';
        $('#userCount').find('p').html("");
        $('#userCount').find('p').html(userCounthtml);
    });
    return false;

}

function SelectAllUserForCampain() {
    var url = SiteUrl + '/email/selectalluserforcampain';
    var data = new Object();
    var criteria = Object();
    criteria.JsFunction = "GetCampaignUserInternal(currentPageIndex)";
    criteria.PageIndex = 1;
    criteria.PageSize = $(".campaignUserPaging").find(".pagination-row #txtTotalPages").attr('data-totalpage');
    criteria.FirstName = $("#txtSearchFirstName").val();
    criteria.LastName = $("#txtSearchLastName").val();
    criteria.Email = $("#txtSearchEmail").val();
    loading = true;
    data.criteria = criteria;
    data.pageType = $('#divSearchUser').attr('data-type');
    if (data.pageType == 'Campaign') {
        data.TemplateCode = $('#UserTypeDiv').find('input[name=typeradio]:checked').attr('data-templatecode');
        if(data.TemplateCode == undefined)
        {
            data.TemplateCode = 'LD';
        }
    }
    else {
        data.TemplateCode = 'LD';
    }
    PostData(data, url, function (res) {
        if (res.length > 0) {
            var url = SiteUrl + '/email/loadselecteduserlist';
            var Contact = new Object();
            var Contacts = new Array();
            $.each(res, function (index, item) {
                Contact = new Object();
                Contact.ContactId = item.ContactId;
                Contact.FirstName = item.FirstName;
                Contact.LastName = item.LastName;
                Contact.Email = item.Email;
                Contacts.push(Contact);
            });
            var data = new Object();
            var removeID = 0;
            data.Contacts = Contacts;
            data.removeID = removeID;
            PostDataGetHtml(data, url, function (response) {
                $('.divselectedUserList').html("");
                $('.divselectedUserList').html(response);
                var contactsLength = $("#campaignUserDiv").attr('data-userCount');
                var userCounthtml = '<span class="user-icon-user"></span> ' + contactsLength + ' Users Selected';
                $('#userCount').find('p').html("");
                $('#userCount').find('p').html(userCounthtml);
                $(".userPopUp").hidediv();
                return GetCampaignUserInternal(1, '', '');
            });
        }
    });
    return false;
}

function LoadMoreSelectedUsers() {
    var data = new Object();
    var url = SiteUrl + '/email/loadmoreselectedusers';
    PostDataGetHtml(data, url, function (response) {
        $('.selectedUserPopUp').html(response);
        $(".selectedUserPopUp").loadpopup();
    });
    return false;
}

function InitSelectedUserUI() {
    $('.sortselectedusers').find('a').click(function () {
        GetSelectedUserInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
    return false;
}

function GetSelectedUserInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/email/filterselecteduserdetail';
    var data = new Object();
    var criteria = Object();
    criteria.JsFunction = "GetSelectedUserInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    criteria.FirstName = $("#txtuserFirstName").val();
    criteria.LastName = $("#txtuserLastName").val();
    criteria.Email = $("#txtuserEmail").val();
    loading = true;
    data.criteria = criteria;
    PostData(data, url, function (response) {
        $('.selectedUserResult').html(response.Records.Data);
        $('.selectedUserPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function SearchSelectedUser() {
    GetSelectedUserInternal(1, '', '');
}

function ResetSelectedUserSearch() {
    $("#txtuserFirstName").val("");
    $("#txtuserLastName").val("");
    $("#txtuserEmail").val("");
    GetSelectedUserInternal(1, '', '');
}

/*************************************************************************Choose User***************************************************************************/

function ChooseUsers(PageType) {
    var data = new Object();
    var TemplateCode = $('#UserTypeDiv').find('input[name=typeradio]:checked').attr('data-templatecode');
    if (TemplateCode == undefined)
    {
        TemplateCode = "LD";
    }
    data.PageType = PageType;
    data.TemplateCode = TemplateCode;
    data.entityId = 0;
    data.IsPopupOpen = false;
    var url = SiteUrl + '/email/chooseusers';
    PostDataGetHtml(data, url, function (response) {
        $('.userPopUp').html(response);
        $(".userPopUp").loadpopup();
    });
    return false;
}

function InitializeUserSearchUI() {
    //$("#btnDiv").find(".ckbCheckAll").on('click', function () {
    //    $("#ContactDeailForm").find(".checkBoxClass").prop('checked', $(this).prop('checked'));
    //});
    $('.sortusers').find('a').click(function () {
        GetCampaignUserInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
    return false;
}

function GetCampaignUserInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/email/filtercampaignuserdetail';
    var data = new Object();
    var criteria = Object();
    criteria.JsFunction = "GetCampaignUserInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    criteria.FirstName = $("#txtSearchFirstName").val();
    criteria.LastName = $("#txtSearchLastName").val();
    criteria.Email = $("#txtSearchEmail").val();
    loading = true;
    data.criteria = criteria;
    data.pageType = $('#divSearchUser').attr('data-type');
    if (data.pageType == 'Campaign') {
        data.TemplateCode = $('#UserTypeDiv').find('input[name=typeradio]:checked').attr('data-templatecode');
        if(data.TemplateCode == undefined)
        {
            data.TemplateCode = 'LD';
        }
    }
    else {
        data.TemplateCode = 'LD';
    }
    data.entityId = $(".filterUsers").attr('data-entityId');
    PostData(data, url, function (response) {
        $('.campaignUserResult').html(response.Records.Data);
        $('.campaignUserPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function SearchUser() {
    GetCampaignUserInternal(1, '', '');
}

function ResetSearchUser() {
    $("#txtSearchFirstName").val("");
    $("#txtSearchLastName").val("");
    $("#txtSearchEmail").val("");
    GetCampaignUserInternal(1, '', '');
}

/*************************************************************************Email Campaign***************************************************************************/


function ManageExpressEmail(emailCampaignId,activityId,emailTemplateType)
{
    var url = SiteUrl + '/email/campaign/manage/' + emailCampaignId + '/?id=' + activityId + '&type=' + emailTemplateType
    window.open(url,"");
}

function SaveEmailCampaignDetail() {
    var validationResponse = $('#CampaignForm').IsValidated();
    var error = "";
    var saveUrl = SiteUrl + "/email/saveemailcampaigndetail";
    var emailCampaign = new Object();
    emailCampaign.EmailCampaignId = $("#hdnEmailCampaignId").val();
    emailCampaign.ActivityId = $("#UserTypeDiv").attr('data-activityid');
    emailCampaign.EmailTemplateId = $("#ddlEmailTemplate").find('option:selected').val();
    emailCampaign.EmailCampaignTypeId = $('input:radio[name=typeradio]:checked').val();
    if (emailCampaign.EmailCampaignTypeId == undefined)
    {
        emailCampaign.EmailCampaignTypeId = $("#UserTypeDiv").attr('data-templateTypeid');
    }
    emailCampaign.ActivityId = $("#UserTypeDiv").attr('data-activityid');
    emailCampaign.EnableTracking = $("#chktracking").is(":checked") ? 1 : 0;

    if ($("#txtduedate").val() == "01-00-0001 0:0") {
        error = "Please Select Send Date";
        validationResponse.IsValid = false;
        validationResponse.Message.push(error);
    }
    if (tinymce.get('txtbody').getContent() == "") {
        error = "Please Enter Body For Campaign";
        validationResponse.IsValid = false;
        validationResponse.Message.push(error);
    }
    if ($("#campaignUserDiv").find(".contactDiv").length == 0 || $("#campaignUserDiv").find(".contactDiv").length == undefined)
    {
        error = "Please Select Atleast One User";
        validationResponse.IsValid = false;
        validationResponse.Message.push(error);
    }
    emailCampaign.Status = $("#ddlStatus").find('option:selected').val();
    emailCampaign.Name = $("#txtName").val();
    emailCampaign.Subject = $("#txtSubject").val();
    emailCampaign.Body = tinymce.get('txtbody').getContent();
    emailCampaign.EmailSenderId = $("#ddlFromAddress").find('option:selected').val();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message)
        return;
    }
    var data = new Object();
    data.emailCampaign = emailCampaign;
    data.sendDateString = $("#txtduedate").val();
    data.tsSenddate = $("#ddlSendDateHour").find('option:selected').val() + ":" + $("#ddlSendDateMin").find('option:selected').val() + ":00";
    PostData(data, saveUrl, function (campaignResponse) {
        if (campaignResponse.response.IsValid) {
            Message(campaignResponse.response.Message, function () {
                if (campaignResponse.ActivityId > 0)
                {
                    var emailTemplateType = $("#UserTypeDiv").attr('data-type');
                    location.href = SiteUrl + '/email/campaign/manage/0' + '/?id=' + campaignResponse.ActivityId + '&type=' + emailTemplateType;
                }
                else {
                    location.href = SiteUrl + '/email/campaign/manage/' + campaignResponse.response.RecordId;
                }
                
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function InitializeCampaignListUI() {
    $('#EmailCampaigns .sortCampaigns').find('a').click(function () {
        GetEmailCampaignsInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
}

function SearchEmailCampaigns() {
    var sortExpression = "";
    var sortDirection = "";
    GetEmailCampaignsInternal(1, sortExpression, sortDirection);
    return false;
}

function GetEmailCampaignsInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/email/filteremailcampaigndetails';
    var criteria = new Object();
    criteria.JsFunction = "GetEmailCampaignsInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 3;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    criteria.Name = $("#txtCampaignName").val();
    criteria.EmailTemplateId = $("#ddlEmailteplateId").find('option:selected').val();
    criteria.Status = $("#ddlStatus").find('option:selected').val();

    loading = true;
    PostData(criteria, url, function (response) {
        $('.emailCampaignResult').html(response.Records.Data);
        $('.emailCampaignPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function ResetEmailCampaigns() {
    $("#txtCampaignName").val("");
    $("#ddlEmailteplateId").val("");
    $("#ddlStatus").val("");
    GetEmailCampaignsInternal(1, '', '');
    return false;
}

function RedirectNewEmailCampaigns() {
    window.location.href = SiteUrl + "/email/campaign/manage";
}

function ConfirmDeleteEmailCampaign(message, emailCampaignId) {
    ConfirmationBox(message, function () {
        DeleteEmailCampaignDetail(emailCampaignId);
    });
    return false;
}

function DeleteEmailCampaignDetail(emailCampaignId) {
    var data = new Object();
    data.emailCampaignId = emailCampaignId;
    url = SiteUrl + '/email/deleteEmailCampaignDetail';
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.reload();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

/*************************************************************************EmailCampaign User***************************************************************************/

function InitEmailCampaignUserUI() {
    $('.sortCampaignStatus').find('a').click(function () {
        GetCampaignUserStatusInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
    return false;
}

function GetCampaignUserStatusInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/email/filtercampaignuserstatus';
    var criteria = Object();
    criteria.JsFunction = "GetCampaignUserStatusInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    criteria.FirstName = $("#txtFirstName").val();
    criteria.LastName = $("#txtLastName").val();
    criteria.Email = $("#txtEmail").val();
    criteria.EmailStatus = $("#ddlEmailStatus").find('option:selected').val();
    var data = new Object();
    data.criteria = criteria;
    data.emailCampaignId = $("#CampaignUserStatus").attr('data-campaignid');
    loading = true;
    PostData(data, url, function (response) {
        $('.campaignUserStatusResult').html(response.Records.Data);
        $('.campaignUserStatusPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function SearchCampaignUserStatus() {
    return GetCampaignUserStatusInternal(1, '', '');
}

function ResetCampaignUserStatus() {
    $("#txtFirstName").val("");
    $("#txtLastName").val("");
    $("#txtEmail").val("");
    $("#ddlEmailStatus").val("");
    return GetCampaignUserStatusInternal(1, '', '');
}

function InitCampaignReportUI() {
      $("#CampaignReport").find(".filtercampaignreports #ddlType").change(function () {
        return GetCampaignReportInternal(1);
    });
    $("#CampaignReport").find(".recipient #totalRecipient").click(function () {
        $("#ddlType").val("All");
        return GetCampaignReportInternal(1, '', '');
    });
    $("#CampaignReport").find(".chart #totalOpened").click(function () {
        debugger
        $("#ddlType").val("Opened");
        return GetCampaignReportInternal(1);
    });
    $("#CampaignReport").find(".chart #totalClicked").click(function () {
        $("#ddlType").val("Clicked");
        return GetCampaignReportInternal(1, '', '');
    });
    $("#CampaignReport").find(".chart #totalBounced").click(function () {
        $("#ddlType").val("Bounced");
        return GetCampaignReportInternal(1, '', '');
    });
    $("#CampaignReport").find(".chart #totalUnsubscribed").click(function () {
        $("#ddlType").val("Unsubscribed");
        return GetCampaignReportInternal(1, '', '');
    });
}

function GetCampaignReportInternal(currentPageIndex) {
    var url = SiteUrl + '/email/filtercampaignreportdetails';
    var criteria = Object();
    criteria.JsFunction = "GetCampaignReportInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    criteria.Activity = $("#ddlType").find('option:selected').val();
    var data = new Object();
    data.criteria = criteria;
    data.emailCampaignId = $(".CampaignReportDiv").attr('data-id');
    loading = true;
    PostData(data, url, function (response) {
        $('.campaignActivityResult').html(response.Records.Data);
        $('.campaignActivityPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function ResetCampaignActivity() {
    $("#ddlType").val("All");
    return GetCampaignReportInternal(1, '', '');
}