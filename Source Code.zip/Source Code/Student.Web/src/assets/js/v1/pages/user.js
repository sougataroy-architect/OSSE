﻿fullBlur = { blurRadius: 6, cssFilterSupport: true }
var currentWin = '';
function InitializeLoginUI() {
    //$('#loginform #btnLogin').click(function () {
    //    alert('registered...');
    //   return CheckLogin();
    //});
    //$('#loginform #btnLogin').on('click', function () {
    //    alert('dfd');
    //    return false;
    //});
    $("#loginform #txtUserName,#loginform #txtPassword").keydown(function (event) {
        var key = event.charCode || event.keyCode || 0;
        if (key == 13) {
            var id = $(this).attr("id");
            switch (id) {
                case "txtUserName":
                    $("#loginform #txtPassword").focus();
                    break;
                case "txtPassword":
                    $('#loginform #btnLogin').click();
                    break;
            }
        }
    });
    $(document).on('click', '.login', function () {
        loadModal('login');
        currentWin = 'login';
        $('#loginform #txtUserName').focus();
        $('.resetPswrdMsg').html("");
        return false;
    });
    $(document).on('click', '.register', function () {
        loadModal('register');
        currentWin = 'register';
        $('#registerUserForm #txtFirstName').focus();
        return false;
    });
    $(document).on('click', '.password-reset', function () {
        loadModal('password-reset');
        currentWin = 'password-reset';
        $('#resetPasswordForm #txtemailId').focus();
        return false;
    });
    $(document).on('click', '.close-pop-modal', function () {
        // Detect if modal close should reload page instead 
        if (/^true$/i.test($(this).closest('.pop-modal').attr('refresh'))) {
            location.reload();
        } else {
            hideModal();
        }
        // Prevent Default
        return false;
    });

    // Detect escape press to close modal
    $(document).keyup(function (e) {
        if (e.keyCode == 27) {
            hideModal();
        }
        else if (e.keyCode == 13) {
            switch (currentWin) {
                //case 'login':
                //    CheckLogin();
                //    //$('#loginform #btnLogin').click();
                //    break;
                case 'register':
                    RegisterUser();
                    break;
                case 'password-reset':
                    ForgotPassword();
                    break;
            }

        }
    });
}

/*  Function:    loadModal(slug)
     *  Created By:  Jordan Piluso
     *  Support URL: December 27, 2014
     *
     *  This function will recieve a string which represents
     *  a page to be loaded. This will either be loaded
     *  through an AJAX call or a local cach on the page.
     */
function loadModal(slug, queryData) {

    // Check if array is empty
    queryData = (queryData === undefined || !jQuery.isPlainObject(queryData)) ? {} : queryData;

    // Check if modal is pre-loaded
    if ($(document).find('.modal-preload').find('[modal-slug="' + slug + '"]').length > 0) {
        $(document).find('.pop-modal').html($(document).find('.modal-preload').find('[modal-slug="' + slug + '"]').html());
        showModal();

        // Dynamically load modal through AJAX
    }
}


/*  Function:    showModal()
 *  Created By:  Jordan Piluso
 *  Support URL: December 27, 2014
 *
 *  This function will show the page modal as well as the
 *  page overlay. This will be animated.
 */
function showModal() {

    // Animate scroll to top of page
    $('html, body').animate({ scrollTop: 0 }, 150);

    // Detect if browser is webkit based
    if (isWebkit()) {
        $('.page-container').foggy(fullBlur).addClass('active');
    } else {
        $(document).find('.pop-overlay').show();
    }

    // Show the modal
    $('.pop-modal').fadeIn().addClass('active');

}


/*  Function:    hideModal()
 *  Created By:  Jordan Piluso
 *  Support URL: December 27, 2014
 *
 *  This function will hide the page modal, clear the
 *  content as well as animate it disappearing.
 */
function hideModal() {
    // Fade out modal and background
    $(".modal-bg").removeClass("active");
    $('.pop-modal').fadeOut();

    // Detect if browser is webkit based
    if (isWebkit()) {
        $(".page-container").foggy(false).removeClass('active');
    } else {
        $(document).find('.pop-overlay').hide();
    }

    // Remove modal active status
    $(".pop-modal").removeClass('active');

}
/*  Function:    isWebkit()
*  Created By:  Jordan Piluso
*  Support URL: December 27, 2014
*
*  This function will return true if the browser is
*  webkit based or false if not.
*/
function isWebkit() {
    return (window.URL != null) ? true : false;
}

function CheckLogin() {
    if ($("#loginform").attr('data-isclicked') == 'false') {
        $("#loginform").attr('data-isclicked', true);
        var userName = $('#loginform #txtUserName').val();
        var password = $('#loginform #txtPassword').val();
        var url = SiteUrl + '/home/checklogindetails';
        var data = new Object();
        data.userName = userName;
        data.password = password;
        PostData(data, url, function (response) {
            if (response.IsValid) {
                location.href = SiteUrl + '/leaderboard';
            }
            else {
                alert(response.Message);
            }
        });
        return false;
    }
    else
    {
        return false;
    }
    
}

function ForgotPassword() {
    var emailid = $("#resetPasswordForm #txtemailId").val();
    var url = SiteUrl + '/home/forgotpassword';
    var data = new Object();
    data.emailId = emailid;
    PostData(data, url, function (response) {
        if (response.IsValid) {
            $("#resetPasswordForm").find("#txtemailId").addClass("hide");
            $("#resetPasswordForm").find("#resetbtn").addClass("hide");
            $('.resetPswrdMsg').html("");
            $('.resetPswrdMsg').html(response.Message);
        }
        else {
            $('.resetPswrdMsg').html("");
            $('.resetPswrdMsg').html(response.Message);
        }

    });
    return false;
}

function RegisterUser() {
    var user = new Object();
    user.UserName = $("#registerUserForm .contactDetailDiv").find("#emailForUser").find("#txtvalue").val();
    user.Password = $("#registerUserForm #txtPassword").val();

    var contact = new Object();
    contact.FirstName = $("#registerUserForm #txtFirstName").val();
    contact.LastName = $("#registerUserForm #txtLastName").val();

    var contacts = new Object();
    var contactDetail = new Array();
    $("#registerUserForm").find(".contactDetailDiv").each(function () {
        contacts = new Object();
        contacts.Value = $(this).find("#txtvalue").val();
        contacts.Type = $(this).find("#txtvalue").attr('data-type');
        contacts.IsDefault = $(this).find("#txtvalue").attr('data-isdefault');
        if (contacts.Value != "") {
            contactDetail.push(contacts);
        }
    })
    var address = new Object();
    address.Zip = $("#registerUserForm #txtzipCode").val();
   
    var result = new Array();
    var error = "";
    if (user.UserName == "") {
        error = $("#registerUserForm .contactDetailDiv").find("#emailForUser").find("#txtvalue").attr('data-r');
        result.push(error);
    }
    if (user.Password == "") {
        error = $("#registerUserForm #txtPassword").attr('data-r');
        result.push(error);
    }
    if (contact.FirstName == "") {
        error = $("#registerUserForm #txtFirstName").attr('data-r');
        result.push(error);
    }
    if (contact.LastName == "") {
        error = $("#registerUserForm #txtLastName").attr('data-r');
        result.push(error);
    }
    if (user.UserName != "") {
        var emailField = $("#registerUserForm .contactDetailDiv").find("#emailForUser").find("#txtvalue");
        var result1 = validateEmail(emailField);
        if (result1 == false) {
            error = $("#registerUserForm .contactDetailDiv").find("#emailForUser").find("#txtvalue").attr('data-e');
            result.push(error);
        }
    }
    var Phone = $("#registerUserForm .contactDetailDiv").find("#mobileForUser").find("#txtvalue").val();
    if (Phone != '') {
        var mobileField = $("#registerUserForm .contactDetailDiv").find("#mobileForUser").find("#txtvalue");
        var result2 = IsMobileNumber(mobileField);
        if (result2 == false)
        {
            error = $("#registerUserForm .contactDetailDiv").find("#mobileForUser").find("#txtvalue").attr('data-d');
            result.push(error);
            mobileField.focus();
        }
       
    }
    if (result.length > 0) {
        alert(result);
        return false;
    }

    var url = SiteUrl + '/home/registeruser';
    var data = new Object();
    data.user = user;
    data.contact = contact;
    data.contactDetail = contactDetail;
    data.address = address;
    data.companyName = $("#registerUserForm #txtcompanyName").val();
    PostData(data, url, function (response) {
        if (response.IsValid) {
            location.href = SiteUrl + '/confirmregistration/';
        }
        else {
            alert(response.Message);
        }
    });
    return false;
}

function validateEmail(emailField) {
    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if (reg.test(emailField.val()) == false) {
        return false;
    }
    else {
        return true;
    }
}

function IsMobileNumber(mobileField) {
    var mob = /^[1-9]{1}[0-9]{9}$/;
    if (mob.test(mobileField.val()) == false) {
        return false;
    }
    else {
        return true;
    }
}

function ChangePassword() {
    var password = $("#changepasswordform").find("#txtPassword").val();
    var rePassword = $("#changepasswordform").find("#txtConfirmPassword").val();
    if (password == "") {
        alert("Please Enter Password");
        return false;
    }
    if (rePassword == "") {
        alert("Please Enter ConfirmPassword");
        return false;
    }
    if (password != rePassword) {
        alert("ConfirmPassword Does not match please retry");
        return false;
    }
    var data = new Object();
    data.password = password;
    data.userId = $("#changepasswordform").attr('data-userid');
    data.emailId = $("#changepasswordform").attr('data-emailId');
    var url = SiteUrl + '/home/changepassword';
    PostData(data, url, function (response) {
        alert(response.Message);
        if (response.IsValid) {
            location.href = SiteUrl + '/resetpassword'
        }
    });
    return false;
}

/************************************************************************************User**************************************************************************************/

function InitializeUserUI() {
    $('#txtBirthDate').datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, maxDate: "today", dateFormat: DateInputFormatJs });
    var sortExpression = "";
    var sortDirection = "";
    $('#UserDetails .sortsetting').find('a').click(function () {
        GetUserDetailsInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
}
function ShowHideUserPassword(obj) {
    if ($(obj).attr('data-isShow') == "false") {
        $(obj).parent().find('#txtPassword').attr('type', "text");
        $(obj).attr('data-isShow', "true").text("Hide Password");
    }
    else {
        $(obj).parent().find('#txtPassword').attr('type', "password");
        $(obj).attr('data-isShow', "false").text("Show Password");
    }
}
function SaveUserDetail() {
    var validationResponse = $('#UserDetail').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message)
        return false;
    }
    url = SiteUrl + "/users/saveuserdetail";
    var user = new Object();
    user.UserId = $("#UserDetail").attr('data-id');
    user.UserName = $("#txtUserName").val();
    user.Password = $("#txtPassword").val();
    user.UserTypeId = $("#ddlUserType").find('option:selected').val();
    user.Status = $("#chkStatus").is(':checked') ? "A" : "I";

    var contact = new Object();
    contact.ContactId = $("#UserDetail").attr('data-contactid');
    contact.FirstName = $("#txtFirstName").val();
    contact.LastName = $("#txtLastName").val();
    //contact.Title = $("#txtTitle").val();
    //contact.BirthDate = $("#txtBirthDate").val() + " 00:00";
    contact.Gender = $("#ddlGender").find('option:selected').val();
    contact.CreatedBy = $("#chkStatus").attr('data-createdby');
    contact.CreatedOn = $("#chkStatus").attr('data-createdon');
    var contactDetail = new Array();
    var userContact = new Object()
    userContact.ContactDetailId = $("#UserDetail").attr('data-contactDetailid');
    contactDetail.push(userContact);

    var data = new Object();
    data.user = user;
    data.contact = contact;
    data.contactDetail = contactDetail;
    data.birthDateString = $("#txtBirthDate").val();
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () { window.location = SiteUrl + "/users/list"; })
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function SearchUserDetails() {
    var sortExpression = "";
    var sortDirection = "";
    GetUserDetailsInternal(1, sortExpression, sortDirection);
    return false;
}

function GetUserDetailsInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/users/filterUserDetails';
    var criteria = new Object();
    criteria.JsFunction = "GetUserDetailsInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    criteria.UserName = $("#txtUserName").val();
    criteria.FirstName = $("#txtFirstName").val();
    criteria.LastName = $("#txtLastName").val();
    criteria.Status = $("#ddlStatus").find('option:selected').val();
    loading = true;
    PostData(criteria, url, function (response) {
        $('.usersResult').html(response.Records.Data);
        $('.usersPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function ResetUserDetails() {
    $("#txtUserName").val("");
    $("#txtFirstName").val("");
    $("#txtLastName").val("");
    $("#ddlStatus").val("All");
    GetUserDetailsInternal(1, '', '');
    return false;
}

function RedirectNewUserDetail() {
    window.location.href = SiteUrl + "/users/manage";
}

function ConfirmDeleteUserDetail(message, userId) {
    ConfirmationBox(message, function () {
        DeleteUserDetail(userId);
    });
    return false;
}

function DeleteUserDetail(userId) {
    var data = new Object();
    data.userId = userId;
    var url = SiteUrl + "/users/deleteuserdetail";
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.reload();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function AssignRolesToUser(UserId) {
    var data = new Object();
    var url = SiteUrl + '/users/assignrole/' + UserId;
    PostJsonGetHtml(data, url, function (response) {
        $('.assignuserrolepopup').html(response);
        $(".assignuserrolepopup").loadpopup();
    });
}

function SaveRolesForUser() {
    var result = $(".userRoleForm").IsValidated();
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }
    var userRole = new Object();
    userRole.UserId = $(".userRoleForm").find("#hdnUserId").val();
    userRole.RoleId = $("#ddlUserRoles").find('option:selected').data("roleid");

    var data = new Object();
    data.userRole = userRole;
    var url = SiteUrl + "/users/assignuserrole/save";
    PostData(data, url, function (response) {
        if (response == true) {
            Message("Record Updated Successfully", function () {
                $(".assignuserrolepopup").hidediv();
            });
        }
        else {
            ErrorBox("Record Updation Failed")
        }

    });
}
