﻿function InitializeCompanyUI() {
    $('#ddlCountry').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'S')
    });

    $('#ddlState').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'C')
    });
    $('#txtEstablishedOn').datepicker({ showAnim: 'slideDown', changeMonth: true, changeYear: true, dateFormat: DateInputFormatJs });
}

function InitializeCompanyInfoUI() {
    $('#ddlCountry').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'S')
    });

    $('#ddlState').on('change', function () {
        var id = $(this).val();
        GetCountryStates(id, 'C')
    });
    $('#CompanyDetails .sortsetting').find('a').click(function () {
        GetCompanyDetailsInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });
}

function SaveCompanyInfo() {
    var validationResponse = $('#CompanyInfo').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message);
        return false;
    }
    url = SiteUrl + "/setup/savecompanyinfo";
    var company = new Object();
    company.CompanyId = $("#CompanyInfo").attr('data-companyid');
    company.Name = $("#txtName").val();
    company.NoOfEmployees = $("#txtNoOfEmployees").val();
    company.Status = $("#chkActive").is(':checked') ? "A" : "I";

    var address = new Object();
    var addresslist = new Array();
    address.AddressId = $("#CompanyInfo").attr('data-addressid');
    address.Address1 = $("#txtAddress1").val();
    address.Address2 = $("#txtAddress2").val();
    address.Country = $("#ddlCountry").find('option:selected').val();
    address.State = $("#ddlState").find('option:selected').val();
    address.City = $("#ddlCity").find('option:selected').val();
    address.Zip = $("#txtZip").val();
    address.AddressType = $("#ddlAddressType").find('option:selected').val();
    address.IsDefault = $("#chkIsdefault").is(':checked') ? true : false;
    address.EntityType = "C";
    addresslist.push(address);

    var data = new Object();
    data.company = company;
    data.addresslist = addresslist;
    data.establishDateString = $("#txtEstablishedOn").val();
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.href = SiteUrl + "/setup/company/list";
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function SearchCompanyDetail() {
    var sortExpression = "";
    var sortDirection = "";
    GetCompanyDetailsInternal(1, sortExpression, sortDirection);
    return false;
}

function GetCompanyDetailsInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/setup/filterCompanyDetails';
    var criteria = new Object();
    criteria.JsFunction = "GetCompanyDetailsInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    criteria.Name = $("#txtName").val();
    criteria.Country = $("#ddlCountry").find('option:selected').val();
    criteria.State = $("#ddlState").find('option:selected').val();
    criteria.City = $("#ddlCity").find('option:selected').val();
    criteria.Status = $("#ddlStatus").find('option:selected').val();
    loading = true;
    PostData(criteria, url, function (response) {
        $('.companyResult').html(response.Records.Data);
        $('.companyPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function ResetCompanyDetails() {
    $("#txtName").val("");
    $("#ddlCountry").val("");
    $("#ddlState").val("");
    $("#ddlCity").val("");
    $("#ddlStatus").val('-1');
    GetCompanyDetailsInternal(1, '', '');
    return false;
}

function RedirectNewCompanyDetail() {
    window.location.href = SiteUrl + "/setup/companyinfo/manage";
}

function ConfirmDeleteCompanyDetail(message, companyId) {
    ConfirmationBox(message, function () {
        DeleteCompanyDetail(companyId);
    });
    return false;
}

function DeleteCompanyDetail(companyId) {
    var data = new Object();
    data.companyId = companyId;
    url = SiteUrl + '/setup/deletecompanydetail';
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.reload();
            });
        }
        else {
            ErrorBox(response.Message);
        }

    });
    return false;
}

/******************************************************************************LookupTypeField********************************************************************************/

function SaveLookupTypeField() {
    var validationResponse = $('#LookupForm').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message);
        return false;
    }
    url = SiteUrl + "/setup/savelookuptypefield";
    var lookupTypeField = new Object();
    lookupTypeField.LookupTypeFieldId = $("#LookupForm").attr('data-id');
    lookupTypeField.LookupType = $("#ddlEntity").find('option:selected').val();
    lookupTypeField.TableName = $("#LookupForm").attr('data-tableName');
    lookupTypeField.ColumnName = $("#txtColumn").val();
    lookupTypeField.DataType = $("#ddlDataType").find('option:selected').val();
    lookupTypeField.ControlType = $("#ddlControlType").find('option:selected').val();
    lookupTypeField.Source = $("#ddlSource").find('option:selected').val();
    lookupTypeField.SourceDisplay = $("#ddlSourceDisp").find('option:selected').val();
    lookupTypeField.SourceValue = $("#ddlSourceValue").find('option:selected').val();
    lookupTypeField.IsDisplayAdd = $("#chkDisInList").attr('data-DisplayinAdd');
    lookupTypeField.IsDisplayList = $("#chkDisInList").is(':checked') ? true : false;
    lookupTypeField.IsRequiredForSave = $("#chkDisInList").attr('data-IsrequiredforSave');
    lookupTypeField.DisplayOrder = $("#txtDispOrder").val();
    lookupTypeField.Status = $("#chkStatus").is(':checked') ? "A" : "I";
    lookupTypeField.Description = $("#txtDescription").val();
    lookupTypeField.CreatedBy = $("#LookupForm").attr('data-createdby');
    lookupTypeField.CreatedOn = $("#LookupForm").attr('data-createdon');
    lookupTypeField.UniqueId = $("#LookupForm").attr('data-uniqueId');

    var data = new Object();
    data.lookupTypeField = lookupTypeField;
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.href = SiteUrl + "/setup/customfields";
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function InitLookupTypeFieldUI() {
    $("#LookupForm").find("#ddlSource").change(function () {
        $("#LookupForm").find("#ddlSourceDisp").val("");
        $("#LookupForm").find("#ddlSourceValue").val("");
    });
    $("#LookupForm").find("#ddlControlType").change(function () {
        ShowHideSources(this);
    })
    $("#LookupForm").find("#ddlControlType").each(function () {
        ShowHideSources(this);
    })

    function ShowHideSources(obj) {
        if ($(obj).val() == "Dropdown") {
            $("#LookupForm").find("#sourceDiv").removeClass('hide');
            $("#LookupForm").find("#sourceDiv #ddlSource").attr("data-r", "Source is Required Please Enter")
            $("#LookupForm").find("#sourceDisplayDiv").removeClass('hide');
            $("#LookupForm").find("#sourceDisplayDiv #ddlSourceDisp").attr("data-r", "Source Display is Required Please Enter")
            $("#LookupForm").find("#sourceValueDiv").removeClass('hide');
            $("#LookupForm").find("#sourceValueDiv #ddlSourceValue").attr("data-r", "Source Value is Required Please Enter")
        }
        else {
            $("#LookupForm").find("#sourceDiv").addClass('hide');
            $("#LookupForm").find("#sourceDisplayDiv").addClass('hide');
            $("#LookupForm").find("#sourceValueDiv").addClass('hide');
        }
    }

    $('.sortlookupTypeField').find('a').click(function () {
        GetLookupTypeFieldInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'));
        return SetFilterText(this);
    });

}

function SearchLookupTypeFields() {
    var sortExpression = "";
    var sortDirection = "";
    GetLookupTypeFieldInternal(1, sortExpression, sortDirection);
    return false;
}

function GetLookupTypeFieldInternal(currentPageIndex, sortExpression, sortDirection) {
    var url = SiteUrl + '/setup/filterlookuptypefields';
    var criteria = new Object();
    criteria.JsFunction = "GetLookupTypeFieldInternal(currentPageIndex)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    criteria.ColumnName = $("#txtColumnName").val();
    criteria.LookupType = $("#ddlLookupType").find('option:selected').val();
    criteria.Status = $("#ddlStatus").find('option:selected').val();
    loading = true;
    PostData(criteria, url, function (response) {
        $('.customFieldResult').html(response.Records.Data);
        $('.customfieldPaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function ResetLookupTypeFields() {
    $("#txtColumnName").val("");
    $("#ddlLookupType").val("");
    $("#ddlStatus").val("");
    GetLookupTypeFieldInternal(1, '', '');
    return false;
}

function RedirectNewLookupTypeField() {
    window.location.href = SiteUrl + "/setup/customfield/manage";
}

function LookupTypeFieldValidation(lookupFieldTypeId) {
    var data = new Object();
    var url = SiteUrl + '/setup/fieldvalidation/' + lookupFieldTypeId;
    PostJsonGetHtml(data, url, function (response) {
        $('.FieldValidationPop').html(response);
        $('.divValidationPopUp').HideCssPopup(false);
        $(".FieldValidationPop").CssPopup();

    });
    return false;
}

function ManageFieldValidation(lookupFieldTypeId, lookupTypeFieldValidationId) {
    $(".divFieldValidation").removeClass("hide");
    var lookupFieldTypeId = lookupFieldTypeId;
    var lookupTypeFieldValidationId = lookupTypeFieldValidationId;
    var EmailTemplateTypeId = $('input:radio[name=typeradio]:checked').val();
    var url = SiteUrl + '/setup/managefieldvalidation/' + lookupFieldTypeId + '/' + lookupTypeFieldValidationId;
    var data = new Object();
    PostJsonGetHtml(data, url, function (response) {
        $('.divFieldValidation').html("");
        $('.divFieldValidation').html(response);
    });
}

function ManageValidation(lookupFieldTypeId, lookupTypeFieldValidationId) {
    $(".divFieldValidation").removeClass("hide");
    var lookupFieldTypeId = lookupFieldTypeId;
    var lookupTypeFieldValidationId = lookupTypeFieldValidationId;
    var EmailTemplateTypeId = $('input:radio[name=typeradio]:checked').val();
    var url = SiteUrl + '/setup/managefieldvalidation/' + lookupFieldTypeId + '/' + lookupTypeFieldValidationId;
    var data = new Object();
    PostJsonGetHtml(data, url, function (response) {
        $('.divValidationPopUp').html(response);
        $(".divValidationPopUp").CssPopup();
    });
}

function InitializeFieldValidation() {
    $(".divbtnhideShow").find("#canceldiv").click(function () {
        $("#btnadd").removeClass("hide");
        $(".divFieldValidation").addClass("hide");
        $('.divValidationPopUp').HideCssPopup(false);
    });

    $("#btnadd").click(function () {
        $("#btnadd").addClass("hide");
    });

    if ($("#ValidationNameDiv").find("#ddlValidation").find('option:selected').val() == "3") {
        $("#FieldValidationForm").find("#MaxlengthDiv").removeClass("hide");
    }
    else if ($("#ValidationNameDiv").find("#ddlValidation").find('option:selected').val() == "1003") {
        $("#FieldValidationForm").find("#minMaxDiv").removeClass("hide");
    }
    else {
        $("#FieldValidationForm").find("#minMaxDiv").addClass("hide");
        $("#FieldValidationForm").find("#MaxlengthDiv").addClass("hide");
    }
    $("#ValidationNameDiv").find("#ddlValidation").change(function () {
        var validationId = $(this).find('option:selected').val();
        var lookupTypeFieldId = $("#FieldValidationForm").attr('data-lookupfieldid');
        CheckValidationUniqueName(validationId, lookupTypeFieldId);
    });
    return false;
}

function CheckValidationUniqueName(validationId, lookupTypeFieldId) {
    var url = SiteUrl + "/setup/checkvalidationuniquename";
    var data = new Object();
    data.validationId = validationId;
    data.lookupTypeFieldId = lookupTypeFieldId
    PostData(data, url, function (response) {
        if (response.IsValid) {
            if (validationId == "3") {
                $("#FieldValidationForm").find("#minMaxDiv").addClass("hide");
                $("#FieldValidationForm").find("#MaxlengthDiv").removeClass("hide");
            }
            else if (validationId == "1003") {
                $("#FieldValidationForm").find("#MaxlengthDiv").addClass("hide");
                $("#FieldValidationForm").find("#minMaxDiv").removeClass("hide");
            }
            else {
                $("#FieldValidationForm").find("#MaxlengthDiv").addClass("hide");
                $("#FieldValidationForm").find("#minMaxDiv").addClass("hide");
            }
        }
        else {
            ErrorBox(response.Message);
            $("#ValidationNameDiv").find("#ddlValidation").val("");
            InitializeFieldValidation();
        }
    });
    return false;
}

function ConfirmDeleteFieldValidation(obj, message, lookupTypeFieldValidationId) {
    ConfirmationBox(message, function () {
        DeleteFieldValidation(obj, lookupTypeFieldValidationId);
    });
    return false;
}

function DeleteFieldValidation(obj, lookupTypeFieldValidationId) {
    var data = new Object();
    data.lookupTypeFieldValidationId = lookupTypeFieldValidationId;
    var url = SiteUrl + '/setup/deletefieldvalidation';
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                $(obj).parents(".Listdiv").remove();
            });
        }
        else {
            ErrorBox(response.Message);
        }

    });
    return false;
}

function SaveFieldValidation() {
    var validationResponse = $('#FieldValidationForm').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message);
        return false;
    }
    url = SiteUrl + "/setup/savefieldvalidation";
    var fieldValidations = new Object();
    fieldValidations.LookupTypeFieldValidationId = $("#FieldValidationForm").attr('data-id');
    fieldValidations.LookupTypeFieldId = $("#FieldValidationForm").attr('data-lookupfieldid');
    fieldValidations.ValidationId = $("#ddlValidation").find('option:selected').val();
    fieldValidations.Min = $("#txtMin").val();
    fieldValidations.Max = $("#txtMax").val();
    fieldValidations.MaxLength = $("#txtMaxLength").val();
    fieldValidations.Status = $("#chkStatus").is(':checked') ? "A" : "I";

    var data = new Object();
    data.fieldValidations = fieldValidations;
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                $(".FieldValidationPop").hidediv();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

/******************************************************************************Controller Class********************************************************************************/
function RedirectNewControllerClass(controllerClassId) {
    if (controllerClassId > 0) {
        window.location.href = SiteUrl + "/setup/controller/manage/" + controllerClassId;
    } else {
        window.location.href = SiteUrl + "/setup/controller/manage";
    }

}

function SaveControllerClass() {
    var result = $("#divAddController").IsValidated();
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }
    var controllerClass = new Object();
    controllerClass.ControllerClassId = $("#divAddController").attr('data-controllerid');
    controllerClass.Name = $("#txtControllerName").val();

    var url = SiteUrl + "/setup/savecontrollerdetail";
    PostData(controllerClass, url, function (response) {
        Message(response.Message, function () {
            window.location.reload();
        });
    });
    return false
}

function DeleteController(message, ControllerClassId) {
    ConfirmationBox(message, function () {
        DeleteControllerDetail(ControllerClassId);
    });
}

function DeleteControllerDetail(ControllerClassId) {
    var url = SiteUrl + '/setup/deletecontrollerdetail';
    var data = new Object();
    data.ControllerClassId = ControllerClassId;
    PostData(data, url, function (response) {
        if (response != 0) {

            Message(RecordDelMsg, function (res) {
                window.location.reload();
            })

        }
        else {
            ErrorBox(ReferenceRemoveMsg);
        }
    });
}

function AssignActionMethod(FunctionalityId) {
    var data = new Object();
    var url = SiteUrl + '/setup/assignactionmethod/' + FunctionalityId;

    PostJsonGetHtml(data, url, function (response) {
        $('.assignactionmethodPopup').html(response);
        initActionManagement();
        $(".assignactionmethodPopup").loadpopup();
    });
}

function SaveAssignActionMethod() {
    var result = $("#divActionFunctionality").IsValidated();
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }

    var url = SiteUrl + '/setup/saveassignedactionmethod';
    var data = new Object();
    data.FunctionalityId = $('#hdnActFunctionalityId').val();
    data.ActionMethodId = $('#ddlFunActionmethod').find('option:selected').val();

    PostData(data, url, function (response) {
        if (response == true) {
            Message("Action Method Assigned Successfully", function (res) {
                window.location.reload();
            })
        }
    })
}

function initActionManagement() {
    $('#ddlControllerClass').change(function () {
        var ControllerClassId = $(this).find('option:selected').val();
        var url = SiteUrl + '/setup/loadactionmethod/' + ControllerClassId;
        var data = new Object();
        PostJsonGetHtml(data, url, function (response) {
            $('.divActionMethodList').html("");
            $('.divActionMethodList').html(response);
            initActionManagement();
        });
    });

    $('#ddlFunActionmethod').change(function () {

        var url = SiteUrl + '/setup/checkuniquefunctionality';
        var data = new Object();
        data.FunctionalityId = $('#hdnActFunctionalityId').val();
        data.ActionMethodId = $(this).find('option:selected').val();
        var actionname = $(this).find('option:selected').text();
        PostData(data, url, function (response) {
            if (response == 0) {
                Message(actionname + " is already assigned", function (res) {
                    $('#ddlFunActionmethod').val("");
                });

            }
        });
    });
}


/****************************************************************************** Action method******************************************************************************/
function RedirectNewActionMethod(controllerClassId, actionMethodId) {
    if (actionMethodId > 0) {
        window.location.href = SiteUrl + "/setup/action/manage/" + controllerClassId + "/" + actionMethodId;
    }
    else {
        window.location.href = SiteUrl + "/setup/action/manage/" + controllerClassId;
    }
}

function SaveActionMethod() {
    var validationResponse = $('#ActionMethodDetail').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message)
        return false;
    }
    url = SiteUrl + "/setup/saveactionmethod";

    var action = new Object();
    action.ActionMethodId = $("#ActionMethodDetail").attr('data-id');
    action.ControllerClassId = $("#ActionMethodDetail").attr('data-controllerClassId');
    action.Name = $("#txtActionMethodName").val();
    action.DisplayName = $("#txtDisplayName").val();
    action.DispalyAsMenu = $("#chkDispalyAsMenu").is(':checked') ? "A" : "I";
    action.Status = $("#chkStatus").is(':checked') ? "A" : "I";

    var data = new Object();
    data.actionMethod = action;
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.href = SiteUrl + "/setup/action/list";
            })
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

/***********************************************************Role Management*****************************************************/

function AddRole(RoleId) {
    var data = new Object();
    var url = SiteUrl + '/setup/role/add/';
    if (RoleId > 0)
        url = url + RoleId;

    PostJsonGetHtml(data, url, function (response) {
        $('.addnewRolePopup').html(response);
        $(".addnewRolePopup").loadpopup();
    });
}

function LoadRolePopup(primarykey) {
    $('#RoleLn' + primarykey).loadpopup();
}

function SaveRole(LnTable) {
    var result = $("#divAddRole").IsValidated();
    if (result.IsValid == false) {
        ErrorBox(result.Message);
        return false;
    }
    var url = SiteUrl + '/setup/role/save';
    var role = new Object();
    var roleLn = new Object();
    role.RoleId = $('#divAddRole').attr('data-id');
    role.RoleType = $("#divAddRole").data('roleType');

    roleLn.Name = $("#txtRoleName").val();
    var data = new Object();
    data.role = role;
    data.roleLn = roleLn;
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.reload();
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
}

/*****************************************************************Rights*************************************************************/
function InitRights() {
    $(".nav-button").click(function () {
        $(".nav-button,.primary-nav").toggleClass("open");
    });
}

function SaveRightManage() {
    var validationResponse = $('#rightDetail').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message)
        return false;
    }

    var right = new Object();
    right.RightId = $("#rightDetail").attr('data-id');
    right.RightType = $('#ddlRightType').find('option:selected').val();
    var rightLn = new Object();
    rightLn.Name = $("#txtRightName").val();
    rightLn.RightId = $("#rightDetail").attr('data-id');
    var data = new Object();
    data.right = right;
    data.rightLn = rightLn
    url = SiteUrl + "/setup/right/save";
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.href = SiteUrl + "/setup/rights/management";
            })
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function AssignRights(functionalityId) {
    var data = new Object();
    var url = SiteUrl + '/setup/right/assign/';
    url = url + functionalityId;
    PostJsonGetHtml(data, url, function (response) {
        $('.rightpopup').html(response);
        $(".rightpopup").loadpopup();
    });
}

function SaveAssignedRights(FunctionalityId) {
    var funRightsList = new Array();
    var funRights = new Object();
    $('.funRightsList').find($("input[id='cbkRightsId']:checked")).each(function () {
        funRights = new Object();
        funRights.FunctionalityId = FunctionalityId;
        funRights.RightId = $(this).val();
        funRightsList.push(funRights);
    });
    var data = new Object();
    data.funRightsList = funRightsList;
    var url = SiteUrl + "/setup/functionalityrights/save";
    PostData(data, url, function (response) {
        Message("Record Updated Succesfully", function () {
            window.location.reload();
        });
    });

}

function AddRights(rightsId) {
    var url = SiteUrl + '/setup/right/manage';
    if (rightsId > 0)
        url = url + '/' + rightsId;
    location.href = url;

}

/***********************************************************Functionality & Group**************************************************************/

function InitFunctionality() {
    $(".nav-button").click(function () {
        $(".nav-button,.primary-nav").toggleClass("open");
    });
}

function AddFunctionalityGroup(functionalityGroupId) {
    var url = SiteUrl + '/setup/functionalitygroup/';
    if (functionalityGroupId > 0)
        location.href = url + functionalityGroupId;
    else
        location.href = url
}

function SaveFunctionalityGroupDetail() {
    var validationResponse = $('#FunctionalityGroupDetail').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message)
        return false;
    }

    var funGroup = new Object();
    funGroup.FunctionalityGroupId = $("#FunctionalityGroupDetail").attr('data-id');
    funGroup.Status = $("#chkStatus").is(':checked') ? "A" : "I";
    var funGroupLn = new Object();
    funGroupLn.Name = $("#txtFunctionalityGroup").val();
    funGroupLn.FunctionalityGroupId = $("#FunctionalityGroupDetail").attr('data-id');
    var data = new Object();
    data.functionalityGroup = funGroup;
    data.functionalityGroupLn = funGroupLn
    url = SiteUrl + "/setup/savefunctionalitygroup";
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.href = SiteUrl + "/setup/functionality/management";
            })
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function AddFunctionality(functionalityId, functionalityGroupId) {
    var url = SiteUrl + '/setup/functionality/manage/';
    if (functionalityId > 0)
        location.href = url + functionalityGroupId + '/' + functionalityId;
    else
        location.href = url + functionalityGroupId;
}

function SaveFunctionality() {
    var validationResponse = $('#functionalityDetail').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message)
        return false;
    }

    var fun = new Object();
    fun.FunctionalityId = $("#functionalityDetail").attr('data-id');
    fun.FunctionalityGroupId = $("#ddlFunctionalityGroup").find('option:selected').val();
    fun.Name = $("#txtFunctionality").val();
    fun.Status = $("#chkStatus").is(':checked') ? "A" : "I";

    var data = new Object();
    data.functionality = fun;

    url = SiteUrl + "/setup/functionality/save";
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.href = SiteUrl + "/setup/functionality/management";
            })
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function DeleteFunctionalityGroup(message, FunctionalityGroupId) {
    ConfirmationBox(message, function () {
        DeleteFunctionalityGroupDetail(FunctionalityGroupId);
    });
}

function DeleteFunctionalityGroupDetail(FunctionalityGroupId) {
    var url = SiteUrl + '/setup/deletefunctionalitydetail';
    var data = new Object();
    data.FunctionalityGroupId = FunctionalityGroupId;
    PostData(data, url, function (response) {
        if (response != 0) {

            Message(RecordUpdationMsg, function (res) {
                window.location.reload();
            })

        }
        else {
            ErrorBox(ReferenceRemoveMsg);
        }
    });
}

/***********************************************************Menu Management*****************************************************/

function CreateMenu(MenuId, ParentId, MenuType) {
    if (ParentId > 0 && MenuId > 0)
    {
        location.href = SiteUrl + '/setup/menu/add/' + MenuType + "/" + ParentId + "/" + MenuId;
    }
    else if(MenuId > 0)
    {
        location.href = SiteUrl + '/setup/menu/add/' + MenuType + "/" + ParentId + "/" + MenuId;
    }
    else {
        location.href = SiteUrl + '/setup/menu/add/' + MenuType;
    }
}

function SaveMenuManage() {
    var validationResponse = $('#menuDetail').IsValidated();
    if (!validationResponse.IsValid) {
        ErrorBox(validationResponse.Message)
        return false;
    }
    var menu = new Object();
    menu.MenuId = $("#menuDetail").attr('data-id');
    menu.ActionMethodId = $("#ddlActionMethod").find('option:selected').val();
    menu.ReferenceId = $("#menuDetail").attr('data-referenceId');

    menu.MenuType = $('#ddlMenuType').find('option:selected').val();
    menu.ParentId = $('#ddlParentId').find('option:selected').val();

    menu.DisplayOrder = $("#txtDisplayOrder").val();
    menu.MenuURL = $("#txtMenuUrl").val();


    var menuLn = new Object();
    menuLn.DisplayName = $("#txtMenuName").val();
    menuLn.MenuId = $("#menuDetail").attr('data-id');
    var data = new Object();
    data.menu = menu;
    data.menuLn = menuLn
    url = SiteUrl + "/setup/menu/save";
    PostData(data, url, function (response) {
        if (response.IsValid) {
            Message(response.Message, function () {
                location.href = SiteUrl + "/setup/menu/manage";
            });
        }
        else {
            ErrorBox(response.Message);
        }
    });
    return false;
}

function initMenuManagement() {
    $('#ddlControllerClass').change(function () {
        var ControllerClassId = $(this).find('option:selected').val();
        var url = SiteUrl + '/setup/loadaction/' + ControllerClassId;
        var data = new Object();
        PostJsonGetHtml(data, url, function (response) {
            $('.divActionMethodList').html("");
            $('.divActionMethodList').html(response);
            initMenuManagement();
        });
    });
}

function DeleteMenu(message, MenuId) {
    ConfirmationBox(message, function () {
        DeleteMenuDetail(MenuId);
    });
}

function DeleteMenuDetail(MenuId) {

    var url = SiteUrl + '/setup/menu/delete';
    var data = new Object();
    data.MenuId = MenuId;
    PostData(data, url, function (response) {
        if (response != 0) {
            //$('.divBed' + BedId).remove();
            Message(RecordDelMsg, function () {
            });
        }
        else {

            ErrorBox(ReferenceRemoveMsg);
        }
    });

}

function initMenuType() {
    $('#ddlMenuType').change(function () {
        var data = new Object();
        data.MenuType = $(this).find('option:selected').val();
        var url = SiteUrl + "/setup/loadmenu";
        PostData(data, url, function (response) {
            $('.divMenuManage').html("");
            $('.divMenuManage').html(response.Value1.Data);
        });
    });
}

/***************************************************************** Role RIghts*************************************************************/
function SaveRoleRights() {
    var functionalityRoles = new Array();
    var funRole = new Object();
    var RoleId = $('#ddlRole').find('option:selected').val();
    //if (RoleId == "4") {
    //    return false;
    //}

    $('.divFunctionality').each(function () {
        $(this).find('.divFunRights').find($("input[id^='cbkFunRights']:checked")).each(function () {
            funRole = new Object();
            funRole.FunctionalityId = $(this).parents('.divFunctionality').attr('data-funid');
            funRole.RoleId = RoleId;
            funRole.RightId = $(this).val();
            functionalityRoles.push(funRole);
        });
    });
    var data = new Object();
    data.functionalityRoles = functionalityRoles;
    var url = SiteUrl + "/setup/rolerights/save";
    PostData(data, url, function (response) {

        Message("Record Updated Succesfully", function () {
            location.reload();
        });
    });
}

function InitRoleFunctionality() {
    $('#ddlRole').change(function () {
        //if ($('#ddlRole').find('option:selected').val() == "4") {
        //    $(".forSaveRights").addClass("hide");
        //}
        //else {
        //    $(".forSaveRights").removeClass("hide");
        //}
        var data = new Object();
        data.RoleId = $(this).find('option:selected').val();
        var url = SiteUrl + "/setup/loadrolerights";
        PostData(data, url, function (response) {
            $('.divRoleRightsManage').html("");
            $('.divRoleRightsManage').html(response.Value1.Data);
        });
    })
}
