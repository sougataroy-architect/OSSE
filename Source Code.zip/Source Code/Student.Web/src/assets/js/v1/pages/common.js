﻿(function ($) {
    $.fn.GetSearchCriteria = function () {
        var criteria = new Object();
        $($(this).find('input[type=text],select')).each(function () {
            var element = $(this);
            criteria[element.attr('data-sfield')] = element.val();
        });
        return criteria;
    }
    $.fn.ResetSearchCriteria = function () {
        $($(this).find('input[type=text],select')).each(function () {
            var element = $(this);
            element.val('');
        });
    }
    $.fn.BindTinyMCE = function () {
        tinymce.init({
            mode: "exact",
            elements: this.attr("id"), //id of the textarea(s) If multiple, need to have comma separated
            editor_selector: "textarea",
            height: $(this).attr("height"),
            convert_urls: false,
            //plugins: [
            ////    "advlist autolink lists link image charmap print preview anchor",
            ////    "searchreplace visualblocks code fullscreen",
            ////    "insertdatetime media table contextmenu paste"
            //"code image fullscreen preview link textcolor "
            //],
            plugins: ["code link image textcolor"],
            menubar : false,
            //toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image unsubscribe",
            toolbar: "bold italic forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image code",
            setup: function (ed) {
                // Add a custom button
                ed.addButton('unsubscribe', {
                    title: 'Add unsubscribe link',
                    image: '../../content/images/unsubscribe.png',
                    onclick: function () {
                        // Add you own code to execute something on click
                        ed.focus();
                        ed.selection.setContent('<a href="#UNSUBSCRIBE_LINK#">unsubscribe</a>');
                    }
                });
            }
        });
    };
})(jQuery);
$(document).ready(function () {
    setTimeout(SetHeight, 100);
});
function SetHeight() {
    var docHeight = $(window).height();
    var footerHeight = $('#footer').height();
    var footerTop = $('#footer').position().top + footerHeight;
    if (footerTop < docHeight) {
        $('#footer').css('margin-top', (docHeight - footerTop - 40) + 'px');
    }
}
function ClearCombo(controlId) {
    $('#' + controlId).find("option").remove();
}
function ClearComboAddDefault(controlId) {
    ClearCombo(controlId);
    $('<option>').val("0").text("Select").appendTo('#' + controlId);
}
function LoadLookup(targetControlId, parentLookupId, lookupTypeId) {
    ClearCombo(targetControlId);
    var url = SiteUrl + "/setup/getlookup";
    var data = new Object();
    data.lookupTypeId = lookupTypeId;
    data.parentLookupId = parentLookupId;
    PostData(data, url, function (response) {
        $.each(response, function () {
            $('<option>').val(this.Value).text(this.Text).appendTo('#' + targetControlId);
        });
    });
}
function LoadLookupPickUp(targetControlId, source, lookupTypeId) {
    LoadLookup(targetControlId, parseInt($(source).val()), lookupTypeId);
}
function SetFilterText(element) {
    if ($('.selected-filter').length > 0)
        $('.selected-filter').text($(element).text());
    return false;
}
function ParseSaveResponse(container, data, successCallBack) {
    if (data.SessionStatusCode != undefined) {
        MessageBox(data.SessionStatusMessage, function (popup) {
            HideMsgBox(popup, function () {
                window.location = SiteUrl + "/login";
            });
        });
    }
    else
        container.ParseResponse(data, successCallBack);
}
function LoadStates(source) {
    LoadLookup('ddlState', parseInt($(source).val()), 2);
}
function DisplayMessage(message,messageType) {
    alert(message);
}
function ConfirmOnDelete() {
    if (confirm("Are you sure to delete?") == true)
        return true;
    else
        return false;
}
function ShowLoader()
{
    debugger;
    $('#loaderbg').removeClass('hide');
    //$('.loaderimg').removeClass('hide');
}
function HideLoader() {
    $('.loaderimg').addClass('hide');
}
function LoadtinymcePopupFields() {
    $("body").find('textarea.editor[data-isfield = "true"]').each(function () {
        var langid = $(this).attr("data-langid") == null ? "1" : $(this).attr("data-langid");
        tinymce.remove("#" + $(this).attr("id"));     
        $(this).BindTinyMCE();

    });
}

//(function ($) {
//    $.fn.BindTinyMCE = function () {
//        alert('bind2');
//        tinymce.init({
//            mode: "exact",
//            plugins: [
//           //    "advlist autolink lists link image charmap print preview anchor",
//           //    "searchreplace visualblocks code fullscreen",
//           //    "insertdatetime media table contextmenu paste"
//           "code image fullscreen preview link textcolor "
//            ],
//            toolbar:"",
//            elements: $(this).attr("id"), //id of the textarea(s) If multiple, need to have comma separated
//            editor_selector: "textarea",
//            height: $(this).attr("height"),
//            language: ($(this).attr("data-langid") == null || $(this).attr("data-langid") != 2) ? "en" : "ar",
//            directionality: ($(this).attr("data-langid") == null || $(this).attr("data-langid") != 2) ? "ltr" : "rtl"
//            //toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
//        });
//    };
//})(jQuery);

