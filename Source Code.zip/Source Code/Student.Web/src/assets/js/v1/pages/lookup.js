﻿function InitializeLookupUI() {
    $('#lookup .sorting').find('a').click(function () {
        GetLookupsInternal(1, $(this).attr('data-sortexpr'), $(this).attr('data-sortdir'), $('#hdnType').val());
        SetFilterText(this);
    });
}
function GetLookupsInternal(currentPageIndex, sortExpression, sortDirection, type) {
    var url = SiteUrl + '/setup/filterlookup';
    var criteria = $('#lookup .filter').GetSearchCriteria();
    criteria.Type = type;
    criteria.JsFunction = "GetLookups(currentPageIndex,type)";
    criteria.PageIndex = currentPageIndex;
    criteria.PageSize = 6;
    if (sortExpression != undefined)
        criteria.SortExpression = sortExpression;
    if (sortDirection != undefined)
        criteria.SortDirection = sortDirection;
    loading = true;
    PostData(criteria, url, function (response) {
        $('#lookup .lookupitems').html(response.Records.Data);
        $('#lookup .lookuppaging').html(response.Paging.Data);
        loading = false;
    });
    return false;
}

function GetLookups(currentPageIndex, type) {
    return GetLookupsInternal(currentPageIndex, '', '', $('#hdnType').val());
}

function SearchLookups(type) {
    return GetLookups(1, type);
}
function ResetLookups(type) {
    $('#lookup .filter').ResetSearchCriteria();
    return SearchLookups(type);
}
function GetLookupItems() {
    var items = [];
    $($("#managelookup").find("input[data-IsRequiredForSave='True'],textarea[data-IsRequiredForSave='True'],select[data-IsRequiredForSave='True']")).each(function () {
        var value = "";
        if (this.type == 'checkbox')
            value = $(this).is(':checked') ? "A" : "I";
        else
            value = $(this).val().toString();
        var oldValue = $(this).attr('data-OldValue');
        if (oldValue == undefined)
            oldValue = "";
        if (oldValue != value || (value != "" && value != null && typeof value != typeof undefined)) {
            items.push({ FieldId: $(this).data("fieldid"), Value: value });
        }
    });

    var data = new Object();
    data.LookupTypeId = $('#managelookup').data("ltypeid");
    data.LookupId = $('#managelookup').data("lookupid");
    data.Data = items;
    return data;
}
function SaveCustomFields(LookupId, callBackFunction) {
    $('#managelookup').attr("data-lookupid", LookupId);
    var data = GetLookupItems();
    if (data.Data.length == 0) {
        if ($.isFunction(callBackFunction) == true) {
            callBackFunction(true);
            return;
        }
    }
    var url = SiteUrl + '/setup/savecustomfield';
    PostData(data, url, function (response) {
        if (response.IsValid == true) {
            if ($.isFunction(callBackFunction) == true) {
                callBackFunction(response);
            }
        }
        else {
            callBackFunction(response);
        }
    });

}
function SaveLookup() {
    var data = GetLookupItems();
    var url = SiteUrl + '/setup/savelookup';
    PostData(data, url, function (response) {
        $('#managelookup .erroron').each(function () {
            $(this).removeClass('erroron');
            $(this).removeAttr('title');
        });
        ParseSaveResponse($('#managelookup'), response, function (response2) {
            if (response2.IsValid) {
                location.href = $('.canlce-btn').attr('href');
            }
            //else {
            //    HideMsgBox(response2);
            //}
        });

    });
    return false;
}
function AddNewLookup(type) {
    location.href = SiteUrl + '/setup/' + type + '/manage'
    return false;
}