﻿using Student.BL.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Student.BL
{
    public interface IRepository<C, T>
        where C : Microsoft.EntityFrameworkCore.DbContext
        where T : class
    {
        C Context { get; set; }
        IQueryable<T> ObjectSet { get; set; }
        IQueryable<T> Select();
        int Save(T entity);
        bool Delete(List<Int32> recordIds);
    }
    public class RepositoryBase<T> : IRepository<BL.Data.ApiContext, T>
       where T : class, IEntity
    {
        public Int64 RecordId { get; internal set; }
        public Int32 LanguageId { get; internal set; }
        public BL.Data.ApiContext Context { get; set; }
        public IQueryable<T> ObjectSet { get; set; }
        public RepositoryBase()
        {
            var builder = new DbContextOptionsBuilder<ApiContext>();
            builder.UseInMemoryDatabase("Students");
            Context = new ApiContext(builder.Options);
            //Context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            ObjectSet = GetQuery();
        }
        public IQueryable<T> Select()
        {
            return ObjectSet;
        }
        internal virtual IQueryable<T> GetQuery()
        {
            return Context.Set<T>().AsQueryable();
        }
        public virtual int Insert(T entity)
        {
            try
            {
                var newEntry = Context.Set<T>().Add(entity);
                Context.SaveChanges();
                return newEntry.Entity.Id;
            }
            catch (DbUpdateException ex)
            {
                return -1;
            }
        }

        public virtual int Update(T entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");

            try
            {
                var entry = Context.Entry(entity);

                try
                {
                    var set = Context.Set<T>();
                    T attachedEntity = set.FirstOrDefault(s => s.Id == entity.Id);// .Find(pKey);  // access the key
                    if (attachedEntity != null)
                    {
                        var attachedEntry = Context.Entry(attachedEntity);
                        attachedEntry.CurrentValues.SetValues(entity);
                    }
                    else
                    {
                        entry.State = EntityState.Modified; // attach the entity
                    }
                }
                catch (Exception ex)
                {

                }
                return this.Context.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                return -1;
            }
        }
        public int Save(T entity)
        {
            if (entity.Id == 0)
                return Insert(entity);
            else
                return Update(entity);
        }
        public virtual void Delete(T entity)
        {
            // Entities.Remove(entity);
            Context.Set<T>().Remove(entity);
            Context.SaveChanges();
        }
        internal IQueryable<T> Get(
        Expression<Func<T, bool>> filter = null,
        Func<IQueryable<T>,
            IOrderedQueryable<T>> orderBy = null,
        List<Expression<Func<T, object>>>
            includeProperties = null,
        int? page = null,
        int? pageSize = null)
        {
            IQueryable<T> query = ObjectSet;

            if (includeProperties != null)
                includeProperties.ForEach(i => { query = query.Include(i); });

            if (filter != null)
                query = query.Where(filter);

            if (orderBy != null)
                query = orderBy(query);

            if (page != null && pageSize != null)
                query = query
                    .Skip((page.Value - 1) * pageSize.Value)
                    .Take(pageSize.Value);

            return query;
        }

        public System.Collections.Generic.List<SqlParameter> GetObjectParameters(object obj)
        {
            var prms = new System.Collections.Generic.List<SqlParameter>();
            var objProps = System.ComponentModel.TypeDescriptor.GetProperties(obj);
            var allowedTypes = new System.Collections.Generic.List<Type>() { typeof(int),typeof(int?), typeof(Int64), typeof(Int64?),typeof(byte),typeof(byte?),
                typeof(bool),typeof(bool?), typeof(DateTime), typeof(DateTime?), typeof(double),typeof(double?), typeof(decimal),typeof(decimal?),
                typeof(string), typeof(TimeSpan) , typeof(TimeSpan?),typeof(System.Guid)  };
            var props = obj.GetType().GetProperties().OrderBy(d => d.MetadataToken);
            string primaryKey = props.FirstOrDefault().Name.Replace("@", "");
            foreach (var prop in props.Where(pt => allowedTypes.Contains(pt.PropertyType)))
            {
                //  throw new NotImplementedException("Add Ignore attribute logic here");
                if (prop.Name == "S" + primaryKey) continue;
                var value = objProps[prop.Name].GetValue(obj);
                if (value == null)
                    value = string.Empty;
                prms.Add(new SqlParameter("@" + prop.Name, value));
            }
            return prms;
        }
        protected String GetArgs(List<SqlParameter> prms)
        {
            string args = string.Join(",", prms.Select(p => String.Format("{0}={0}", p.ParameterName)));
            return args;
        }
        public List<T> ExecuteSqlProcedure<T>(string query, Func<System.Data.Common.DbDataReader, T> map, params SqlParameter[] parameters)
        {
            return SqlQuery<T>(query, map, System.Data.CommandType.StoredProcedure, parameters);
        }
        public List<T> ExecuteSqlQuery<T>(string query, Func<System.Data.Common.DbDataReader, T> map, params SqlParameter[] parameters)
        {
            return SqlQuery<T>(query, map, System.Data.CommandType.Text, parameters);
        }
        private List<T> SqlQuery<T>(string query, Func<System.Data.Common.DbDataReader, T> map, System.Data.CommandType commandType, params SqlParameter[] parameters)
        {
            using (var command = Context.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = query;
                command.CommandType = commandType;
                command.Parameters.AddRange(parameters);
                Context.Database.OpenConnection();

                using (var result = command.ExecuteReader())
                {
                    var entities = new List<T>();

                    while (result.Read())
                    {
                        entities.Add(map(result));
                    }

                    return entities;
                }
            }
        }
        
        public bool Delete(List<Int32> recordIds)
        {
            try
            {
                recordIds.ForEach(id =>
                {
                    var entity = (T)Activator.CreateInstance(typeof(T));
                    //SetPrimaryKeyValue(entity, id);
                    entity.Id = id;
                    Context.Entry(entity).State = EntityState.Deleted;
                });
                return Context.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                // LogWriter.WriteLogEntry("Delete", ex, CRMSystem.Global.Lib.Enums.LogWriterModule.Administration);
                return false;
            }
        }
    }
}
