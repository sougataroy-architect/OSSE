﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;

namespace Student.BL
{
    public interface IStudentRepository: IRepository<Data.ApiContext,Data.Student>
    {

    }

    public class StudentRepository:RepositoryBase<Data.Student >, IStudentRepository
    {

    }
}
