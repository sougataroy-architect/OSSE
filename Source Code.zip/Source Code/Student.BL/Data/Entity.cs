﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Student.BL.Data
{
    public interface IEntity
    {
        int Id { get; set; }
    }

    public partial class Student : IEntity { };
}
