﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Student.BL.Data
{
    public partial class Student
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public int Grade { get; set; }
        public string School { get; set; }
    }
}
