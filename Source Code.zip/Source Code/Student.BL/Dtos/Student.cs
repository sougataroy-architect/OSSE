﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Student.BL.Dtos
{
    public partial class Student
    {
        public int Id { get; set; }
    }
}
