﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Student.Api.Lib;
using Student.BL.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace Student.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : BaseApiController
    {
        private BL.Data.ApiContext _context;
        private readonly BL.IStudentRepository _studentRepository;
        public StudentController(BL.Data.ApiContext context, BL.IStudentRepository studentRepository)
        {
            _context = context;
           // _studentRepository = studentRepository;
        }


        [HttpPost("GetStudents")]
        public IEnumerable<BL.Data.Student> GetStudents([FromBody]StudentModel searchResult)
        {
            var grade = -1;
            if (!int.TryParse(searchResult.Search.Grade, out grade))
            {
                grade = -1;
            }

            return _context.Students.Where(x=> 
            (searchResult.Search.Name != "" ? x.Name.Contains(searchResult.Search.Name) : "1" == "1") 
            &&
            grade == (grade > 0 ? x.Grade : -1)
            &&
            (searchResult.Search.School != "" ? x.Name.Contains(searchResult.Search.School) : "1" == "1"));
            //return _studentRepository.Select();
        }

        [HttpPost]
        public IActionResult AddStudent(BL.Data.Student student)
        {
            if (student == null)
                return BadRequest();
            if(student.Id == 0)
            {
                _context.Students.Add(student);
                _context.SaveChanges();
            }
            else
            {
                var dbStudent = _context.Students.FirstOrDefault(x => x.Id == student.Id);
                if (dbStudent == null)
                    return NotFound();

                ////_studentRepository.Save(student);
                dbStudent.Name = student.Name;
                dbStudent.Grade = student.Grade;
                dbStudent.School = student.School;

                _context.Students.Update(dbStudent);
                _context.SaveChanges();
            }
            //_studentRepository.Save(student);
            
            return Ok(new { id = student.Id });
        }

        [HttpGet("{id}")]
        public BL.Data.Student GetStudent(int id)
        {
            BL.Data.Student student = new BL.Data.Student();
            //_studentRepository.Save(student);
            if (_context.Students.Where(s => s.Id == id).Any())
            {
                student = _context.Students.Where(s => s.Id == id).FirstOrDefault();
            }
            else
            {
                student = new BL.Data.Student() { Id = 1, Grade = 10, Name = "Test11", School = "School11" };
            }
            return student;
        }

        [HttpPut("{id}")]
        public IActionResult UpdateStudent(int id, [FromBody] BL.Data.Student student)
        {
            if (student == null || student.Id != id)
                return BadRequest();

            //var dbStudent = _studentRepository.Select().FirstOrDefault(x => x.Id == student.Id);
            var dbStudent = _context.Students.FirstOrDefault(x => x.Id == student.Id);
            if (dbStudent == null)
                return NotFound();

            //_studentRepository.Save(student);
            dbStudent.Name = student.Name;
            dbStudent.Grade = student.Grade;
            dbStudent.School = student.School;

            _context.Students.Update(dbStudent);
            _context.SaveChanges();
            return Ok();
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            //var dbStudent = _studentRepository.Select().FirstOrDefault(x => x.Id == id);
            var dbStudent = _context.Students.FirstOrDefault(x => x.Id == id);
            if (dbStudent == null)
                return NotFound();

            //_studentRepository.Delete(new List<int>{id });
            _context.Students.Remove(dbStudent);
            _context.SaveChanges();

            return Ok();
        }
    }
}