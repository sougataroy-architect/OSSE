﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Student.Api.Infrastructure.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Student.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseApiController : ControllerBase
    {
        public new AppPrincipal User
        {
            get
            {
                var user = HttpContext.User;
                if (user != null)
                {
                    var employeeIdVal = HttpContext.User.Claims.FirstOrDefault(c => c.Type.ToString().Contains("name") && !c.Type.ToString().Contains("nameidentifier"));

                    var userIdVal = HttpContext.User.Claims.FirstOrDefault(c => c.Type.ToString().Contains("nameidentifier"));
                    int userId = 0;
                    int employeeId = 0;
                    int.TryParse(employeeIdVal.Value, out employeeId);
                    if (userIdVal != null && int.TryParse(userIdVal.Value, out userId))
                    {
                        return new AppPrincipal(userId, HttpContext.User.Claims.Where(c => c.Type == ClaimTypes.Role).Select(c => c.Value).ToList(), HttpContext.User.Identity);
                    }
                }
                return null;// base.User as AppPrincipal;
            }
        }
    }
}