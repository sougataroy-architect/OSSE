﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Student.Api.Lib
{
    public class StudentModel
    {
        public StudentSearchModel Search { get; set; }
        public Paging Paging { get; set; }
    }
    public class Paging
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public string JsFunction { get; set; }
        public string Parameters { get; set; }
        public int TotalRecords { get; set; }
        
    }
    public class StudentSearchModel
    {
        public string Name { get; set; }
        public string Grade { get; set; }
        public string School { get; set; }
    }


}
