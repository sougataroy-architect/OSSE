﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Student.Api.Lib
{
    public class Constants
    {
        public const string DataSavedSuccessfully = "Data Saved Successfully.";
        public const string DataUpdatedSuccessfully = "Data Updated Successfully.";
        public const string DataDeletedSuccessfully = "Data Deleted Successfully.";
        public const string ErrorConnectingServer = "Error connecting server, Please try again later.";
        public const string UserAlreadyTaken = "User already taken.";
        public const string UserNameExists = "UserName already exists.";
    }
}
