﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;

namespace Student.Api.Infrastructure.Authorization
{
    public class AppPrincipal : GenericPrincipal
    {
        public int Id { get; private set; }
        //public string Email { get; set; }
        public List<string> Roles { get; private set; }
        public AppPrincipal(int id, List<String> roles, /*string email, */IIdentity identity) : base(identity, roles.ToArray())
        {
            Id = id;
            Roles = roles;
            //Email = email;
        }
    }
}
