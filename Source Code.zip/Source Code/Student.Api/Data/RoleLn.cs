﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class RoleLn
    {
        public int RoleId { get; set; }
        public int LanguageId { get; set; }
        public string Name { get; set; }

        public virtual Language Language { get; set; }
        public virtual Role Role { get; set; }
    }
}
