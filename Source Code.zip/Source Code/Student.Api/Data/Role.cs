﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class Role
    {
        public Role()
        {
            Menu = new HashSet<Menu>();
            RoleFunctionality = new HashSet<RoleFunctionality>();
            RoleLn = new HashSet<RoleLn>();
        }

        public int Id { get; set; }
        public string Status { get; set; }
        public string RoleType { get; set; }
        public string IsDefault { get; set; }
        public int? CreatedBy { get; set; }

        public virtual ICollection<Menu> Menu { get; set; }
        public virtual ICollection<RoleFunctionality> RoleFunctionality { get; set; }
        public virtual ICollection<RoleLn> RoleLn { get; set; }
    }
}
