﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class Menu
    {
        public Menu()
        {
            MenuLn = new HashSet<MenuLn>();
            MenuRights = new HashSet<MenuRights>();
        }

        public int MenuId { get; set; }
        public int? ParentId { get; set; }
        public int? FunctionalityId { get; set; }
        public string MenuType { get; set; }
        public int DisplayOrder { get; set; }
        public string MenuUrl { get; set; }
        public string DisplayHtml { get; set; }
        public int? TotalChilds { get; set; }
        public int? ReferenceId { get; set; }
        public string ClassName { get; set; }
        public int RoleId { get; set; }

        public virtual ActionMethod Functionality { get; set; }
        public virtual Functionality FunctionalityNavigation { get; set; }
        public virtual Role Role { get; set; }
        public virtual ICollection<MenuLn> MenuLn { get; set; }
        public virtual ICollection<MenuRights> MenuRights { get; set; }
    }
}
