﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Student.Api.Data
{
    public partial class FFVSContext : DbContext
    {
        public FFVSContext()
        {
        }

        public FFVSContext(DbContextOptions<FFVSContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ActionMethod> ActionMethod { get; set; }
        public virtual DbSet<Album> Album { get; set; }
        public virtual DbSet<ControllerClass> ControllerClass { get; set; }
        public virtual DbSet<Functionality> Functionality { get; set; }
        public virtual DbSet<FunctionalityAction> FunctionalityAction { get; set; }
        public virtual DbSet<FunctionalityGroup> FunctionalityGroup { get; set; }
        public virtual DbSet<FunctionalityGroupLn> FunctionalityGroupLn { get; set; }
        public virtual DbSet<FunctionalityRights> FunctionalityRights { get; set; }
        public virtual DbSet<Language> Language { get; set; }
        public virtual DbSet<Menu> Menu { get; set; }
        public virtual DbSet<MenuLn> MenuLn { get; set; }
        public virtual DbSet<MenuRights> MenuRights { get; set; }
        public virtual DbSet<Person> Person { get; set; }
        public virtual DbSet<Photo> Photo { get; set; }
        public virtual DbSet<Rights> Rights { get; set; }
        public virtual DbSet<RightsAction> RightsAction { get; set; }
        public virtual DbSet<RightsLn> RightsLn { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<RoleFunctionality> RoleFunctionality { get; set; }
        public virtual DbSet<RoleLn> RoleLn { get; set; }
        public virtual DbSet<Token> Token { get; set; }
        public virtual DbSet<TokenAccess> TokenAccess { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=pc01;Database=FFVS;user id=ft;password=f@123;Trusted_Connection=True;Integrated Security = false;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.4-servicing-10062");

            modelBuilder.Entity<ActionMethod>(entity =>
            {
                entity.Property(e => e.CanLoadWitoutOwnerRights)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DispalyAsMenu)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.DisplayName)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.IsLoginRequired)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.HasOne(d => d.ControllerClass)
                    .WithMany(p => p.ActionMethod)
                    .HasForeignKey(d => d.ControllerClassId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ActionMethod_ControllerClass");
            });

            modelBuilder.Entity<Album>(entity =>
            {
                entity.Property(e => e.AlbumId).ValueGeneratedNever();

                entity.Property(e => e.CreatedDate).HasColumnType("smalldatetime");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.Path).HasMaxLength(500);
            });

            modelBuilder.Entity<ControllerClass>(entity =>
            {
                entity.Property(e => e.ClassType)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Functionality>(entity =>
            {
                entity.Property(e => e.FunctionalityFor)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('A')");

                entity.Property(e => e.Name).HasMaxLength(200);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.HasOne(d => d.FunctionalityGroup)
                    .WithMany(p => p.Functionality)
                    .HasForeignKey(d => d.FunctionalityGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Functionality_FunctionalityGroup");
            });

            modelBuilder.Entity<FunctionalityAction>(entity =>
            {
                entity.HasKey(e => new { e.FunctionalityId, e.ActionMethodId });

                entity.HasOne(d => d.ActionMethod)
                    .WithMany(p => p.FunctionalityAction)
                    .HasForeignKey(d => d.ActionMethodId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FunctionalityAction_ActionMethod");

                entity.HasOne(d => d.Functionality)
                    .WithMany(p => p.FunctionalityAction)
                    .HasForeignKey(d => d.FunctionalityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FunctionalityAction_Functionality");
            });

            modelBuilder.Entity<FunctionalityGroup>(entity =>
            {
                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<FunctionalityGroupLn>(entity =>
            {
                entity.HasKey(e => new { e.FunctionalityGroupId, e.LanguageId });

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.FunctionalityGroup)
                    .WithMany(p => p.FunctionalityGroupLn)
                    .HasForeignKey(d => d.FunctionalityGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FunctionalityGroupLn_FunctionalityGroup");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.FunctionalityGroupLn)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FunctionalityGroupLn_Language");
            });

            modelBuilder.Entity<FunctionalityRights>(entity =>
            {
                entity.HasKey(e => new { e.FunctionalityId, e.RightId })
                    .HasName("PK_FuntionalityRights");

                entity.HasOne(d => d.Functionality)
                    .WithMany(p => p.FunctionalityRights)
                    .HasForeignKey(d => d.FunctionalityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FunctionalityRights_Functionality");

                entity.HasOne(d => d.Right)
                    .WithMany(p => p.FunctionalityRights)
                    .HasForeignKey(d => d.RightId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FunctionalityRights_Rights");
            });

            modelBuilder.Entity<Language>(entity =>
            {
                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Menu>(entity =>
            {
                entity.Property(e => e.ClassName).HasMaxLength(100);

                entity.Property(e => e.DisplayHtml)
                    .HasColumnName("DisplayHTML")
                    .HasMaxLength(3000);

                entity.Property(e => e.MenuType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MenuUrl)
                    .IsRequired()
                    .HasColumnName("MenuURL")
                    .HasMaxLength(500);

                entity.HasOne(d => d.Functionality)
                    .WithMany(p => p.Menu)
                    .HasForeignKey(d => d.FunctionalityId)
                    .HasConstraintName("FK_Menu_ActionMethod");

                entity.HasOne(d => d.FunctionalityNavigation)
                    .WithMany(p => p.Menu)
                    .HasForeignKey(d => d.FunctionalityId)
                    .HasConstraintName("FK_Menu_Functionality");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Menu)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Menu_Role");
            });

            modelBuilder.Entity<MenuLn>(entity =>
            {
                entity.HasKey(e => new { e.MenuId, e.LanguageId });

                entity.Property(e => e.DisplayName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.Menu)
                    .WithMany(p => p.MenuLn)
                    .HasForeignKey(d => d.MenuId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MenuLn_Menu");
            });

            modelBuilder.Entity<MenuRights>(entity =>
            {
                entity.HasKey(e => new { e.MenuId, e.RightId });

                entity.HasOne(d => d.Menu)
                    .WithMany(p => p.MenuRights)
                    .HasForeignKey(d => d.MenuId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MenuRights_Menu");

                entity.HasOne(d => d.Right)
                    .WithMany(p => p.MenuRights)
                    .HasForeignKey(d => d.RightId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MenuRights_Rights");
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.Property(e => e.Code).HasMaxLength(40);

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Password).HasMaxLength(100);

                entity.Property(e => e.PersonType)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.RegisteredOn).HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Photo>(entity =>
            {
                entity.Property(e => e.Description).HasMaxLength(1000);

                entity.Property(e => e.Image)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.UploadedDate).HasColumnType("smalldatetime");

                entity.HasOne(d => d.Album)
                    .WithMany(p => p.Photo)
                    .HasForeignKey(d => d.AlbumId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Photo_Album");
            });

            modelBuilder.Entity<Rights>(entity =>
            {
                entity.HasKey(e => e.RightId);

                entity.Property(e => e.ControlType)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.DisplayType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.RightType)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.HasOne(d => d.Functionality)
                    .WithMany(p => p.Rights)
                    .HasForeignKey(d => d.FunctionalityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Rights_Functionality");

                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.InverseParent)
                    .HasForeignKey(d => d.ParentId)
                    .HasConstraintName("FK_Rights_Rights");
            });

            modelBuilder.Entity<RightsAction>(entity =>
            {
                entity.HasKey(e => new { e.RightId, e.ActionMethodId });

                entity.HasOne(d => d.ActionMethod)
                    .WithMany(p => p.RightsAction)
                    .HasForeignKey(d => d.ActionMethodId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RightsAction_ActionMethod");

                entity.HasOne(d => d.Right)
                    .WithMany(p => p.RightsAction)
                    .HasForeignKey(d => d.RightId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RightsAction_Right");
            });

            modelBuilder.Entity<RightsLn>(entity =>
            {
                entity.HasKey(e => new { e.RightId, e.LanguageId });

                entity.Property(e => e.Description).HasMaxLength(4000);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.RightsLn)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RightsLn_Language");

                entity.HasOne(d => d.Right)
                    .WithMany(p => p.RightsLn)
                    .HasForeignKey(d => d.RightId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RightsLn_Rights");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.Property(e => e.IsDefault)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.RoleType)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<RoleFunctionality>(entity =>
            {
                entity.HasKey(e => new { e.RoleId, e.FunctionalityId, e.RightId });

                entity.HasOne(d => d.Functionality)
                    .WithMany(p => p.RoleFunctionality)
                    .HasForeignKey(d => d.FunctionalityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RoleFunctionality_Functionality");

                entity.HasOne(d => d.Right)
                    .WithMany(p => p.RoleFunctionality)
                    .HasForeignKey(d => d.RightId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RoleFunctionality_Rights");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.RoleFunctionality)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RoleFunctionality_Role");
            });

            modelBuilder.Entity<RoleLn>(entity =>
            {
                entity.HasKey(e => new { e.RoleId, e.LanguageId });

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.RoleLn)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RoleLn_Language");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.RoleLn)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RoleLn_Role");
            });

            modelBuilder.Entity<Token>(entity =>
            {
                entity.Property(e => e.BrowserId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Ipaddress)
                    .IsRequired()
                    .HasColumnName("IPAddress")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ValidFrom).HasColumnType("date");

                entity.Property(e => e.ValidTo).HasColumnType("date");

                entity.HasOne(d => d.Person)
                    .WithMany(p => p.Token)
                    .HasForeignKey(d => d.PersonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Token_Users");
            });

            modelBuilder.Entity<TokenAccess>(entity =>
            {
                entity.Property(e => e.AccessedOn).HasColumnType("datetime");

                entity.HasOne(d => d.Token)
                    .WithMany(p => p.TokenAccess)
                    .HasForeignKey(d => d.TokenId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TokenAccess_Token");
            });
        }
    }
}
