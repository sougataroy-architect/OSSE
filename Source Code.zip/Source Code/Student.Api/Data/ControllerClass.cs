﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class ControllerClass
    {
        public ControllerClass()
        {
            ActionMethod = new HashSet<ActionMethod>();
        }

        public int ControllerClassId { get; set; }
        public string Name { get; set; }
        public string ClassType { get; set; }

        public virtual ICollection<ActionMethod> ActionMethod { get; set; }
    }
}
