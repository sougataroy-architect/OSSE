﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class FunctionalityAction
    {
        public int ActionMethodId { get; set; }
        public int FunctionalityId { get; set; }

        public virtual ActionMethod ActionMethod { get; set; }
        public virtual Functionality Functionality { get; set; }
    }
}
