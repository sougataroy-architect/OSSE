﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class ActionMethod
    {
        public ActionMethod()
        {
            FunctionalityAction = new HashSet<FunctionalityAction>();
            Menu = new HashSet<Menu>();
            RightsAction = new HashSet<RightsAction>();
        }

        public int ActionMethodId { get; set; }
        public int ControllerClassId { get; set; }
        public string DisplayName { get; set; }
        public string Name { get; set; }
        public string DispalyAsMenu { get; set; }
        public string Status { get; set; }
        public string IsLoginRequired { get; set; }
        public string CanLoadWitoutOwnerRights { get; set; }

        public virtual ControllerClass ControllerClass { get; set; }
        public virtual ICollection<FunctionalityAction> FunctionalityAction { get; set; }
        public virtual ICollection<Menu> Menu { get; set; }
        public virtual ICollection<RightsAction> RightsAction { get; set; }
    }
}
