﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class FunctionalityGroupLn
    {
        public int FunctionalityGroupId { get; set; }
        public int LanguageId { get; set; }
        public string Name { get; set; }

        public virtual FunctionalityGroup FunctionalityGroup { get; set; }
        public virtual Language Language { get; set; }
    }
}
