﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class MenuLn
    {
        public int MenuId { get; set; }
        public int LanguageId { get; set; }
        public string DisplayName { get; set; }

        public virtual Menu Menu { get; set; }
    }
}
