﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class Functionality
    {
        public Functionality()
        {
            FunctionalityAction = new HashSet<FunctionalityAction>();
            FunctionalityRights = new HashSet<FunctionalityRights>();
            Menu = new HashSet<Menu>();
            Rights = new HashSet<Rights>();
            RoleFunctionality = new HashSet<RoleFunctionality>();
        }

        public int FunctionalityId { get; set; }
        public int FunctionalityGroupId { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public string FunctionalityFor { get; set; }

        public virtual FunctionalityGroup FunctionalityGroup { get; set; }
        public virtual ICollection<FunctionalityAction> FunctionalityAction { get; set; }
        public virtual ICollection<FunctionalityRights> FunctionalityRights { get; set; }
        public virtual ICollection<Menu> Menu { get; set; }
        public virtual ICollection<Rights> Rights { get; set; }
        public virtual ICollection<RoleFunctionality> RoleFunctionality { get; set; }
    }
}
