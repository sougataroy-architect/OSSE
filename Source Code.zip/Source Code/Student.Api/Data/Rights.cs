﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class Rights
    {
        public Rights()
        {
            FunctionalityRights = new HashSet<FunctionalityRights>();
            InverseParent = new HashSet<Rights>();
            MenuRights = new HashSet<MenuRights>();
            RightsAction = new HashSet<RightsAction>();
            RightsLn = new HashSet<RightsLn>();
            RoleFunctionality = new HashSet<RoleFunctionality>();
        }

        public int RightId { get; set; }
        public int? ParentId { get; set; }
        public int FunctionalityId { get; set; }
        public string RightType { get; set; }
        public string ControlType { get; set; }
        public string DisplayType { get; set; }

        public virtual Functionality Functionality { get; set; }
        public virtual Rights Parent { get; set; }
        public virtual ICollection<FunctionalityRights> FunctionalityRights { get; set; }
        public virtual ICollection<Rights> InverseParent { get; set; }
        public virtual ICollection<MenuRights> MenuRights { get; set; }
        public virtual ICollection<RightsAction> RightsAction { get; set; }
        public virtual ICollection<RightsLn> RightsLn { get; set; }
        public virtual ICollection<RoleFunctionality> RoleFunctionality { get; set; }
    }
}
