﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class TokenAccess
    {
        public int Id { get; set; }
        public int TokenId { get; set; }
        public DateTime? AccessedOn { get; set; }

        public virtual Token Token { get; set; }
    }
}
