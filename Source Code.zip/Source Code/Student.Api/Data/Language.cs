﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class Language
    {
        public Language()
        {
            FunctionalityGroupLn = new HashSet<FunctionalityGroupLn>();
            RightsLn = new HashSet<RightsLn>();
            RoleLn = new HashSet<RoleLn>();
        }

        public int LanguageId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<FunctionalityGroupLn> FunctionalityGroupLn { get; set; }
        public virtual ICollection<RightsLn> RightsLn { get; set; }
        public virtual ICollection<RoleLn> RoleLn { get; set; }
    }
}
