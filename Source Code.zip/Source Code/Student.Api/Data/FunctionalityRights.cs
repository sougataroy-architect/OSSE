﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class FunctionalityRights
    {
        public int FunctionalityId { get; set; }
        public int RightId { get; set; }

        public virtual Functionality Functionality { get; set; }
        public virtual Rights Right { get; set; }
    }
}
