﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class Token
    {
        public Token()
        {
            TokenAccess = new HashSet<TokenAccess>();
        }

        public int Id { get; set; }
        public Guid AccessToken { get; set; }
        public string Ipaddress { get; set; }
        public int PersonId { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }
        public string BrowserId { get; set; }

        public virtual Person Person { get; set; }
        public virtual ICollection<TokenAccess> TokenAccess { get; set; }
    }
}
