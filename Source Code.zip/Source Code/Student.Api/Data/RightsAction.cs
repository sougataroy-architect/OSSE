﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class RightsAction
    {
        public int ActionMethodId { get; set; }
        public int RightId { get; set; }

        public virtual ActionMethod ActionMethod { get; set; }
        public virtual Rights Right { get; set; }
    }
}
