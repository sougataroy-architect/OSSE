﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class RightsLn
    {
        public int RightId { get; set; }
        public int LanguageId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public virtual Language Language { get; set; }
        public virtual Rights Right { get; set; }
    }
}
