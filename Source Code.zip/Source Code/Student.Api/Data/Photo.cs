﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class Photo
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public int AlbumId { get; set; }
        public int UploadedBy { get; set; }
        public DateTime UploadedDate { get; set; }

        public virtual Album Album { get; set; }
    }
}
