﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class FunctionalityGroup
    {
        public FunctionalityGroup()
        {
            Functionality = new HashSet<Functionality>();
            FunctionalityGroupLn = new HashSet<FunctionalityGroupLn>();
        }

        public int FunctionalityGroupId { get; set; }
        public string Status { get; set; }

        public virtual ICollection<Functionality> Functionality { get; set; }
        public virtual ICollection<FunctionalityGroupLn> FunctionalityGroupLn { get; set; }
    }
}
