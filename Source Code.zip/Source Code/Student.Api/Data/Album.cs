﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class Album
    {
        public Album()
        {
            Photo = new HashSet<Photo>();
        }

        public int AlbumId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Path { get; set; }

        public virtual ICollection<Photo> Photo { get; set; }
    }
}
