﻿using System;
using System.Collections.Generic;

namespace Student.Api.Data
{
    public partial class MenuRights
    {
        public int MenuId { get; set; }
        public int RightId { get; set; }

        public virtual Menu Menu { get; set; }
        public virtual Rights Right { get; set; }
    }
}
